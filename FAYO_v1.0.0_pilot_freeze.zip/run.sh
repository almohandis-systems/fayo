#!/usr/bin/env bash
export PYTHONPATH="."
python3 -m uvicorn fayo_core.api.main:app --host 0.0.0.0 --port 8000
