import json
import uuid
import sqlite3
from typing import Dict, Any, Callable, List

_EVENT_HANDLERS: Dict[str, List[Callable[[Dict[str, Any], Dict[str, Any]], None]]] = {}

def register_event_handler(event_type: str, handler: Callable[[Dict[str, Any], Dict[str, Any]], None]):
    if event_type not in _EVENT_HANDLERS:
        _EVENT_HANDLERS[event_type] = []
    _EVENT_HANDLERS[event_type].append(handler)

def write_outbox_event(
    conn: sqlite3.Connection,
    aggregate_type: str,
    aggregate_id: str,
    event_type: str,
    payload: Dict[str, Any],
    headers: Dict[str, Any] = None
) -> str:
    event_id = str(uuid.uuid4())
    headers = headers or {}
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO transactional_outbox (
            id, aggregate_type, aggregate_id, event_type, payload, headers, status
        ) VALUES (?, ?, ?, ?, ?, ?, 'PENDING')
    """, (
        event_id,
        aggregate_type,
        aggregate_id,
        event_type,
        json.dumps(payload),
        json.dumps(headers)
    ))
    return event_id

def process_outbox_batch(conn: sqlite3.Connection, max_batch: int = 50, max_retries: int = 5) -> int:
    cur = conn.cursor()
    cur.execute("""
        SELECT id, aggregate_type, aggregate_id, event_type, payload, headers, retry_count
        FROM transactional_outbox
        WHERE status = 'PENDING'
        ORDER BY created_at ASC
        LIMIT ?
    """, (max_batch,))
    rows = cur.fetchall()
    
    processed_count = 0
    for row in rows:
        event_id = row["id"]
        event_type = row["event_type"]
        payload = json.loads(row["payload"])
        headers = json.loads(row["headers"])
        retry_count = row["retry_count"]

        handlers = _EVENT_HANDLERS.get(event_type, [])
        handlers_failed = False
        last_error = None

        for handler in handlers:
            try:
                handler(payload, headers)
            except Exception as e:
                handlers_failed = True
                last_error = str(e)
                break

        if not handlers_failed:
            cur.execute("""
                UPDATE transactional_outbox
                SET status = 'PUBLISHED', published_at = datetime('now', 'utc')
                WHERE id = ?
            """, (event_id,))
            processed_count += 1
        else:
            new_retries = retry_count + 1
            if new_retries >= max_retries:
                dlq_id = str(uuid.uuid4())
                cur.execute("""
                    INSERT INTO dead_letter_events (
                        id, original_event_id, event_type, payload, error_reason, retry_count
                    ) VALUES (?, ?, ?, ?, ?, ?)
                """, (dlq_id, event_id, event_type, json.dumps(payload), last_error or "Unknown failure", new_retries))

                cur.execute("""
                    UPDATE transactional_outbox
                    SET status = 'FAILED', retry_count = ?
                    WHERE id = ?
                """, (new_retries, event_id))
            else:
                cur.execute("""
                    UPDATE transactional_outbox
                    SET retry_count = ?
                    WHERE id = ?
                """, (new_retries, event_id))

    return processed_count
