import json
import hashlib
import sqlite3
from typing import Optional, Tuple, Any, Dict
from fayo_core.shared.domain.errors import IdempotencyConflictError, ConflictError

def compute_request_hash(payload: Any) -> str:
    canonical = json.dumps(payload, sort_keys=True)
    return hashlib.sha256(canonical.encode('utf-8')).hexdigest()

def check_or_acquire_idempotency(
    conn: sqlite3.Connection,
    key: str,
    user_id: str,
    request_payload: Any,
    ttl_hours: int = 24
) -> Optional[Tuple[int, Dict[str, Any]]]:
    request_hash = compute_request_hash(request_payload)
    cur = conn.cursor()
    
    cur.execute("""
        SELECT status, request_hash, response_code, response_body, expires_at
        FROM idempotency_keys
        WHERE key = ?
    """, (key,))
    row = cur.fetchone()

    if row:
        if row["request_hash"] != request_hash:
            raise ConflictError(
                title="Idempotency Key Payload Mismatch",
                detail=f"The Idempotency-Key '{key}' was already used with a different request payload."
            )
        
        status = row["status"]
        if status == "PROCESSING":
            raise IdempotencyConflictError(key)
        elif status == "RESOLVED":
            response_code = row["response_code"]
            response_body = json.loads(row["response_body"]) if row["response_body"] else {}
            return (response_code, response_body)
    
    cur.execute("""
        INSERT INTO idempotency_keys (key, user_id, request_hash, status, expires_at)
        VALUES (?, ?, ?, 'PROCESSING', datetime('now', 'utc', ?))
    """, (key, user_id, request_hash, f'+{ttl_hours} hours'))
    
    return None

def resolve_idempotency(
    conn: sqlite3.Connection,
    key: str,
    response_code: int,
    response_body: Dict[str, Any]
):
    cur = conn.cursor()
    cur.execute("""
        UPDATE idempotency_keys
        SET status = 'RESOLVED',
            response_code = ?,
            response_body = ?
        WHERE key = ?
    """, (response_code, json.dumps(response_body), key))
