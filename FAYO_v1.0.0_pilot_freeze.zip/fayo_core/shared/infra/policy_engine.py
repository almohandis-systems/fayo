import sqlite3
from typing import Dict, Any, Optional
from fayo_core.shared.domain.errors import PolicyViolationError

POLICY_MAX_COD_LIMIT_EGP = 2000.00
POLICY_MAX_DELIVERY_DISTANCE_KM = 35.00
POLICY_MAX_MERCHANT_PREP_MINUTES = 60
POLICY_MAX_ORDER_ITEMS_COUNT = 50
POLICY_MAX_WAIT_COMPENSATION_CAP_EGP = 30.00
POLICY_WAIT_COMPENSATION_RATE_PER_MINUTE = 1.50
POLICY_MERCHANT_GRACE_PERIOD_MINUTES = 10

def is_kill_switch_engaged(conn: sqlite3.Connection, switch_key: str) -> bool:
    cur = conn.cursor()
    cur.execute("SELECT is_engaged FROM policy_kill_switches WHERE switch_key = ?", (switch_key,))
    row = cur.fetchone()
    if row and row["is_engaged"] == 1:
        return True
    return False

def set_kill_switch(conn: sqlite3.Connection, switch_key: str, is_engaged: bool, reason: str, engaged_by: str):
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO policy_kill_switches (switch_key, is_engaged, reason, engaged_by, updated_at)
        VALUES (?, ?, ?, ?, datetime('now', 'utc'))
        ON CONFLICT(switch_key) DO UPDATE SET
            is_engaged = excluded.is_engaged,
            reason = excluded.reason,
            engaged_by = excluded.engaged_by,
            updated_at = datetime('now', 'utc');
    """, (switch_key, 1 if is_engaged else 0, reason, engaged_by))

def validate_policy_order_creation(
    conn: sqlite3.Connection,
    zone_id: str,
    items_count: int,
    distance_km: float,
    total_amount: float
):
    if is_kill_switch_engaged(conn, "KILL_SWITCH:GLOBAL_AUTOMATION"):
        raise PolicyViolationError("GLOBAL_AUTOMATION", "System operations temporarily paused by platform management.")
    
    zone_switch = f"KILL_SWITCH:ZONE:{zone_id}"
    if is_kill_switch_engaged(conn, zone_switch):
        raise PolicyViolationError("ZONE_RESTRICTION", f"Operations in zone '{zone_id}' are temporarily paused.")

    if items_count > POLICY_MAX_ORDER_ITEMS_COUNT:
        raise PolicyViolationError(
            "ORDER_ITEMS_CAP",
            f"Order items count ({items_count}) exceeds maximum allowed cap of {POLICY_MAX_ORDER_ITEMS_COUNT}."
        )

    if distance_km > POLICY_MAX_DELIVERY_DISTANCE_KM:
        raise PolicyViolationError(
            "DISTANCE_CAP",
            f"Delivery distance ({distance_km:.1f} km) exceeds maximum delivery radius of {POLICY_MAX_DELIVERY_DISTANCE_KM} km."
        )

def validate_courier_cod_capacity(conn: sqlite3.Connection, courier_id: str, order_total: float, current_floating_cash: float):
    cur = conn.cursor()
    cur.execute("SELECT cod_balance_limit FROM fleet_couriers WHERE courier_id = ?", (courier_id,))
    row = cur.fetchone()
    limit = row["cod_balance_limit"] if row else POLICY_MAX_COD_LIMIT_EGP
    
    if (current_floating_cash + order_total) > limit:
        raise PolicyViolationError(
            "COURIER_COD_LIMIT",
            f"Assigning this cash order ({order_total:.2f} EGP) causes courier floating cash ({current_floating_cash + order_total:.2f} EGP) to exceed safe limit ({limit:.2f} EGP)."
        )
