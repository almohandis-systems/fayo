import json
import sqlite3
from typing import Any, Dict, Optional

def log_audit_trail(
    conn: sqlite3.Connection,
    trace_id: str,
    actor_id: str,
    actor_type: str,
    action: str,
    entity_type: str,
    entity_id: str,
    decision_reason: str,
    input_payload: Optional[Dict[str, Any]] = None,
    state_before: Optional[Dict[str, Any]] = None,
    state_after: Optional[Dict[str, Any]] = None,
    ip_address: Optional[str] = None,
    user_agent: Optional[str] = None
) -> int:
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO audit_system_audit_trail (
            trace_id, actor_id, actor_type, action, entity_type, entity_id,
            ip_address, user_agent, input_payload, decision_reason, state_before, state_after
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        trace_id,
        actor_id,
        actor_type,
        action,
        entity_type,
        entity_id,
        ip_address,
        user_agent,
        json.dumps(input_payload) if input_payload is not None else None,
        decision_reason,
        json.dumps(state_before) if state_before is not None else None,
        json.dumps(state_after) if state_after is not None else None
    ))
    return cur.lastrowid

def log_security_alert(
    trace_id: str,
    actor_id: str,
    actor_type: str,
    action: str,
    entity_type: str,
    entity_id: str,
    decision_reason: str,
    input_payload: Optional[Dict[str, Any]] = None
):
    from fayo_core.database import get_db_connection
    conn = get_db_connection()
    try:
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO audit_system_audit_trail (
                trace_id, actor_id, actor_type, action, entity_type, entity_id,
                decision_reason, input_payload
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            trace_id, actor_id, actor_type, action, entity_type, entity_id,
            decision_reason, json.dumps(input_payload) if input_payload is not None else None
        ))
        conn.commit()
    finally:
        conn.close()
