class DomainError(Exception):
    def __init__(self, title: str, detail: str, status_code: int = 400, error_type: str = "about:blank", invalid_params: list = None):
        super().__init__(detail)
        self.title = title
        self.detail = detail
        self.status_code = status_code
        self.error_type = error_type
        self.invalid_params = invalid_params or []

    def to_dict(self, instance: str = None) -> dict:
        doc = {
            "type": self.error_type,
            "title": self.title,
            "status": self.status_code,
            "detail": self.detail,
        }
        if instance:
            doc["instance"] = instance
        if self.invalid_params:
            doc["invalid_params"] = self.invalid_params
        return doc

class NotFoundError(DomainError):
    def __init__(self, entity: str, identifier: str):
        super().__init__(
            title="Entity Not Found",
            detail=f"{entity} with identifier '{identifier}' was not found.",
            status_code=404,
            error_type="https://errors.fayo.app/not-found"
        )

class ConflictError(DomainError):
    def __init__(self, title: str, detail: str, invalid_params: list = None):
        super().__init__(
            title=title,
            detail=detail,
            status_code=409,
            error_type="https://errors.fayo.app/conflict",
            invalid_params=invalid_params
        )

class UnauthorizedError(DomainError):
    def __init__(self, detail: str = "Authentication credentials missing or invalid."):
        super().__init__(
            title="Unauthorized",
            detail=detail,
            status_code=401,
            error_type="https://errors.fayo.app/unauthorized"
        )

class ForbiddenError(DomainError):
    def __init__(self, detail: str = "You do not have permission to perform this action."):
        super().__init__(
            title="Forbidden",
            detail=detail,
            status_code=403,
            error_type="https://errors.fayo.app/forbidden"
        )

class PolicyViolationError(DomainError):
    def __init__(self, policy_rule: str, reason: str):
        super().__init__(
            title="Policy Engine Rejection",
            detail=f"Operation rejected by policy rule '{policy_rule}': {reason}",
            status_code=422,
            error_type="https://errors.fayo.app/policy-violation"
        )

class IdempotencyConflictError(DomainError):
    def __init__(self, key: str):
        super().__init__(
            title="Concurrent Idempotent Request in Progress",
            detail=f"A request with Idempotency-Key '{key}' is already actively being processed.",
            status_code=409,
            error_type="https://errors.fayo.app/idempotency-conflict"
        )
