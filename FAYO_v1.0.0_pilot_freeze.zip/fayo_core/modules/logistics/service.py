import uuid
import math
import hashlib
import sqlite3
from typing import Optional, Dict, Any, List
from fayo_core.shared.domain.errors import (
    NotFoundError, ConflictError, ForbiddenError, PolicyViolationError
)
from fayo_core.shared.infra.audit import log_audit_trail
from fayo_core.shared.infra.outbox import write_outbox_event
from fayo_core.shared.infra.policy_engine import (
    POLICY_MAX_WAIT_COMPENSATION_CAP_EGP,
    POLICY_WAIT_COMPENSATION_RATE_PER_MINUTE,
    POLICY_MERCHANT_GRACE_PERIOD_MINUTES,
    validate_courier_cod_capacity
)
from fayo_core.modules.orders.service import calculate_haversine_distance_km

class LogisticsService:
    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn

    def register_courier(
        self,
        user_id: str,
        vehicle_type: str,
        license_plate: str,
        max_payload_weight_kg: float = 30.0,
        max_payload_volume_m3: float = 0.15,
        cod_balance_limit: float = 2000.0
    ) -> Dict[str, Any]:
        cur = self.conn.cursor()
        courier_id = str(uuid.uuid4())
        cur.execute("""
            INSERT INTO fleet_couriers (
                courier_id, user_id, vehicle_type, license_plate,
                max_payload_weight_kg, max_payload_volume_m3,
                is_active, is_online, current_status, cod_balance_limit
            ) VALUES (?, ?, ?, ?, ?, ?, 1, 1, 'IDLE', ?)
        """, (courier_id, user_id, vehicle_type, license_plate, max_payload_weight_kg, max_payload_volume_m3, cod_balance_limit))

        return {
            "courier_id": courier_id,
            "vehicle_type": vehicle_type,
            "status": "IDLE",
            "cod_limit": cod_balance_limit
        }

    def update_courier_telemetry(
        self,
        courier_id: str,
        lat: float,
        lng: float,
        speed_kmh: float,
        is_mock: bool = False
    ):
        cur = self.conn.cursor()
        # GPS Spoofing Detection
        if is_mock or speed_kmh > 140.0:
            log_audit_trail(
                conn=self.conn,
                trace_id=str(uuid.uuid4()),
                actor_id=courier_id,
                actor_type="COURIER",
                action="GPS_SPOOFING_DETECTED",
                entity_type="COURIER",
                entity_id=courier_id,
                decision_reason="Anomalous speed or mock provider detected",
                input_payload={"speed": speed_kmh, "is_mock": is_mock, "coords": [lat, lng]}
            )
            raise ConflictError("Telemetry Rejected", "Simulated or impossible GPS coordinates detected.")

        cur.execute("""
            UPDATE fleet_couriers
            SET current_lat = ?,
                current_lng = ?,
                last_location_update = datetime('now', 'utc')
            WHERE courier_id = ?
        """, (lat, lng, courier_id))

        cur.execute("""
            INSERT INTO fleet_telemetry_logs (courier_id, lat, lng, speed_kmh, is_mock)
            VALUES (?, ?, ?, ?, ?)
        """, (courier_id, lat, lng, speed_kmh, 1 if is_mock else 0))

    def select_best_vehicle_type(
        self,
        weight_kg: float,
        volume_m3: float,
        distance_km: float,
        is_narrow_village_alley: bool = False
    ) -> str:
        if weight_kg > 30.0 or volume_m3 > 0.15:
            return "TRICYCLE"
        if is_narrow_village_alley:
            return "TUKTUK"
        if distance_km > 12.0:
            return "CAR"
        return "MOTORCYCLE"

    def assign_smart_dispatch(self, order_id: str) -> Dict[str, Any]:
        cur = self.conn.cursor()
        cur.execute("""
            SELECT o.merchant_id, o.total_amount, o.delivery_lat, o.delivery_lng,
                   m.lat as merchant_lat, m.lng as merchant_lng
            FROM orders_orders o
            JOIN commerce_merchants m ON o.merchant_id = m.merchant_id
            WHERE o.order_id = ?
        """, (order_id,))
        order = cur.fetchone()
        if not order:
            raise NotFoundError("Order", order_id)

        m_lat = order["merchant_lat"]
        m_lng = order["merchant_lng"]
        order_total = order["total_amount"]

        # Find online IDLE couriers
        cur.execute("""
            SELECT courier_id, vehicle_type, current_lat, current_lng, cod_balance_limit
            FROM fleet_couriers
            WHERE is_active = 1 AND is_online = 1 AND current_status = 'IDLE' AND current_lat IS NOT NULL
        """)
        candidates = cur.fetchall()
        if not candidates:
            raise ConflictError("No Couriers Available", "No available idle couriers found in this operating zone.")

        # Score candidates by proximity to merchant
        scored_candidates = []
        for c in candidates:
            # Check current floating cash
            cur.execute("""
                SELECT COALESCE(SUM(p.amount), 0.0) as floating_cash
                FROM finance_postings p
                JOIN finance_accounts a ON p.account_id = a.account_id
                WHERE a.entity_type = 'COURIER' AND a.entity_id = ? AND a.account_type = 'ASSET'
            """, (c["courier_id"],))
            row = cur.fetchone()
            floating_cash = row["floating_cash"] if row else 0.0

            if (floating_cash + order_total) > c["cod_balance_limit"]:
                continue # Skip couriers exceeding COD float limit

            dist_to_store = calculate_haversine_distance_km(c["current_lat"], c["current_lng"], m_lat, m_lng)
            scored_candidates.append((dist_to_store, c))

        if not scored_candidates:
            raise ConflictError("Courier Capacity Exceeded", "All nearby couriers have reached their maximum COD cash limit.")

        scored_candidates.sort(key=lambda x: x[0])
        best_dist, best_courier = scored_candidates[0]
        courier_id = best_courier["courier_id"]

        # Generate 6-digit Delivery OTP
        raw_otp = str(uuid.uuid4().int)[:6].zfill(6)
        otp_hash = hashlib.sha256(raw_otp.encode('utf-8')).hexdigest()

        delivery_id = str(uuid.uuid4())
        dist_total = calculate_haversine_distance_km(m_lat, m_lng, order["delivery_lat"], order["delivery_lng"])

        cur.execute("""
            INSERT INTO fleet_deliveries (
                delivery_id, order_id, courier_id, pickup_lat, pickup_lng,
                dropoff_lat, dropoff_lng, estimated_distance_km, assigned_at, delivery_otp_hash
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now', 'utc'), ?)
        """, (
            delivery_id, order_id, courier_id, m_lat, m_lng,
            order["delivery_lat"], order["delivery_lng"], dist_total, otp_hash
        ))

        cur.execute("UPDATE fleet_couriers SET current_status = 'ASSIGNED' WHERE courier_id = ?", (courier_id,))
        cur.execute("UPDATE orders_orders SET order_status = 'READY_FOR_PICKUP' WHERE order_id = ?", (order_id,))

        write_outbox_event(
            self.conn,
            aggregate_type="DELIVERY",
            aggregate_id=delivery_id,
            event_type="dispatch.assigned",
            payload={"delivery_id": delivery_id, "order_id": order_id, "courier_id": courier_id}
        )

        return {
            "delivery_id": delivery_id,
            "courier_id": courier_id,
            "order_id": order_id,
            "raw_otp": raw_otp # returned for client notification test
        }

    def courier_arrive_merchant(self, delivery_id: str, courier_id: str, courier_lat: float, courier_lng: float):
        cur = self.conn.cursor()
        cur.execute("SELECT pickup_lat, pickup_lng FROM fleet_deliveries WHERE delivery_id = ? AND courier_id = ?", (delivery_id, courier_id))
        deliv = cur.fetchone()
        if not deliv:
            raise NotFoundError("Delivery", delivery_id)

        # Geofence check: must be within 100 meters (0.1 km) of merchant pickup
        dist_m = calculate_haversine_distance_km(courier_lat, courier_lng, deliv["pickup_lat"], deliv["pickup_lng"]) * 1000.0
        if dist_m > 100.0:
            raise ConflictError(
                title="Geofence Violation",
                detail=f"Courier is {dist_m:.1f} meters away from store. Must be within 100m to confirm arrival."
            )

        cur.execute("""
            UPDATE fleet_deliveries
            SET arrived_merchant_at = datetime('now', 'utc')
            WHERE delivery_id = ?
        """, (delivery_id,))

        cur.execute("UPDATE fleet_couriers SET current_status = 'WAITING_AT_STORE' WHERE courier_id = ?", (courier_id,))

    def courier_pickup_order(self, delivery_id: str, courier_id: str):
        cur = self.conn.cursor()
        cur.execute("SELECT order_id, arrived_merchant_at FROM fleet_deliveries WHERE delivery_id = ? AND courier_id = ?", (delivery_id, courier_id))
        row = cur.fetchone()
        if not row:
            raise NotFoundError("Delivery", delivery_id)

        cur.execute("""
            UPDATE fleet_deliveries
            SET picked_up_at = datetime('now', 'utc')
            WHERE delivery_id = ?
        """, (delivery_id,))

        cur.execute("UPDATE fleet_couriers SET current_status = 'IN_DELIVERY' WHERE courier_id = ?", (courier_id,))
        cur.execute("UPDATE orders_orders SET order_status = 'IN_TRANSIT' WHERE order_id = ?", (row["order_id"],))

    def confirm_delivery_handshake(
        self,
        delivery_id: str,
        courier_id: str,
        provided_otp: str,
        cash_collected: float
    ) -> Dict[str, Any]:
        cur = self.conn.cursor()
        cur.execute("""
            SELECT d.order_id, d.delivery_otp_hash, d.otp_attempts, d.otp_expires_at, d.otp_locked_until,
                   o.payment_method, o.total_amount
            FROM fleet_deliveries d
            JOIN orders_orders o ON d.order_id = o.order_id
            WHERE d.delivery_id = ? AND d.courier_id = ?
        """, (delivery_id, courier_id))
        deliv = cur.fetchone()
        if not deliv:
            raise NotFoundError("Delivery", delivery_id)

        # 1. Check lock and brute-force attempt limits
        if deliv["otp_attempts"] >= 3:
            log_audit_trail(
                conn=self.conn,
                trace_id=str(uuid.uuid4()),
                actor_id=courier_id,
                actor_type="COURIER",
                action="OTP_BRUTE_FORCE_BLOCKED",
                entity_type="DELIVERY",
                entity_id=delivery_id,
                decision_reason="Maximum failed OTP attempts (3) exceeded"
            )
            raise ForbiddenError("Delivery verification is locked due to too many failed OTP attempts. Contact support.")

        # 2. Check expiration
        cur.execute("SELECT datetime('now', 'utc') > ? as is_expired", (deliv["otp_expires_at"],))
        exp_row = cur.fetchone()
        if exp_row and exp_row["is_expired"] == 1:
            raise ConflictError("OTP Expired", "Delivery verification OTP has expired. Customer must request a new code.")

        input_hash = hashlib.sha256(provided_otp.strip().encode('utf-8')).hexdigest()
        if input_hash != deliv["delivery_otp_hash"]:
            new_attempts = deliv["otp_attempts"] + 1
            cur.execute("UPDATE fleet_deliveries SET otp_attempts = ? WHERE delivery_id = ?", (new_attempts, delivery_id))
            log_audit_trail(
                conn=self.conn,
                trace_id=str(uuid.uuid4()),
                actor_id=courier_id,
                actor_type="COURIER",
                action="OTP_VERIFICATION_FAILED",
                entity_type="DELIVERY",
                entity_id=delivery_id,
                decision_reason=f"Incorrect OTP entered (Attempt {new_attempts}/3)"
            )
            self.conn.commit()
            raise ForbiddenError(f"Invalid Delivery OTP. ({3 - new_attempts} attempts remaining).")

        order_id = deliv["order_id"]
        cur.execute("UPDATE fleet_deliveries SET delivered_at = datetime('now', 'utc'), otp_attempts = 0 WHERE delivery_id = ?", (delivery_id,))
        cur.execute("UPDATE fleet_couriers SET current_status = 'IDLE' WHERE courier_id = ?", (courier_id,))
        cur.execute("UPDATE orders_orders SET order_status = 'DELIVERED', payment_status = 'CAPTURED' WHERE order_id = ?", (order_id,))

        write_outbox_event(
            self.conn,
            aggregate_type="DELIVERY",
            aggregate_id=delivery_id,
            event_type="order.delivered",
            payload={
                "delivery_id": delivery_id,
                "order_id": order_id,
                "courier_id": courier_id,
                "cash_collected": cash_collected
            }
        )

        return {"status": "DELIVERED", "order_id": order_id}

    def sync_offline_delivery(
        self,
        action_id: str,
        delivery_id: str,
        courier_id: str,
        provided_otp: str,
        cash_collected: float,
        client_timestamp: str
    ) -> Dict[str, Any]:
        # Idempotency check with action_id
        from fayo_core.shared.infra.idempotency import check_or_acquire_idempotency, resolve_idempotency
        cached = check_or_acquire_idempotency(
            self.conn,
            key=f"OFFLINE_{action_id}",
            user_id=courier_id,
            request_payload={"delivery_id": delivery_id, "cash": cash_collected}
        )
        if cached:
            return cached[1]

        # Execute delivery handshake
        result = self.confirm_delivery_handshake(
            delivery_id=delivery_id,
            courier_id=courier_id,
            provided_otp=provided_otp,
            cash_collected=cash_collected
        )

        log_audit_trail(
            conn=self.conn,
            trace_id=str(uuid.uuid4()),
            actor_id=courier_id,
            actor_type="COURIER",
            action="OFFLINE_EVENT_SYNCED",
            entity_type="DELIVERY",
            entity_id=delivery_id,
            decision_reason="Offline delivery confirmed upon network restoration",
            input_payload={"action_id": action_id, "client_ts": client_timestamp}
        )

        resolve_idempotency(self.conn, f"OFFLINE_{action_id}", 200, result)
        return result
