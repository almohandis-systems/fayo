import sqlite3
from typing import Dict, Any, List, Optional
from fayo_core.shared.infra.policy_engine import set_kill_switch, is_kill_switch_engaged
from fayo_core.shared.infra.outbox import process_outbox_batch

SUPPORTED_FAIYUM_ZONES = [
    {"zone_id": "FYM-CITY", "name_ar": "بندر الفيوم"},
    {"zone_id": "FYM-SINNURIS", "name_ar": "سنورس"},
    {"zone_id": "FYM-ITSA", "name_ar": "إطسا"},
    {"zone_id": "FYM-IBSHAWAY", "name_ar": "أبشواي"},
    {"zone_id": "FYM-TUNIS", "name_ar": "يوسف الصديق / قرية تونس"}
]

class ControlTowerService:
    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn

    def get_dashboard_snapshot(self) -> Dict[str, Any]:
        cur = self.conn.cursor()

        # 1. Orders breakdown by status
        cur.execute("""
            SELECT order_status, COUNT(*) as count
            FROM orders_orders
            GROUP BY order_status
        """)
        orders_by_status = {row["order_status"]: row["count"] for row in cur.fetchall()}

        # 2. Orders breakdown by zone
        cur.execute("""
            SELECT zone_id, COUNT(*) as count
            FROM orders_orders
            GROUP BY zone_id
        """)
        orders_by_zone = {row["zone_id"]: row["count"] for row in cur.fetchall()}

        # 3. Fleet metrics
        cur.execute("""
            SELECT 
                COUNT(*) as total_couriers,
                SUM(CASE WHEN is_online = 1 THEN 1 ELSE 0 END) as online_couriers,
                SUM(CASE WHEN current_status = 'IDLE' AND is_online = 1 THEN 1 ELSE 0 END) as idle_couriers,
                SUM(CASE WHEN current_status = 'IN_DELIVERY' THEN 1 ELSE 0 END) as in_delivery_couriers
            FROM fleet_couriers
        """)
        fleet_row = cur.fetchone()
        fleet_stats = {
            "total_couriers": fleet_row["total_couriers"] or 0,
            "online_couriers": fleet_row["online_couriers"] or 0,
            "idle_couriers": fleet_row["idle_couriers"] or 0,
            "in_delivery_couriers": fleet_row["in_delivery_couriers"] or 0
        }

        # 4. Total Courier Floating Cash (Asset account 1010)
        cur.execute("""
            SELECT COALESCE(SUM(p.amount), 0.0) as total_cash
            FROM finance_postings p
            JOIN finance_accounts a ON p.account_id = a.account_id
            WHERE a.account_name = 'COURIER_CASH' AND p.direction = 'DR'
        """)
        dr_cash = cur.fetchone()["total_cash"]
        cur.execute("""
            SELECT COALESCE(SUM(p.amount), 0.0) as total_cash
            FROM finance_postings p
            JOIN finance_accounts a ON p.account_id = a.account_id
            WHERE a.account_name = 'COURIER_CASH' AND p.direction = 'CR'
        """)
        cr_cash = cur.fetchone()["total_cash"]
        courier_floating_cash = round(dr_cash - cr_cash, 2)

        # 5. Platform Commission Revenue
        cur.execute("""
            SELECT 
                COALESCE(SUM(CASE WHEN p.direction = 'CR' THEN p.amount ELSE -p.amount END), 0.0) as revenue
            FROM finance_postings p
            JOIN finance_accounts a ON p.account_id = a.account_id
            WHERE a.account_name = 'PLATFORM_COMMISSION'
        """)
        platform_revenue = round(cur.fetchone()["revenue"], 2)

        # 6. System Health & DLQ
        cur.execute("SELECT COUNT(*) as pending_count FROM transactional_outbox WHERE status = 'PENDING'")
        pending_outbox = cur.fetchone()["pending_count"]

        cur.execute("SELECT COUNT(*) as dlq_count FROM dead_letter_events")
        dlq_count = cur.fetchone()["dlq_count"]

        # 7. Active Kill Switches
        cur.execute("SELECT switch_key, reason FROM policy_kill_switches WHERE is_engaged = 1")
        engaged_switches = {row["switch_key"]: row["reason"] for row in cur.fetchall()}

        return {
            "system_health": {
                "status": "OPERATIONAL" if not engaged_switches else "DEGRADED",
                "pending_outbox_events": pending_outbox,
                "dead_letter_events_count": dlq_count,
                "engaged_kill_switches": engaged_switches
            },
            "orders": {
                "by_status": orders_by_status,
                "by_zone": orders_by_zone
            },
            "fleet": fleet_stats,
            "financials": {
                "courier_floating_cash_egp": courier_floating_cash,
                "platform_accumulated_commission_egp": platform_revenue
            }
        }

    def set_system_kill_switch(self, switch_key: str, is_engaged: bool, reason: str, actor_id: str):
        set_kill_switch(self.conn, switch_key, is_engaged, reason, actor_id)

    def trigger_outbox_relay(self) -> int:
        return process_outbox_batch(self.conn)

    # --- Delivery Area Control ---
    def get_delivery_zones_status(self) -> Dict[str, Any]:
        global_paused = is_kill_switch_engaged(self.conn, "KILL_SWITCH:GLOBAL_AUTOMATION")
        cur = self.conn.cursor()
        
        zones_status = []
        all_active = not global_paused
        
        for z in SUPPORTED_FAIYUM_ZONES:
            zone_id = z["zone_id"]
            zone_paused = global_paused or is_kill_switch_engaged(self.conn, f"KILL_SWITCH:ZONE:{zone_id}")
            if zone_paused:
                all_active = False
                
            cur.execute("SELECT reason, updated_at FROM policy_kill_switches WHERE switch_key = ? AND is_engaged = 1", (f"KILL_SWITCH:ZONE:{zone_id}",))
            row = cur.fetchone()
            reason = row["reason"] if row else ("Global halt engaged" if global_paused else None)
            
            zones_status.append({
                "zone_id": zone_id,
                "name_ar": z["name_ar"],
                "is_active": not zone_paused,
                "status_text": "التوصيل مفعّل" if not zone_paused else "التوصيل متوقف",
                "reason": reason
            })
            
        return {
            "all_zones_active": all_active,
            "global_status": "OPERATIONAL" if not global_paused else "PAUSED",
            "zones": zones_status
        }

    def toggle_delivery_zone(self, zone_id: Optional[str], is_active: bool, reason: str, actor_id: str) -> Dict[str, Any]:
        if zone_id in ("ALL", None):
            set_kill_switch(self.conn, "KILL_SWITCH:GLOBAL_AUTOMATION", not is_active, reason, actor_id)
            if is_active:
                for z in SUPPORTED_FAIYUM_ZONES:
                    set_kill_switch(self.conn, f"KILL_SWITCH:ZONE:{z['zone_id']}", False, reason, actor_id)
            return {
                "status": "ALL_ZONES_UPDATED",
                "all_zones_active": is_active,
                "reason": reason
            }
        else:
            valid_ids = [z["zone_id"] for z in SUPPORTED_FAIYUM_ZONES]
            if zone_id not in valid_ids:
                raise ValueError(f"Invalid zone identifier '{zone_id}'. Supported zones: {valid_ids}")
            
            set_kill_switch(self.conn, f"KILL_SWITCH:ZONE:{zone_id}", not is_active, reason, actor_id)
            return {
                "status": "ZONE_UPDATED",
                "zone_id": zone_id,
                "is_active": is_active,
                "reason": reason
            }
