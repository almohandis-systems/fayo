import uuid
import sqlite3
from typing import Optional, Dict, Any, List
from fayo_core.shared.domain.errors import NotFoundError, ConflictError
from fayo_core.shared.infra.audit import log_audit_trail

class CatalogService:
    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn

    def create_merchant(
        self,
        name: str,
        merchant_type: str,
        zone_id: str,
        lat: float,
        lng: float,
        is_platform_owned: bool = False,
        commission_rate: float = 0.15,
        max_prep_time_minutes: int = 30,
        tenant_id: str = "EGY-FYM"
    ) -> Dict[str, Any]:
        merchant_id = str(uuid.uuid4())
        cur = self.conn.cursor()
        cur.execute("""
            INSERT INTO commerce_merchants (
                merchant_id, tenant_id, zone_id, name, merchant_type,
                is_platform_owned, commission_rate, lat, lng, is_open, max_prep_time_minutes
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)
        """, (
            merchant_id, tenant_id, zone_id, name, merchant_type,
            1 if is_platform_owned else 0, commission_rate, lat, lng, max_prep_time_minutes
        ))

        log_audit_trail(
            conn=self.conn,
            trace_id=str(uuid.uuid4()),
            actor_id="SYSTEM",
            actor_type="SYSTEM",
            action="MERCHANT_CREATED",
            entity_type="MERCHANT",
            entity_id=merchant_id,
            decision_reason="New merchant onboarded",
            input_payload={"name": name, "zone_id": zone_id, "platform_owned": is_platform_owned}
        )

        return {
            "merchant_id": merchant_id,
            "name": name,
            "merchant_type": merchant_type,
            "zone_id": zone_id,
            "is_platform_owned": is_platform_owned,
            "commission_rate": commission_rate,
            "lat": lat,
            "lng": lng
        }

    def add_sku(
        self,
        merchant_id: str,
        category: str,
        name: str,
        price: float,
        initial_qty: int
    ) -> Dict[str, Any]:
        cur = self.conn.cursor()
        cur.execute("SELECT merchant_id FROM commerce_merchants WHERE merchant_id = ?", (merchant_id,))
        if not cur.fetchone():
            raise NotFoundError("Merchant", merchant_id)

        sku_id = str(uuid.uuid4())
        cur.execute("""
            INSERT INTO commerce_skus (sku_id, merchant_id, category, name, price, is_available)
            VALUES (?, ?, ?, ?, ?, 1)
        """, (sku_id, merchant_id, category, name, price))

        cur.execute("""
            INSERT INTO commerce_inventories (sku_id, available_qty, reserved_qty, version)
            VALUES (?, ?, 0, 1)
        """, (sku_id, initial_qty))

        return {
            "sku_id": sku_id,
            "merchant_id": merchant_id,
            "name": name,
            "price": price,
            "available_qty": initial_qty
        }

    def reserve_inventory_atomic(self, sku_id: str, requested_qty: int):
        cur = self.conn.cursor()
        cur.execute("""
            UPDATE commerce_inventories
            SET available_qty = available_qty - ?,
                reserved_qty = reserved_qty + ?,
                version = version + 1,
                updated_at = datetime('now', 'utc')
            WHERE sku_id = ? AND available_qty >= ?
        """, (requested_qty, requested_qty, sku_id, requested_qty))

        if cur.rowcount == 0:
            cur.execute("SELECT available_qty FROM commerce_inventories WHERE sku_id = ?", (sku_id,))
            row = cur.fetchone()
            available = row["available_qty"] if row else 0
            raise ConflictError(
                title="Inventory Unavailable",
                detail=f"SKU '{sku_id}' has only {available} units available, requested {requested_qty}."
            )

    def release_inventory_atomic(self, sku_id: str, qty: int):
        cur = self.conn.cursor()
        cur.execute("""
            UPDATE commerce_inventories
            SET available_qty = available_qty + ?,
                reserved_qty = reserved_qty - ?,
                version = version + 1,
                updated_at = datetime('now', 'utc')
            WHERE sku_id = ? AND reserved_qty >= ?
        """, (qty, qty, sku_id, qty))

    def commit_inventory_atomic(self, sku_id: str, qty: int):
        cur = self.conn.cursor()
        cur.execute("""
            UPDATE commerce_inventories
            SET reserved_qty = reserved_qty - ?,
                version = version + 1,
                updated_at = datetime('now', 'utc')
            WHERE sku_id = ? AND reserved_qty >= ?
        """, (qty, qty, sku_id, qty))
