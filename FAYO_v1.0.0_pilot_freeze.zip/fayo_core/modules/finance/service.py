import uuid
import sqlite3
from typing import List, Dict, Any, Optional
from fayo_core.shared.domain.errors import (
    NotFoundError, ConflictError, ForbiddenError
)
from fayo_core.shared.infra.audit import log_audit_trail
from fayo_core.shared.infra.outbox import write_outbox_event

class FinancialLedgerService:
    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn

    def get_or_create_account(
        self,
        entity_type: str, # PLATFORM, MERCHANT, COURIER, CUSTOMER
        entity_id: str,
        account_type: str, # ASSET, LIABILITY, EQUITY, REVENUE, EXPENSE
        account_code: str  # standard machine code: COURIER_CASH, COURIER_EARNINGS, MERCHANT_PAYABLE, etc.
    ) -> Dict[str, Any]:
        cur = self.conn.cursor()
        cur.execute("""
            SELECT account_id, account_number, account_name, account_type
            FROM finance_accounts
            WHERE entity_type = ? AND entity_id = ? AND account_name = ?
        """, (entity_type, entity_id, account_code))
        row = cur.fetchone()
        if row:
            return dict(row)

        account_id = str(uuid.uuid4())
        account_number = f"{entity_type[:3]}-{account_type[:3]}-{uuid.uuid4().hex[:6].upper()}"

        cur.execute("""
            INSERT INTO finance_accounts (
                account_id, account_number, account_name, account_type,
                currency, entity_type, entity_id, is_active
            ) VALUES (?, ?, ?, ?, 'EGP', ?, ?, 1)
        """, (account_id, account_number, account_code, account_type, entity_type, entity_id))

        return {
            "account_id": account_id,
            "account_number": account_number,
            "account_name": account_code,
            "account_type": account_type
        }

    def post_journal_entry(
        self,
        reference_type: str,
        reference_id: str,
        description: str,
        postings: List[Dict[str, Any]],
        created_by: str = "SYSTEM"
    ) -> str:
        total_dr = 0.0
        total_cr = 0.0

        for p in postings:
            amt = round(float(p["amount"]), 4)
            if amt <= 0:
                raise ConflictError("Invalid Posting Amount", "Posting amounts must be strictly positive.")
            if p["direction"] == "DR":
                total_dr += amt
            elif p["direction"] == "CR":
                total_cr += amt
            else:
                raise ConflictError("Invalid Direction", f"Direction must be 'DR' or 'CR', got '{p['direction']}'")

        if abs(total_dr - total_cr) > 0.001:
            raise ConflictError(
                title="Unbalanced Journal Entry",
                detail=f"Debits ({total_dr:.4f} EGP) do not balance with Credits ({total_cr:.4f} EGP)."
            )

        cur = self.conn.cursor()
        entry_id = str(uuid.uuid4())
        cur.execute("""
            INSERT INTO finance_journal_entries (
                entry_id, reference_type, reference_id, description, created_by
            ) VALUES (?, ?, ?, ?, ?)
        """, (entry_id, reference_type, reference_id, description, created_by))

        for p in postings:
            posting_id = str(uuid.uuid4())
            cur.execute("""
                INSERT INTO finance_postings (
                    posting_id, entry_id, account_id, amount, direction
                ) VALUES (?, ?, ?, ?, ?)
            """, (posting_id, entry_id, p["account_id"], round(p["amount"], 4), p["direction"]))

        write_outbox_event(
            self.conn,
            aggregate_type="LEDGER",
            aggregate_id=entry_id,
            event_type="ledger.entry_posted",
            payload={
                "entry_id": entry_id,
                "reference_type": reference_type,
                "reference_id": reference_id,
                "total_dr": total_dr,
                "total_cr": total_cr
            }
        )

        return entry_id

    def process_order_delivered_settlement(
        self,
        order_id: str,
        courier_id: str,
        cash_collected: float
    ) -> str:
        cur = self.conn.cursor()
        cur.execute("""
            SELECT o.merchant_id, o.items_subtotal, o.delivery_fee, o.total_amount,
                   m.commission_rate, m.name as merchant_name
            FROM orders_orders o
            JOIN commerce_merchants m ON o.merchant_id = m.merchant_id
            WHERE o.order_id = ?
        """, (order_id,))
        order = cur.fetchone()
        if not order:
            raise NotFoundError("Order", order_id)

        gross_total = round(order["total_amount"], 2)
        items_subtotal = round(order["items_subtotal"], 2)
        delivery_fee = round(order["delivery_fee"], 2)
        commission_rate = order["commission_rate"]

        commission = round(items_subtotal * commission_rate, 2)
        merchant_payable = round(items_subtotal - commission, 2)
        courier_earning = round(delivery_fee * 0.80, 2)
        platform_delivery_margin = round(delivery_fee - courier_earning, 2)

        # Exact standardized account codes
        courier_cash_acc = self.get_or_create_account("COURIER", courier_id, "ASSET", "COURIER_CASH")
        courier_earning_acc = self.get_or_create_account("COURIER", courier_id, "LIABILITY", "COURIER_EARNINGS")
        merchant_payable_acc = self.get_or_create_account("MERCHANT", order["merchant_id"], "LIABILITY", "MERCHANT_PAYABLE")
        platform_comm_acc = self.get_or_create_account("PLATFORM", "FAYO_HEADQUARTERS", "REVENUE", "PLATFORM_COMMISSION")
        platform_fee_acc = self.get_or_create_account("PLATFORM", "FAYO_HEADQUARTERS", "REVENUE", "PLATFORM_DELIVERY_MARGIN")

        postings = [
            {"account_id": courier_cash_acc["account_id"], "amount": gross_total, "direction": "DR"},
            {"account_id": merchant_payable_acc["account_id"], "amount": merchant_payable, "direction": "CR"},
            {"account_id": courier_earning_acc["account_id"], "amount": courier_earning, "direction": "CR"},
            {"account_id": platform_comm_acc["account_id"], "amount": commission, "direction": "CR"},
            {"account_id": platform_fee_acc["account_id"], "amount": platform_delivery_margin, "direction": "CR"},
        ]

        entry_id = self.post_journal_entry(
            reference_type="ORDER_PAYMENT_COD",
            reference_id=order_id,
            description=f"COD Settlement for order {order_id}",
            postings=postings
        )

        log_audit_trail(
            conn=self.conn,
            trace_id=str(uuid.uuid4()),
            actor_id="SYSTEM",
            actor_type="FINANCE_ENGINE",
            action="ORDER_SETTLEMENT_RECORDED",
            entity_type="ORDER",
            entity_id=order_id,
            decision_reason="Double-entry ledger settlement generated automatically",
            input_payload={"gross": gross_total, "merchant_net": merchant_payable, "courier_net": courier_earning}
        )

        return entry_id

    def process_courier_cash_remittance(
        self,
        courier_id: str,
        amount_remitted: float,
        clearing_agent_id: str = "FAYO_MAIN_AGENT"
    ) -> str:
        courier_cash_acc = self.get_or_create_account("COURIER", courier_id, "ASSET", "COURIER_CASH")
        clearing_acc = self.get_or_create_account("PLATFORM", clearing_agent_id, "ASSET", "CLEARING_ACCOUNT")

        postings = [
            {"account_id": clearing_acc["account_id"], "amount": amount_remitted, "direction": "DR"},
            {"account_id": courier_cash_acc["account_id"], "amount": amount_remitted, "direction": "CR"},
        ]

        return self.post_journal_entry(
            reference_type="COURIER_REMITTANCE",
            reference_id=courier_id,
            description=f"Cash remittance deposited by courier {courier_id}",
            postings=postings
        )

    def get_account_balance(self, account_id: str) -> float:
        cur = self.conn.cursor()
        cur.execute("SELECT account_type FROM finance_accounts WHERE account_id = ?", (account_id,))
        row = cur.fetchone()
        if not row:
            raise NotFoundError("Account", account_id)
        
        acc_type = row["account_type"]
        cur.execute("""
            SELECT 
                COALESCE(SUM(CASE WHEN direction = 'DR' THEN amount ELSE 0 END), 0.0) as total_dr,
                COALESCE(SUM(CASE WHEN direction = 'CR' THEN amount ELSE 0 END), 0.0) as total_cr
            FROM finance_postings
            WHERE account_id = ?
        """, (account_id,))
        data = cur.fetchone()
        dr = data["total_dr"]
        cr = data["total_cr"]

        if acc_type in ("ASSET", "EXPENSE"):
            return round(dr - cr, 4)
        else:
            return round(cr - dr, 4)

    def process_order_refund_reversal(
        self,
        order_id: str,
        refund_type: str, # FULL or PARTIAL
        refund_amount: float,
        reason: str,
        actor_id: str
    ) -> str:
        cur = self.conn.cursor()
        cur.execute("""
            SELECT o.merchant_id, o.items_subtotal, o.delivery_fee, o.total_amount,
                   o.order_status, m.commission_rate, m.name as merchant_name
            FROM orders_orders o
            JOIN commerce_merchants m ON o.merchant_id = m.merchant_id
            WHERE o.order_id = ?
        """, (order_id,))
        order = cur.fetchone()
        if not order:
            raise NotFoundError("Order", order_id)

        gross_total = round(order["total_amount"], 2)
        if refund_amount <= 0 or refund_amount > gross_total:
            raise ConflictError("Invalid Refund Amount", f"Refund amount ({refund_amount} EGP) must be positive and <= total order ({gross_total} EGP).")

        # Proportional refund calculation
        ratio = refund_amount / gross_total
        merchant_deduction = round(order["items_subtotal"] * (1 - order["commission_rate"]) * ratio, 2)
        commission_reversal = round(order["items_subtotal"] * order["commission_rate"] * ratio, 2)
        delivery_margin_reversal = round(order["delivery_fee"] * 0.20 * ratio, 2)
        courier_deduction = round(order["delivery_fee"] * 0.80 * ratio, 2)

        # Accounts
        merchant_payable_acc = self.get_or_create_account("MERCHANT", order["merchant_id"], "LIABILITY", "MERCHANT_PAYABLE")
        platform_comm_acc = self.get_or_create_account("PLATFORM", "FAYO_HEADQUARTERS", "REVENUE", "PLATFORM_COMMISSION")
        platform_fee_acc = self.get_or_create_account("PLATFORM", "FAYO_HEADQUARTERS", "REVENUE", "PLATFORM_DELIVERY_MARGIN")
        customer_refund_acc = self.get_or_create_account("CUSTOMER", "REFUND_CLEARING", "LIABILITY", "CUSTOMER_REFUND_PAYABLE")

        # Invariant check:
        # Reversal debits liabilities/revenues, credits refund clearing payable
        # sum(DR) = merchant_deduction + commission_reversal + delivery_margin_reversal + courier_deduction = refund_amount
        postings = [
            {"account_id": merchant_payable_acc["account_id"], "amount": merchant_deduction, "direction": "DR"},
            {"account_id": platform_comm_acc["account_id"], "amount": commission_reversal, "direction": "DR"},
            {"account_id": platform_fee_acc["account_id"], "amount": delivery_margin_reversal, "direction": "DR"},
            {"account_id": customer_refund_acc["account_id"], "amount": refund_amount, "direction": "CR"},
        ]
        # Balance out any rounding cent difference into platform margin
        dr_sum = sum(p["amount"] for p in postings if p["direction"] == "DR")
        diff = round(refund_amount - dr_sum, 4)
        if diff != 0:
            postings.append({"account_id": platform_fee_acc["account_id"], "amount": abs(diff), "direction": "DR" if diff > 0 else "CR"})

        entry_id = self.post_journal_entry(
            reference_type=f"ORDER_REFUND_{refund_type}",
            reference_id=order_id,
            description=f"Reversal entry for {refund_type} refund on order {order_id}. Reason: {reason}",
            postings=postings,
            created_by=actor_id
        )

        new_status = "REFUNDED" if (refund_type == "FULL" or refund_amount >= gross_total) else "PARTIALLY_REFUNDED"
        cur.execute("UPDATE orders_orders SET order_status = ?, updated_at = datetime('now', 'utc') WHERE order_id = ?", (new_status, order_id))

        log_audit_trail(
            conn=self.conn,
            trace_id=str(uuid.uuid4()),
            actor_id=actor_id,
            actor_type="ADMIN",
            action=f"ORDER_{new_status}",
            entity_type="ORDER",
            entity_id=order_id,
            decision_reason=reason,
            input_payload={"refund_amount": refund_amount, "type": refund_type}
        )

        return entry_id
