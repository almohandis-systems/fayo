import uuid
import sqlite3
from typing import Dict, Any, Optional
from fayo_core.shared.infra.audit import log_audit_trail
from fayo_core.shared.infra.outbox import register_event_handler

class NotificationService:
    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn

    def send_notification(
        self,
        recipient_phone: str,
        template_type: str,
        params: Dict[str, Any],
        channel: str = "SMS"
    ) -> Dict[str, Any]:
        cur = self.conn.cursor()
        notif_id = str(uuid.uuid4())

        # Authentic Arabic templates for Faiyum operations
        if template_type == "ORDER_CONFIRMED":
            body = (
                f"فايو: تم استلام طلبك رقم {params.get('order_number')} بنجاح! "
                f"إجمالي الطلب: {params.get('total_amount'):.2f} ج.م. المتجر يجهز طلبك الآن."
            )
        elif template_type == "DISPATCH_ASSIGNED":
            body = (
                f"فايو: المندوب تم إسناده لطلبك رقم {params.get('order_number')}. "
                f"رمز التحقق السري للاستلام (OTP): [{params.get('raw_otp')}]. لا تشارك الرمز إلا عند الاستلام الفعلي."
            )
        elif template_type == "ORDER_DELIVERED":
            body = (
                f"فايو: تم تسليم طلبك رقم {params.get('order_number')} بنجاح. "
                "شكراً لتسوقك مع فايو — منظومة الفيوم للتجارة واللوجستيات."
            )
        else:
            body = f"فايو: إشعار بخصوص طلبك - {params}"

        cur.execute("""
            INSERT INTO notification_logs (
                notification_id, recipient_phone, channel, template_type, message_body, status
            ) VALUES (?, ?, ?, ?, ?, 'SENT')
        """, (notif_id, recipient_phone, channel, template_type, body))

        log_audit_trail(
            conn=self.conn,
            trace_id=str(uuid.uuid4()),
            actor_id="NOTIFICATION_SERVICE",
            actor_type="SYSTEM",
            action="NOTIFICATION_SENT",
            entity_type="NOTIFICATION",
            entity_id=notif_id,
            decision_reason=f"Automated notification for {template_type}",
            input_payload={"phone": recipient_phone, "channel": channel, "type": template_type}
        )

        return {
            "notification_id": notif_id,
            "recipient_phone": recipient_phone,
            "channel": channel,
            "template_type": template_type,
            "message_body": body,
            "status": "SENT"
        }
