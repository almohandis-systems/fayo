import hashlib
import uuid
import sqlite3
from typing import List, Optional, Dict, Any
from fayo_core.shared.domain.errors import (
    NotFoundError, ConflictError, UnauthorizedError, ForbiddenError
)
from fayo_core.shared.infra.audit import log_audit_trail

SALT = "fayo_secure_salt_2026_faiyum"

def hash_password(password: str) -> str:
    return hashlib.sha256((password + SALT).encode('utf-8')).hexdigest()

class IAMService:
    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn

    def register_user(
        self,
        phone_number: str,
        full_name: str,
        password: str,
        zone_id: str,
        role_name: str = "CUSTOMER",
        device_fingerprint: Optional[str] = None,
        tenant_id: str = "EGY-FYM",
        governorate_code: str = "FYM"
    ) -> Dict[str, Any]:
        cur = self.conn.cursor()
        cur.execute("SELECT user_id FROM iam_users WHERE phone_number = ?", (phone_number,))
        if cur.fetchone():
            raise ConflictError("User Already Exists", f"Phone number '{phone_number}' is already registered.")

        cur.execute("SELECT role_name FROM iam_roles WHERE role_name = ?", (role_name,))
        if not cur.fetchone():
            raise NotFoundError("Role", role_name)

        user_id = str(uuid.uuid4())
        pwd_hash = hash_password(password)

        cur.execute("""
            INSERT INTO iam_users (
                user_id, tenant_id, phone_number, full_name, password_hash,
                governorate_code, zone_id, device_fingerprint, is_active
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)
        """, (user_id, tenant_id, phone_number, full_name, pwd_hash, governorate_code, zone_id, device_fingerprint))

        cur.execute("INSERT INTO iam_user_roles (user_id, role_name) VALUES (?, ?)", (user_id, role_name))

        log_audit_trail(
            conn=self.conn,
            trace_id=str(uuid.uuid4()),
            actor_id=user_id,
            actor_type="USER",
            action="USER_REGISTERED",
            entity_type="USER",
            entity_id=user_id,
            decision_reason="New account registration",
            input_payload={"phone": phone_number, "role": role_name, "zone": zone_id}
        )

        return {
            "user_id": user_id,
            "full_name": full_name,
            "phone_number": phone_number,
            "role": role_name,
            "zone_id": zone_id
        }

    def authenticate_user(
        self,
        phone_number: str,
        password: str,
        device_fingerprint: Optional[str] = None
    ) -> Dict[str, Any]:
        cur = self.conn.cursor()
        cur.execute("""
            SELECT user_id, full_name, password_hash, zone_id, is_active, device_fingerprint
            FROM iam_users
            WHERE phone_number = ?
        """, (phone_number,))
        user = cur.fetchone()

        if not user or user["password_hash"] != hash_password(password):
            raise UnauthorizedError("Invalid phone number or password.")

        if user["is_active"] != 1:
            raise ForbiddenError("User account is inactive or suspended.")

        user_id = user["user_id"]
        cur.execute("SELECT role_name FROM iam_user_roles WHERE user_id = ?", (user_id,))
        roles = [r["role_name"] for r in cur.fetchall()]

        if device_fingerprint and user["device_fingerprint"] and user["device_fingerprint"] != device_fingerprint:
            log_audit_trail(
                conn=self.conn,
                trace_id=str(uuid.uuid4()),
                actor_id=user_id,
                actor_type="USER",
                action="DEVICE_FINGERPRINT_MISMATCH_LOGIN",
                entity_type="USER",
                entity_id=user_id,
                decision_reason="Login from unrecognized device hardware",
                input_payload={"new_device": device_fingerprint, "registered_device": user["device_fingerprint"]}
            )

        return {
            "user_id": user_id,
            "full_name": user["full_name"],
            "roles": roles,
            "zone_id": user["zone_id"]
        }

    def assign_role(self, actor_user_id: str, target_user_id: str, new_role: str):
        cur = self.conn.cursor()
        cur.execute("SELECT role_name FROM iam_user_roles WHERE user_id = ? AND role_name = 'SUPER_ADMIN'", (actor_user_id,))
        if not cur.fetchone():
            raise ForbiddenError("Only SUPER_ADMIN can assign or escalate roles.")

        cur.execute("SELECT role_name FROM iam_roles WHERE role_name = ?", (new_role,))
        if not cur.fetchone():
            raise NotFoundError("Role", new_role)

        cur.execute("INSERT OR IGNORE INTO iam_user_roles (user_id, role_name) VALUES (?, ?)", (target_user_id, new_role))

        log_audit_trail(
            conn=self.conn,
            trace_id=str(uuid.uuid4()),
            actor_id=actor_user_id,
            actor_type="ADMIN",
            action="ROLE_ASSIGNED",
            entity_type="USER",
            entity_id=target_user_id,
            decision_reason=f"Role {new_role} assigned by administrator",
            input_payload={"assigned_role": new_role}
        )

    def authorize(self, user_id: str, allowed_roles: List[str], required_zone: Optional[str] = None):
        cur = self.conn.cursor()
        cur.execute("SELECT role_name FROM iam_user_roles WHERE user_id = ?", (user_id,))
        user_roles = [r["role_name"] for r in cur.fetchall()]

        if "SUPER_ADMIN" in user_roles:
            return True

        has_role = any(role in allowed_roles for role in user_roles)
        if not has_role:
            raise ForbiddenError(f"User requires one of the roles: {allowed_roles}")

        if required_zone:
            cur.execute("SELECT zone_id FROM iam_users WHERE user_id = ?", (user_id,))
            user = cur.fetchone()
            if not user or user["zone_id"] != required_zone:
                raise ForbiddenError(f"User is restricted from accessing zone '{required_zone}'.")

        return True
