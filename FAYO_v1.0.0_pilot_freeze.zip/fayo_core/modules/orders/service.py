import uuid
import math
import sqlite3
from typing import List, Dict, Any, Optional
from fayo_core.shared.domain.errors import (
    NotFoundError, ConflictError, ForbiddenError, PolicyViolationError
)
from fayo_core.shared.infra.audit import log_audit_trail
from fayo_core.shared.infra.outbox import write_outbox_event
from fayo_core.shared.infra.idempotency import check_or_acquire_idempotency, resolve_idempotency
from fayo_core.shared.infra.policy_engine import validate_policy_order_creation
from fayo_core.modules.catalog.service import CatalogService

VALID_STATE_TRANSITIONS = {
    "CREATED": ["ACCEPTED", "CANCELLED", "EXPIRED"],
    "ACCEPTED": ["PREPARING", "CANCELLED", "NO_COURIER_FOUND"],
    "PREPARING": ["READY_FOR_PICKUP", "CANCELLED"],
    "READY_FOR_PICKUP": ["IN_TRANSIT", "COURIER_REJECTED", "NO_COURIER_FOUND", "CANCELLED"],
    "COURIER_REJECTED": ["READY_FOR_PICKUP", "NO_COURIER_FOUND", "CANCELLED"],
    "NO_COURIER_FOUND": ["READY_FOR_PICKUP", "CANCELLED"],
    "IN_TRANSIT": ["DELIVERED", "FAILED_DELIVERY", "CUSTOMER_UNAVAILABLE", "DISPUTED"],
    "CUSTOMER_UNAVAILABLE": ["IN_TRANSIT", "RETURNED"],
    "FAILED_DELIVERY": ["RETURNED", "DISPUTED"],
    "RETURNED": ["CANCELLED", "REFUNDED"],
    "DELIVERED": ["DISPUTED", "REFUNDED", "PARTIALLY_REFUNDED"],
    "DISPUTED": ["REFUNDED", "PARTIALLY_REFUNDED", "DELIVERED"],
    "CANCELLED": [],
    "EXPIRED": [],
    "REFUNDED": [],
    "PARTIALLY_REFUNDED": ["REFUNDED"]
}

def calculate_haversine_distance_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    R = 6371.0 # Earth radius in km
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = math.sin(dlat / 2)**2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon / 2)**2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return R * c

class OrderService:
    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn
        self.catalog = CatalogService(conn)

    def place_order(
        self,
        customer_id: str,
        merchant_id: str,
        items: List[Dict[str, Any]], # [{"sku_id": "...", "quantity": 2}]
        delivery_address: str,
        delivery_lat: float,
        delivery_lng: float,
        payment_method: str = "COD",
        idempotency_key: Optional[str] = None
    ) -> Dict[str, Any]:
        cur = self.conn.cursor()

        # 1. Idempotency Check
        if idempotency_key:
            cached = check_or_acquire_idempotency(
                self.conn,
                key=idempotency_key,
                user_id=customer_id,
                request_payload={
                    "merchant_id": merchant_id,
                    "items": items,
                    "delivery_address": delivery_address,
                    "delivery_lat": delivery_lat,
                    "delivery_lng": delivery_lng,
                    "payment_method": payment_method
                }
            )
            if cached:
                return cached[1]

        # 2. Validate Customer & Merchant
        cur.execute("SELECT user_id FROM iam_users WHERE user_id = ?", (customer_id,))
        if not cur.fetchone():
            raise NotFoundError("Customer", customer_id)

        cur.execute("SELECT zone_id, lat, lng, is_open FROM commerce_merchants WHERE merchant_id = ?", (merchant_id,))
        merchant = cur.fetchone()
        if not merchant:
            raise NotFoundError("Merchant", merchant_id)
        if merchant["is_open"] != 1:
            raise ConflictError("Merchant Closed", "This merchant is currently closed and not accepting orders.")

        zone_id = merchant["zone_id"]
        dist_km = calculate_haversine_distance_km(merchant["lat"], merchant["lng"], delivery_lat, delivery_lng)

        # 3. Deterministic Item Pricing & Stock Reservation
        items_subtotal = 0.0
        order_items_processed = []

        for it in items:
            sku_id = it["sku_id"]
            qty = it["quantity"]
            if qty <= 0:
                raise ConflictError("Invalid Quantity", f"Quantity for SKU '{sku_id}' must be positive.")

            cur.execute("SELECT name, price, is_available FROM commerce_skus WHERE sku_id = ? AND merchant_id = ?", (sku_id, merchant_id))
            sku = cur.fetchone()
            if not sku:
                raise NotFoundError("SKU", sku_id)
            if sku["is_available"] != 1:
                raise ConflictError("SKU Unavailable", f"SKU '{sku_id}' is currently marked unavailable.")

            # Atomic Inventory Reservation
            self.catalog.reserve_inventory_atomic(sku_id, qty)

            line_total = sku["price"] * qty
            items_subtotal += line_total
            order_items_processed.append({
                "item_id": str(uuid.uuid4()),
                "sku_id": sku_id,
                "name": sku["name"],
                "unit_price": sku["price"],
                "quantity": qty,
                "total_price": line_total
            })

        # 4. Delivery Fee Deterministic Calculation
        # Base fee 12 EGP + 2.5 EGP/km
        delivery_fee = round(12.0 + (dist_km * 2.5), 2)
        total_amount = round(items_subtotal + delivery_fee, 2)

        # 5. Policy Engine Validation
        validate_policy_order_creation(
            self.conn,
            zone_id=zone_id,
            items_count=len(order_items_processed),
            distance_km=dist_km,
            total_amount=total_amount
        )

        # 6. Insert Order Record
        order_id = str(uuid.uuid4())
        order_number = f"FYM-{uuid.uuid4().hex[:8].upper()}"

        cur.execute("""
            INSERT INTO orders_orders (
                order_id, tenant_id, zone_id, customer_id, merchant_id,
                order_number, order_status, payment_method, payment_status,
                items_subtotal, delivery_fee, discount_amount, total_amount,
                delivery_address, delivery_lat, delivery_lng, version
            ) VALUES (?, 'EGY-FYM', ?, ?, ?, ?, 'CREATED', ?, 'PENDING', ?, ?, 0.0, ?, ?, ?, ?, 1)
        """, (
            order_id, zone_id, customer_id, merchant_id, order_number,
            payment_method, items_subtotal, delivery_fee, total_amount,
            delivery_address, delivery_lat, delivery_lng
        ))

        # Insert Items
        for o_it in order_items_processed:
            cur.execute("""
                INSERT INTO orders_items (item_id, order_id, sku_id, name, unit_price, quantity, total_price)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (o_it["item_id"], order_id, o_it["sku_id"], o_it["name"], o_it["unit_price"], o_it["quantity"], o_it["total_price"]))

        # 7. Transactional Outbox Event
        outbox_payload = {
            "order_id": order_id,
            "order_number": order_number,
            "customer_id": customer_id,
            "merchant_id": merchant_id,
            "total_amount": total_amount,
            "zone_id": zone_id
        }
        write_outbox_event(self.conn, "ORDER", order_id, "order.created", outbox_payload)

        # 8. Audit Trail
        log_audit_trail(
            conn=self.conn,
            trace_id=str(uuid.uuid4()),
            actor_id=customer_id,
            actor_type="CUSTOMER",
            action="ORDER_PLACED",
            entity_type="ORDER",
            entity_id=order_id,
            decision_reason="Customer initiated checkout",
            input_payload={"order_number": order_number, "total": total_amount}
        )

        response_data = {
            "order_id": order_id,
            "order_number": order_number,
            "order_status": "CREATED",
            "items_subtotal": items_subtotal,
            "delivery_fee": delivery_fee,
            "total_amount": total_amount,
            "zone_id": zone_id
        }

        # 9. Resolve Idempotency
        if idempotency_key:
            resolve_idempotency(self.conn, idempotency_key, 201, response_data)

        return response_data

    def transition_order_status(
        self,
        order_id: str,
        target_status: str,
        actor_id: str,
        actor_role: str,
        decision_reason: str = "State transition"
    ) -> Dict[str, Any]:
        cur = self.conn.cursor()
        cur.execute("SELECT order_status, version, customer_id, merchant_id, total_amount FROM orders_orders WHERE order_id = ?", (order_id,))
        row = cur.fetchone()
        if not row:
            raise NotFoundError("Order", order_id)

        current_status = row["order_status"]
        allowed = VALID_STATE_TRANSITIONS.get(current_status, [])
        if target_status not in allowed:
            raise ConflictError(
                title="Invalid State Transition",
                detail=f"Cannot transition order from '{current_status}' to '{target_status}'. Allowed transitions: {allowed}"
            )

        # Handle inventory release for terminal non-delivered states
        if target_status in ("CANCELLED", "EXPIRED", "RETURNED") and current_status not in ("DELIVERED", "REFUNDED", "PARTIALLY_REFUNDED"):
            cur.execute("SELECT sku_id, quantity FROM orders_items WHERE order_id = ?", (order_id,))
            for item in cur.fetchall():
                try:
                    self.catalog.release_inventory_atomic(item["sku_id"], item["quantity"])
                except Exception:
                    pass

        # Handle delivered inventory commit
        elif target_status == "DELIVERED":
            cur.execute("SELECT sku_id, quantity FROM orders_items WHERE order_id = ?", (order_id,))
            for item in cur.fetchall():
                self.catalog.commit_inventory_atomic(item["sku_id"], item["quantity"])

        cur.execute("""
            UPDATE orders_orders
            SET order_status = ?,
                version = version + 1,
                updated_at = datetime('now', 'utc')
            WHERE order_id = ?
        """, (target_status, order_id))

        write_outbox_event(
            self.conn,
            aggregate_type="ORDER",
            aggregate_id=order_id,
            event_type=f"order.{target_status.lower()}",
            payload={"order_id": order_id, "previous_status": current_status, "new_status": target_status}
        )

        log_audit_trail(
            conn=self.conn,
            trace_id=str(uuid.uuid4()),
            actor_id=actor_id,
            actor_type=actor_role,
            action=f"ORDER_STATUS_CHANGED_{target_status}",
            entity_type="ORDER",
            entity_id=order_id,
            decision_reason=decision_reason,
            state_before={"status": current_status},
            state_after={"status": target_status}
        )

        return {"order_id": order_id, "status": target_status}
