import unittest
import uuid
import sys
sys.path.insert(0, "/home/spark/fayo_project")

from fayo_core.database import init_db, db_transaction
from fayo_core.modules.iam.service import IAMService
from fayo_core.modules.catalog.service import CatalogService
from fayo_core.modules.orders.service import OrderService
from fayo_core.shared.domain.errors import ConflictError

class TestOrders(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        init_db()

    def setUp(self):
        with db_transaction() as conn:
            iam = IAMService(conn)
            self.customer = iam.register_user(
                phone_number=f"010{uuid.uuid4().hex[:8]}",
                full_name="Test Customer",
                password="password123",
                zone_id="FYM-SINNURIS"
            )

            cat = CatalogService(conn)
            self.merchant = cat.create_merchant("Al-Fayoum Grill", "RESTAURANT", "FYM-SINNURIS", 29.410, 30.860)
            self.sku = cat.add_sku(self.merchant["merchant_id"], "FOOD", "Grilled Chicken Kilo", 150.0, initial_qty=10)

    def test_order_placement_price_determinism(self):
        with db_transaction() as conn:
            ord_svc = OrderService(conn)
            order = ord_svc.place_order(
                customer_id=self.customer["user_id"],
                merchant_id=self.merchant["merchant_id"],
                items=[{"sku_id": self.sku["sku_id"], "quantity": 2}],
                delivery_address="Sinnuris Center, Main Road",
                delivery_lat=29.415,
                delivery_lng=30.865,
                payment_method="COD"
            )
            self.assertEqual(order["items_subtotal"], 300.0)
            self.assertGreater(order["delivery_fee"], 12.0)
            self.assertEqual(order["order_status"], "CREATED")

    def test_idempotent_order_submission(self):
        idem_key = str(uuid.uuid4())
        cust_id = self.customer["user_id"]
        with db_transaction() as conn:
            ord_svc = OrderService(conn)
            order1 = ord_svc.place_order(
                customer_id=cust_id,
                merchant_id=self.merchant["merchant_id"],
                items=[{"sku_id": self.sku["sku_id"], "quantity": 1}],
                delivery_address="Address 1",
                delivery_lat=29.411,
                delivery_lng=30.861,
                payment_method="COD",
                idempotency_key=idem_key
            )

        with db_transaction() as conn:
            ord_svc = OrderService(conn)
            order2 = ord_svc.place_order(
                customer_id=cust_id,
                merchant_id=self.merchant["merchant_id"],
                items=[{"sku_id": self.sku["sku_id"], "quantity": 1}],
                delivery_address="Address 1",
                delivery_lat=29.411,
                delivery_lng=30.861,
                payment_method="COD",
                idempotency_key=idem_key
            )

        self.assertEqual(order1["order_id"], order2["order_id"])

    def test_order_state_transitions_and_cancellation(self):
        with db_transaction() as conn:
            ord_svc = OrderService(conn)
            order = ord_svc.place_order(
                customer_id=self.customer["user_id"],
                merchant_id=self.merchant["merchant_id"],
                items=[{"sku_id": self.sku["sku_id"], "quantity": 1}],
                delivery_address="Address 2",
                delivery_lat=29.412,
                delivery_lng=30.862,
                payment_method="COD"
            )
            oid = order["order_id"]

            with self.assertRaises(ConflictError):
                ord_svc.transition_order_status(oid, "DELIVERED", "admin", "SUPER_ADMIN")

            ord_svc.transition_order_status(oid, "ACCEPTED", "merchant-staff", "MERCHANT_STAFF")
            ord_svc.transition_order_status(oid, "PREPARING", "merchant-staff", "MERCHANT_STAFF")
            ord_svc.transition_order_status(oid, "CANCELLED", "customer", "CUSTOMER", "Changed mind")

            cur = conn.cursor()
            cur.execute("SELECT order_status FROM orders_orders WHERE order_id = ?", (oid,))
            self.assertEqual(cur.fetchone()["order_status"], "CANCELLED")

if __name__ == "__main__":
    unittest.main()
