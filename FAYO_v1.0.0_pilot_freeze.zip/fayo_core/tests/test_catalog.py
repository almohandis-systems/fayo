import unittest
import uuid
import sys
import threading
sys.path.insert(0, "/home/spark/fayo_project")

from fayo_core.database import init_db, db_transaction
from fayo_core.modules.catalog.service import CatalogService
from fayo_core.shared.domain.errors import ConflictError

class TestCatalog(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        init_db()

    def test_merchant_and_sku_creation(self):
        with db_transaction() as conn:
            catalog = CatalogService(conn)
            merchant = catalog.create_merchant(
                name="Khair El-Faiyum Farm 1",
                merchant_type="FARM",
                zone_id="FYM-SINNURIS",
                lat=29.4120,
                lng=30.8650,
                is_platform_owned=False,
                commission_rate=0.10
            )
            self.assertTrue(merchant["merchant_id"])

            sku = catalog.add_sku(
                merchant_id=merchant["merchant_id"],
                category="VEGETABLES",
                name="Organic Fayoum Tomatoes 1kg",
                price=20.00,
                initial_qty=50
            )
            self.assertEqual(sku["available_qty"], 50)

    def test_atomic_inventory_reservation_and_concurrency(self):
        # Setup sku with exactly 2 units
        with db_transaction() as conn:
            catalog = CatalogService(conn)
            m = catalog.create_merchant("Quick Store", "GROCERY", "FYM-CITY", 29.308, 30.842)
            sku = catalog.add_sku(m["merchant_id"], "GROCERY", "Last Water Packs", 45.0, initial_qty=2)
            sku_id = sku["sku_id"]

        success_count = 0
        failure_count = 0
        lock = threading.Lock()

        def attempt_buy():
            nonlocal success_count, failure_count
            try:
                with db_transaction() as conn:
                    cat = CatalogService(conn)
                    cat.reserve_inventory_atomic(sku_id, 1)
                with lock:
                    success_count += 1
            except ConflictError:
                with lock:
                    failure_count += 1

        threads = [threading.Thread(target=attempt_buy) for _ in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        # Invariant: exactly 2 must succeed, 8 must fail with ConflictError
        self.assertEqual(success_count, 2)
        self.assertEqual(failure_count, 8)

        # Verify final state in DB
        with db_transaction() as conn:
            cur = conn.cursor()
            cur.execute("SELECT available_qty, reserved_qty FROM commerce_inventories WHERE sku_id = ?", (sku_id,))
            inv = cur.fetchone()
            self.assertEqual(inv["available_qty"], 0)
            self.assertEqual(inv["reserved_qty"], 2)

if __name__ == "__main__":
    unittest.main()
