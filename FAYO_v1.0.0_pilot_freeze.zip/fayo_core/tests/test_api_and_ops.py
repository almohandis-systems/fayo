import unittest
import uuid
import sys
sys.path.insert(0, "/home/spark/fayo_project")

from fastapi.testclient import TestClient
from fayo_core.database import init_db
from fayo_core.api.main import app

class TestAPIAndOps(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        test_db = f"/tmp/fayo_api_{uuid.uuid4().hex}.db"
        import os
        os.environ["FAYO_DB_PATH"] = test_db
        import fayo_core.database
        fayo_core.database.DB_PATH = test_db
        init_db()
        cls.client = TestClient(app)

    def test_full_api_workflow(self):
        # 1. Register Customer
        cust_phone = f"010{uuid.uuid4().hex[:8]}"
        res = self.client.post("/api/v1/auth/register", json={
            "phone_number": cust_phone,
            "full_name": "Karim Fayoum",
            "password": "Password123!",
            "zone_id": "FYM-CITY",
            "role_name": "CUSTOMER"
        })
        self.assertEqual(res.status_code, 201)
        cust_id = res.json()["user_id"]

        # 2. Login Customer
        res = self.client.post("/api/v1/auth/login", json={
            "phone_number": cust_phone,
            "password": "Password123!"
        })
        self.assertEqual(res.status_code, 200)

        # 3. Create Merchant
        res = self.client.post("/api/v1/catalog/merchants", json={
            "name": "Fayoum Lake Restaurant",
            "merchant_type": "RESTAURANT",
            "zone_id": "FYM-CITY",
            "lat": 29.3100,
            "lng": 30.8400,
            "commission_rate": 0.12
        })
        self.assertEqual(res.status_code, 201)
        merch_id = res.json()["merchant_id"]

        # 4. Add SKU
        res = self.client.post("/api/v1/catalog/skus", json={
            "merchant_id": merch_id,
            "category": "SEAFOOD",
            "name": "Lake Qarun Grilled Fish 1kg",
            "price": 140.00,
            "initial_qty": 25
        })
        self.assertEqual(res.status_code, 201)
        sku_id = res.json()["sku_id"]

        # 5. Order Checkout with Idempotency Key
        idem_key = str(uuid.uuid4())
        checkout_payload = {
            "customer_id": cust_id,
            "merchant_id": merch_id,
            "items": [{"sku_id": sku_id, "quantity": 2}],
            "delivery_address": "Kiman Fares, Fayoum",
            "delivery_lat": 29.3120,
            "delivery_lng": 30.8420,
            "payment_method": "COD"
        }
        res = self.client.post("/api/v1/orders/checkout", json=checkout_payload, headers={"Idempotency-Key": idem_key})
        self.assertEqual(res.status_code, 201)
        order_data = res.json()
        order_id = order_data["order_id"]
        self.assertEqual(order_data["items_subtotal"], 280.00) # 2 * 140 EGP

        # 6. Resend Identical Checkout -> Returns Cached Result
        res_cached = self.client.post("/api/v1/orders/checkout", json=checkout_payload, headers={"Idempotency-Key": idem_key})
        self.assertEqual(res_cached.status_code, 201)
        self.assertEqual(res_cached.json()["order_id"], order_id)

        # 7. Resend with Mismatched Payload -> Returns 409 Conflict (RFC 7807)
        res_conflict = self.client.post("/api/v1/orders/checkout", json={
            **checkout_payload, "delivery_address": "Tamiyyah Center"
        }, headers={"Idempotency-Key": idem_key})
        self.assertEqual(res_conflict.status_code, 409)
        self.assertEqual(res_conflict.headers.get("content-type"), "application/problem+json")

        # 8. Order Status Transitions
        res = self.client.patch(f"/api/v1/orders/{order_id}/status", json={
            "target_status": "ACCEPTED",
            "actor_id": "merchant-owner",
            "actor_role": "MERCHANT_OWNER"
        })
        self.assertEqual(res.status_code, 200)

        res = self.client.patch(f"/api/v1/orders/{order_id}/status", json={
            "target_status": "PREPARING",
            "actor_id": "merchant-owner",
            "actor_role": "MERCHANT_OWNER"
        })
        self.assertEqual(res.status_code, 200)

        # 9. Register Courier
        cour_phone = f"011{uuid.uuid4().hex[:8]}"
        res_u = self.client.post("/api/v1/auth/register", json={
            "phone_number": cour_phone,
            "full_name": "Saber Courier",
            "password": "Password123!",
            "zone_id": "FYM-CITY",
            "role_name": "COURIER"
        })
        cour_user_id = res_u.json()["user_id"]

        res = self.client.post("/api/v1/fleet/couriers", json={
            "user_id": cour_user_id,
            "vehicle_type": "MOTORCYCLE",
            "license_plate": "FYM-3344",
            "cod_balance_limit": 2000.00
        })
        self.assertEqual(res.status_code, 201)
        courier_id = res.json()["courier_id"]

        # 10. Update Telemetry
        res = self.client.post("/api/v1/fleet/telemetry", json={
            "courier_id": courier_id,
            "lat": 29.3102,
            "lng": 30.8402,
            "speed_kmh": 22.0,
            "is_mock": False
        })
        self.assertEqual(res.status_code, 200)

        # 11. GPS Spoofing Detection
        res_spoof = self.client.post("/api/v1/fleet/telemetry", json={
            "courier_id": courier_id,
            "lat": 29.3102,
            "lng": 30.8402,
            "speed_kmh": 200.0, # Impossible speed
            "is_mock": False
        })
        self.assertEqual(res_spoof.status_code, 409)

        # 12. Smart Dispatch
        res = self.client.post(f"/api/v1/fleet/dispatch/{order_id}")
        self.assertEqual(res.status_code, 200)
        disp = res.json()
        deliv_id = disp["delivery_id"]
        raw_otp = disp["raw_otp"]

        # 13. Courier Arrive (Geofence test)
        # Outside geofence (>100m) -> 409 Conflict
        res_far = self.client.post("/api/v1/fleet/handshake/arrive", json={
            "delivery_id": deliv_id,
            "courier_id": courier_id,
            "courier_lat": 29.3500, # Far away
            "courier_lng": 30.8800
        })
        self.assertEqual(res_far.status_code, 409)

        # Inside geofence -> 200 OK
        res_near = self.client.post("/api/v1/fleet/handshake/arrive", json={
            "delivery_id": deliv_id,
            "courier_id": courier_id,
            "courier_lat": 29.3101,
            "courier_lng": 30.8401
        })
        self.assertEqual(res_near.status_code, 200)

        # 14. Courier Pickup
        res = self.client.post("/api/v1/fleet/handshake/pickup", json={
            "delivery_id": deliv_id,
            "courier_id": courier_id
        })
        self.assertEqual(res.status_code, 200)

        # 15. Deliver with Wrong OTP -> 403 Forbidden
        res_bad_otp = self.client.post("/api/v1/fleet/handshake/deliver", json={
            "delivery_id": deliv_id,
            "courier_id": courier_id,
            "provided_otp": "000000",
            "cash_collected": order_data["total_amount"]
        })
        self.assertEqual(res_bad_otp.status_code, 403)

        # 16. Deliver with Correct OTP -> 200 OK & Financial Settlement
        res_good_otp = self.client.post("/api/v1/fleet/handshake/deliver", json={
            "delivery_id": deliv_id,
            "courier_id": courier_id,
            "provided_otp": raw_otp,
            "cash_collected": order_data["total_amount"]
        })
        self.assertEqual(res_good_otp.status_code, 200)
        self.assertEqual(res_good_otp.json()["status"], "DELIVERED")

        # 17. Courier Cash Remittance
        res = self.client.post("/api/v1/finance/remittance", json={
            "courier_id": courier_id,
            "amount_remitted": 100.00
        })
        self.assertEqual(res.status_code, 200)

        # 18. Control Tower Dashboard
        res = self.client.get("/api/v1/ops/control-tower")
        self.assertEqual(res.status_code, 200)
        dash = res.json()
        self.assertIn("orders", dash)
        self.assertIn("fleet", dash)
        self.assertIn("financials", dash)
        self.assertEqual(dash["orders"]["by_status"].get("DELIVERED"), 1)
        self.assertGreater(dash["financials"]["platform_accumulated_commission_egp"], 0.0)

        # 19. Process Outbox Batch
        res = self.client.post("/api/v1/ops/outbox/process")
        self.assertEqual(res.status_code, 200)

        # 20. Kill Switch Engagement & Verification
        res = self.client.post("/api/v1/ops/kill-switch", json={
            "switch_key": "KILL_SWITCH:ZONE:FYM-CITY",
            "is_engaged": True,
            "reason": "Emergency Sandstorm in Fayoum City",
            "actor_id": "ops-admin"
        })
        self.assertEqual(res.status_code, 200)

        # Attempting checkout in FYM-CITY now must return 422 PolicyViolation
        res_blocked = self.client.post("/api/v1/orders/checkout", json={
            **checkout_payload,
            "items": [{"sku_id": sku_id, "quantity": 1}]
        }, headers={"Idempotency-Key": str(uuid.uuid4())})
        self.assertEqual(res_blocked.status_code, 422)
        self.assertEqual(res_blocked.json()["title"], "Policy Engine Rejection")

if __name__ == "__main__":
    unittest.main()
