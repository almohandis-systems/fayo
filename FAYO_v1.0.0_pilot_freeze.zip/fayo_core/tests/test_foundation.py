import unittest
import uuid
import sys
sys.path.insert(0, "/home/spark/fayo_project")

from fayo_core.database import init_db, db_transaction
from fayo_core.shared.infra.audit import log_audit_trail
from fayo_core.shared.infra.outbox import write_outbox_event, process_outbox_batch, register_event_handler
from fayo_core.shared.infra.idempotency import check_or_acquire_idempotency, resolve_idempotency
from fayo_core.shared.infra.policy_engine import (
    is_kill_switch_engaged, set_kill_switch, validate_policy_order_creation
)
from fayo_core.shared.domain.errors import (
    IdempotencyConflictError, ConflictError, PolicyViolationError
)

class TestFoundation(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        init_db()

    def test_audit_trail_logging(self):
        with db_transaction() as conn:
            trace_id = str(uuid.uuid4())
            audit_id = log_audit_trail(
                conn=conn,
                trace_id=trace_id,
                actor_id="admin-01",
                actor_type="ADMIN",
                action="UPDATE_CONFIG",
                entity_type="SYSTEM",
                entity_id="GLOBAL",
                decision_reason="Routine maintenance",
                input_payload={"param": 10},
                state_before={"param": 5},
                state_after={"param": 10}
            )
            self.assertGreater(audit_id, 0)
            
            cur = conn.cursor()
            cur.execute("SELECT * FROM audit_system_audit_trail WHERE audit_id = ?", (audit_id,))
            row = cur.fetchone()
            self.assertEqual(row["trace_id"], trace_id)
            self.assertEqual(row["action"], "UPDATE_CONFIG")

    def test_idempotency_workflow(self):
        key = str(uuid.uuid4())
        user_id = str(uuid.uuid4())
        payload = {"items": [{"sku": "A", "qty": 1}]}

        with db_transaction() as conn:
            cached = check_or_acquire_idempotency(conn, key, user_id, payload)
            self.assertIsNone(cached)

        # Second concurrent call while PROCESSING must raise IdempotencyConflictError
        with db_transaction() as conn:
            with self.assertRaises(IdempotencyConflictError):
                check_or_acquire_idempotency(conn, key, user_id, payload)

        # Resolve the key
        with db_transaction() as conn:
            resolve_idempotency(conn, key, 201, {"order_id": "ORD-123"})

        # Third call after RESOLVED should return cached response
        with db_transaction() as conn:
            cached = check_or_acquire_idempotency(conn, key, user_id, payload)
            self.assertIsNotNone(cached)
            code, body = cached
            self.assertEqual(code, 201)
            self.assertEqual(body["order_id"], "ORD-123")

        # Call with same key but DIFFERENT payload must raise ConflictError
        different_payload = {"items": [{"sku": "B", "qty": 99}]}
        with db_transaction() as conn:
            with self.assertRaises(ConflictError):
                check_or_acquire_idempotency(conn, key, user_id, different_payload)

    def test_outbox_and_dlq(self):
        received_events = []
        def sample_handler(payload, headers):
            received_events.append(payload["msg"])

        register_event_handler("test.event.success", sample_handler)

        with db_transaction() as conn:
            event_id = write_outbox_event(
                conn, "TEST", "123", "test.event.success", {"msg": "hello_fayo"}
            )
            self.assertTrue(bool(event_id))

        with db_transaction() as conn:
            processed = process_outbox_batch(conn)
            self.assertGreaterEqual(processed, 1)

        self.assertIn("hello_fayo", received_events)

        # Test failure to DLQ
        def failing_handler(payload, headers):
            raise RuntimeError("Handler failure simulated")

        register_event_handler("test.event.failing", failing_handler)

        with db_transaction() as conn:
            fail_event_id = write_outbox_event(
                conn, "FAIL_TEST", "456", "test.event.failing", {"msg": "will_fail"}
            )

        with db_transaction() as conn:
            processed = process_outbox_batch(conn, max_retries=1)
            cur = conn.cursor()
            cur.execute("SELECT * FROM dead_letter_events WHERE original_event_id = ?", (fail_event_id,))
            dlq_row = cur.fetchone()
            self.assertIsNotNone(dlq_row)
            self.assertEqual(dlq_row["event_type"], "test.event.failing")

    def test_policy_engine_and_kill_switches(self):
        with db_transaction() as conn:
            self.assertFalse(is_kill_switch_engaged(conn, "KILL_SWITCH:ZONE:FYM-ITSA"))
            validate_policy_order_creation(conn, "FYM-ITSA", items_count=5, distance_km=6.0, total_amount=150.0)

            set_kill_switch(conn, "KILL_SWITCH:ZONE:FYM-ITSA", is_engaged=True, reason="Severe storm", engaged_by="admin")
            self.assertTrue(is_kill_switch_engaged(conn, "KILL_SWITCH:ZONE:FYM-ITSA"))

            with self.assertRaises(PolicyViolationError):
                validate_policy_order_creation(conn, "FYM-ITSA", items_count=5, distance_km=6.0, total_amount=150.0)

            set_kill_switch(conn, "KILL_SWITCH:ZONE:FYM-ITSA", is_engaged=False, reason="Weather cleared", engaged_by="admin")
            self.assertFalse(is_kill_switch_engaged(conn, "KILL_SWITCH:ZONE:FYM-ITSA"))

if __name__ == "__main__":
    unittest.main()
