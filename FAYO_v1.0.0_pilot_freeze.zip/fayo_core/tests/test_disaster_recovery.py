import unittest
import uuid
import sys
import time
import os
import sqlite3
sys.path.insert(0, "/home/spark/fayo_project")

from fayo_core.database import init_db, db_transaction, get_db_connection

class TestDisasterRecovery(unittest.TestCase):
    def test_backup_disaster_restore_integrity_verification(self):
        primary_db = f"/tmp/fayo_dr_primary_{uuid.uuid4().hex}.db"
        backup_file = f"/tmp/fayo_dr_backup_{uuid.uuid4().hex}.db"
        
        os.environ["FAYO_DB_PATH"] = primary_db
        import fayo_core.database
        fayo_core.database.DB_PATH = primary_db
        init_db()

        with db_transaction() as conn:
            cur = conn.cursor()
            for i in range(50):
                uid = str(uuid.uuid4())
                cur.execute("INSERT INTO iam_users (user_id, phone_number, full_name, password_hash, zone_id) VALUES (?, ?, ?, 'hash', 'FYM-CITY')",
                            (uid, f"010{i:08d}", f"User {i}"))
            conn.commit()

        with get_db_connection() as conn:
            cur = conn.cursor()
            cur.execute("SELECT COUNT(*) FROM iam_users")
            baseline_users_count = cur.fetchone()[0]
            self.assertEqual(baseline_users_count, 50)

        # 1. Hot Backup
        t_backup_start = time.perf_counter()
        source_conn = sqlite3.connect(primary_db)
        dest_conn = sqlite3.connect(backup_file)
        with dest_conn:
            source_conn.backup(dest_conn)
        dest_conn.close()
        source_conn.close()
        backup_duration_ms = (time.perf_counter() - t_backup_start) * 1000.0

        # 2. Simulate Disaster (Corrupt / Drop tables)
        corrupt_conn = sqlite3.connect(primary_db)
        corrupt_conn.execute("DROP TABLE iam_users;")
        corrupt_conn.execute("DROP TABLE audit_system_audit_trail;")
        corrupt_conn.commit()
        corrupt_conn.close()

        check_conn = sqlite3.connect(primary_db)
        cur = check_conn.cursor()
        cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='iam_users';")
        self.assertIsNone(cur.fetchone())
        check_conn.close()

        # 3. Restore
        t_restore_start = time.perf_counter()
        backup_conn = sqlite3.connect(backup_file)
        restore_target = sqlite3.connect(primary_db)
        with restore_target:
            backup_conn.backup(restore_target)
        backup_conn.close()
        restore_target.close()
        restore_duration_ms = (time.perf_counter() - t_restore_start) * 1000.0

        # 4. Verify post-restore integrity
        restored_conn = sqlite3.connect(primary_db)
        cur = restored_conn.cursor()
        cur.execute("PRAGMA integrity_check;")
        integrity = cur.fetchone()[0]
        self.assertEqual(integrity, "ok")

        cur.execute("SELECT COUNT(*) FROM iam_users;")
        restored_count = cur.fetchone()[0]
        self.assertEqual(restored_count, baseline_users_count)
        restored_conn.close()

if __name__ == "__main__":
    unittest.main()
