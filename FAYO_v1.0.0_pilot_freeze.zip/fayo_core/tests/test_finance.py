import unittest
import uuid
import sys
sys.path.insert(0, "/home/spark/fayo_project")

from fayo_core.database import init_db, db_transaction
from fayo_core.modules.iam.service import IAMService
from fayo_core.modules.catalog.service import CatalogService
from fayo_core.modules.orders.service import OrderService
from fayo_core.modules.logistics.service import LogisticsService
from fayo_core.modules.finance.service import FinancialLedgerService
from fayo_core.shared.domain.errors import ConflictError

class TestFinance(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        init_db()

    def test_unbalanced_entry_rejected(self):
        with db_transaction() as conn:
            fin = FinancialLedgerService(conn)
            acc1 = fin.get_or_create_account("PLATFORM", "P1", "ASSET", "ACC_1")
            acc2 = fin.get_or_create_account("PLATFORM", "P2", "REVENUE", "ACC_2")

            with self.assertRaises(ConflictError):
                fin.post_journal_entry(
                    reference_type="TEST",
                    reference_id="T1",
                    description="Unbalanced",
                    postings=[
                        {"account_id": acc1["account_id"], "amount": 100.0, "direction": "DR"},
                        {"account_id": acc2["account_id"], "amount": 90.0, "direction": "CR"}
                    ]
                )

    def test_order_settlement_and_courier_remittance(self):
        with db_transaction() as conn:
            iam = IAMService(conn)
            cust = iam.register_user(f"010{uuid.uuid4().hex[:8]}", "Client F", "pass", "FYM-CITY")
            cour_user = iam.register_user(f"011{uuid.uuid4().hex[:8]}", "Courier F", "pass", "FYM-CITY", "COURIER")

            cat = CatalogService(conn)
            merch = cat.create_merchant("Farm Store", "FARM", "FYM-CITY", 29.308, 30.842, commission_rate=0.10)
            sku = cat.add_sku(merch["merchant_id"], "FARM", "Cheese 1kg", 100.0, 10)

            ord_svc = OrderService(conn)
            order = ord_svc.place_order(
                customer_id=cust["user_id"],
                merchant_id=merch["merchant_id"],
                items=[{"sku_id": sku["sku_id"], "quantity": 1}],
                delivery_address="Fayoum",
                delivery_lat=29.310,
                delivery_lng=30.844,
                payment_method="COD"
            )
            oid = order["order_id"]
            tot = order["total_amount"]

            log_svc = LogisticsService(conn)
            courier = log_svc.register_courier(cour_user["user_id"], "MOTORCYCLE", "FYM-555")
            cid = courier["courier_id"]

            fin = FinancialLedgerService(conn)
            entry_id = fin.process_order_delivered_settlement(oid, cid, tot)
            self.assertTrue(entry_id)

            c_cash_acc = fin.get_or_create_account("COURIER", cid, "ASSET", "COURIER_CASH")
            bal = fin.get_account_balance(c_cash_acc["account_id"])
            self.assertEqual(bal, tot)

            remit_amt = round(tot / 2.0, 2)
            fin.process_courier_cash_remittance(cid, remit_amt)

            new_bal = fin.get_account_balance(c_cash_acc["account_id"])
            self.assertAlmostEqual(new_bal, tot - remit_amt, places=2)

if __name__ == "__main__":
    unittest.main()
