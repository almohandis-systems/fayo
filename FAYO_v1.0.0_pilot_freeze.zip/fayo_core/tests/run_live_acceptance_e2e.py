import sys
import uuid
import time
import json
sys.path.insert(0, "/home/spark/fayo_project")

from fastapi.testclient import TestClient
from fayo_core.api.main import app
from fayo_core.database import init_db, db_transaction
from fayo_core.modules.iam.service import IAMService
from fayo_core.modules.catalog.service import CatalogService
from fayo_core.modules.orders.service import OrderService
from fayo_core.modules.logistics.service import LogisticsService
from fayo_core.modules.finance.service import FinancialLedgerService

test_db = f"/tmp/fayo_live_acceptance_{uuid.uuid4().hex}.db"
import os
os.environ["FAYO_DB_PATH"] = test_db
import fayo_core.database
fayo_core.database.DB_PATH = test_db
init_db()

client = TestClient(app)

print("="*60)
print("LIVE E2E ACCEPTANCE TEST FOR CENTRAL DELIVERY AREA CONTROL")
print("="*60)

report = {}

with db_transaction() as conn:
    iam = IAMService(conn)
    cat = CatalogService(conn)
    log = LogisticsService(conn)

    # 1. Setup Admin, Customers, Courier, and Merchants in Bandar and Sinnuris
    admin = iam.register_user("01012345678", "Admin Control Tower", "Pass123!", "FYM-CITY", role_name="SUPER_ADMIN")
    cust_bandar = iam.register_user("01022223333", "Bandar Customer", "Pass123!", "FYM-CITY", role_name="CUSTOMER")
    cust_sinnuris = iam.register_user("01044445555", "Sinnuris Customer", "Pass123!", "FYM-SINNURIS", role_name="CUSTOMER")

    # Merchants
    merch_bandar = cat.create_merchant("مطعم كبابجي بندر الفيوم", "RESTAURANT", "FYM-CITY", 29.308, 30.842, commission_rate=0.12)
    sku_bandar = cat.add_sku(merch_bandar["merchant_id"], "MAINS", "وجبة كباب بندر", 150.0, 100)

    merch_sinnuris = cat.create_merchant("مطعم فطير سنورس", "RESTAURANT", "FYM-SINNURIS", 29.408, 30.865, commission_rate=0.10)
    sku_sinnuris = cat.add_sku(merch_sinnuris["merchant_id"], "MAINS", "فطيرة مشلتت سنورس", 90.0, 100)

    # Courier
    courier_u = iam.register_user("01066667777", "كابتن أسامة", "Pass123!", "FYM-CITY", role_name="COURIER")
    courier = log.register_courier(courier_u["user_id"], "MOTORCYCLE", "FYM-5566", 3000.0)
    log.update_courier_telemetry(courier["courier_id"], 29.3085, 30.8415, 15.0, False)

# STEP 1: بندر الفيوم ACTIVE: إنشاء طلب حقيقي → يجب أن ينجح
print("\n--- Step 1: Bandar Active - Place Order ---")
order1_payload = {
    "customer_id": cust_bandar["user_id"],
    "merchant_id": merch_bandar["merchant_id"],
    "items": [{"sku_id": sku_bandar["sku_id"], "quantity": 2}],
    "delivery_address": "بندر الفيوم - لطف الله - شارع الدالي",
    "delivery_lat": 29.310, "delivery_lng": 30.840,
    "payment_method": "COD"
}
idem_key_1 = f"IDEM_{uuid.uuid4().hex}"
res1 = client.post("/api/v1/orders/checkout", json=order1_payload, headers={"Idempotency-Key": idem_key_1})
assert res1.status_code == 201, f"Step 1 failed with {res1.status_code}: {res1.text}"
order1_data = res1.json()
order1_id = order1_data["order_id"]
order1_num = order1_data["order_number"]
print(f"Order 1 Created Successfully: {order1_num} (ID: {order1_id}), Status: {order1_data['order_status']}, Subtotal: {order1_data['items_subtotal']} EGP")
report["step_1"] = {
    "status": "PASS",
    "order_id": order1_id,
    "order_number": order1_num,
    "http_code": res1.status_code,
    "total_amount": order1_data["total_amount"]
}

# STEP 2: أوقف بندر الفيوم من Control Tower: محاولة إنشاء طلب جديد → يجب أن تُرفض من Backend (HTTP 422 PolicyViolationError)
print("\n--- Step 2: Deactivate Bandar - Reject New Order ---")
reason_deact = "إيقاف طوارئ تجريبي لبندر الفيوم بسبب سوء الأحوال الجوية"
res_deact = client.post("/api/v1/ops/delivery-zones/toggle", json={
    "zone_id": "FYM-CITY",
    "is_active": False,
    "reason": reason_deact,
    "actor_id": admin["user_id"]
})
assert res_deact.status_code == 200, f"Deactivation failed: {res_deact.text}"
print(f"Control Tower Deactivation Response: {res_deact.json()}")

# Attempt to create new order in Bandar
order2_payload = {
    "customer_id": cust_bandar["user_id"],
    "merchant_id": merch_bandar["merchant_id"],
    "items": [{"sku_id": sku_bandar["sku_id"], "quantity": 1}],
    "delivery_address": "بندر الفيوم - المسلة",
    "delivery_lat": 29.310, "delivery_lng": 30.840,
    "payment_method": "COD"
}
idem_key_2 = f"IDEM_{uuid.uuid4().hex}"
res2 = client.post("/api/v1/orders/checkout", json=order2_payload, headers={"Idempotency-Key": idem_key_2})
assert res2.status_code == 422, f"Expected 422 but got {res2.status_code}: {res2.text}"
err2_data = res2.json()
assert "Policy Engine Rejection" in err2_data.get("title", ""), f"Unexpected error title: {err2_data}"
assert "ZONE_RESTRICTION" in err2_data.get("detail", ""), f"Unexpected error detail: {err2_data}"
print(f"Backend Rejection Verified: HTTP 422, Title: '{err2_data['title']}', Detail: '{err2_data['detail']}'")
report["step_2"] = {
    "status": "PASS",
    "http_code": res2.status_code,
    "error_title": err2_data["title"],
    "error_detail": err2_data["detail"]
}

# STEP 3: تحقق من الطلب القديم الذي تم إنشاؤه قبل الإيقاف: يستمر طبيعيًا حتى نهاية دورة الطلب
print("\n--- Step 3: Lifecycle Continuation for Existing Order 1 ---")
with db_transaction() as conn:
    ord_svc = OrderService(conn)
    log_svc = LogisticsService(conn)
    fin_svc = FinancialLedgerService(conn)

    # 1. Accept by merchant
    s_acc = ord_svc.transition_order_status(order1_id, "ACCEPTED", merch_bandar["merchant_id"], "MERCHANT", "Accepted by merchant")
    assert s_acc["status"] == "ACCEPTED"
    print(f"Existing Order Status: {s_acc['status']}")

    # 2. Preparing
    s_prep = ord_svc.transition_order_status(order1_id, "PREPARING", merch_bandar["merchant_id"], "MERCHANT", "Cooking meal")
    assert s_prep["status"] == "PREPARING"
    print(f"Existing Order Status: {s_prep['status']}")

    # 3. Smart Dispatch
    dispatch_info = log_svc.assign_smart_dispatch(order1_id)
    raw_otp = dispatch_info["raw_otp"]
    delivery_id = dispatch_info["delivery_id"]
    print(f"Existing Order Dispatched: Delivery ID {delivery_id}, Generated OTP: {raw_otp}")

    # 4. Courier Pickup
    log_svc.courier_arrive_merchant(delivery_id, courier["courier_id"], 29.308, 30.842)
    log_svc.courier_pickup_order(delivery_id, courier["courier_id"])
    print(f"Existing Order Picked Up by Courier")

    # 5. Delivery Handshake with OTP
    deliv_done = log_svc.confirm_delivery_handshake(
        delivery_id=delivery_id,
        courier_id=courier["courier_id"],
        provided_otp=raw_otp,
        cash_collected=order1_data["total_amount"]
    )
    assert deliv_done["status"] == "DELIVERED"
    print(f"Existing Order Delivered: Status {deliv_done['status']}")

    # 6. Financial Ledger Settlement
    entry_id = fin_svc.process_order_delivered_settlement(order1_id, courier["courier_id"], order1_data["total_amount"])
    cur = conn.cursor()
    cur.execute("SELECT SUM(amount) FROM finance_postings WHERE entry_id = ? AND direction = 'DR'", (entry_id,))
    debits = cur.fetchone()[0] or 0.0
    cur.execute("SELECT SUM(amount) FROM finance_postings WHERE entry_id = ? AND direction = 'CR'", (entry_id,))
    credits = cur.fetchone()[0] or 0.0
    assert abs(debits - credits) < 0.001
    print(f"Existing Order Financially Settled: {debits:.2f} EGP DR == {credits:.2f} EGP CR (Balanced)")

report["step_3"] = {
    "status": "PASS",
    "order_id": order1_id,
    "final_status": "DELIVERED",
    "financial_entry_id": entry_id,
    "debits_eq_credits": abs(debits - credits) < 0.001
}

# STEP 4: أعد تشغيل بندر الفيوم: إنشاء طلب جديد → يجب أن ينجح فورًا
print("\n--- Step 4: Reactivate Bandar - Place New Order ---")
reason_react = "استئناف خدمة التوصيل في بندر الفيوم بعد انتهاء فترة الإيقاف"
res_react = client.post("/api/v1/ops/delivery-zones/toggle", json={
    "zone_id": "FYM-CITY",
    "is_active": True,
    "reason": reason_react,
    "actor_id": admin["user_id"]
})
assert res_react.status_code == 200, f"Reactivation failed: {res_react.text}"
print(f"Control Tower Reactivation Response: {res_react.json()}")

order3_payload = {
    "customer_id": cust_bandar["user_id"],
    "merchant_id": merch_bandar["merchant_id"],
    "items": [{"sku_id": sku_bandar["sku_id"], "quantity": 1}],
    "delivery_address": "بندر الفيوم - الحواتم",
    "delivery_lat": 29.310, "delivery_lng": 30.840,
    "payment_method": "COD"
}
idem_key_3 = f"IDEM_{uuid.uuid4().hex}"
res3 = client.post("/api/v1/orders/checkout", json=order3_payload, headers={"Idempotency-Key": idem_key_3})
assert res3.status_code == 201, f"Step 4 checkout failed: {res3.status_code}: {res3.text}"
order3_data = res3.json()
print(f"New Order After Reactivation Created Successfully: {order3_data['order_number']} (Status: {order3_data['order_status']})")
report["step_4"] = {
    "status": "PASS",
    "order_id": order3_data["order_id"],
    "order_number": order3_data["order_number"],
    "http_code": res3.status_code
}

# STEP 5: تحقق من Audit Trail: تسجيل الإيقاف والتشغيل وهوية المنفذ والتوقيت والسبب
print("\n--- Step 5: Verify Audit Trail Logs ---")
with db_transaction() as conn:
    cur = conn.cursor()
    cur.execute("""
        SELECT audit_id, actor_id, actor_type, action, entity_type, entity_id, decision_reason, created_at
        FROM audit_system_audit_trail
        WHERE entity_type = 'DELIVERY_ZONE' AND entity_id = 'FYM-CITY'
        ORDER BY created_at ASC
    """)
    audit_rows = [dict(r) for r in cur.fetchall()]
    assert len(audit_rows) >= 2, f"Expected at least 2 audit rows, got {len(audit_rows)}"
    
    # Row 1: Deactivation
    log_deact = audit_rows[-2]
    assert log_deact["actor_id"] == admin["user_id"]
    assert log_deact["action"] == "DELIVERY_ZONE_TOGGLED"
    assert reason_deact in log_deact["decision_reason"]
    print(f"Audit Row 1 Verified (Deactivation): Action={log_deact['action']}, Actor={log_deact['actor_id']}, Reason='{log_deact['decision_reason']}', Timestamp={log_deact['created_at']}")

    # Row 2: Reactivation
    log_react = audit_rows[-1]
    assert log_react["actor_id"] == admin["user_id"]
    assert log_react["action"] == "DELIVERY_ZONE_TOGGLED"
    assert reason_react in log_react["decision_reason"]
    print(f"Audit Row 2 Verified (Reactivation): Action={log_react['action']}, Actor={log_react['actor_id']}, Reason='{log_react['decision_reason']}', Timestamp={log_react['created_at']}")

report["step_5"] = {
    "status": "PASS",
    "deactivation_audit_id": log_deact["audit_id"],
    "reactivation_audit_id": log_react["audit_id"],
    "actor_id": admin["user_id"]
}

# STEP 6: تحقق من Multi-Tenancy: تغيير نطاق في Tenant لا يؤثر على Tenant آخر
print("\n--- Step 6: Verify Multi-Tenancy & Tenant Boundaries ---")
# 1. While Bandar was stopped, Sinnuris was NOT affected:
# Let's pause Bandar again
client.post("/api/v1/ops/delivery-zones/toggle", json={
    "zone_id": "FYM-CITY", "is_active": False, "reason": "Pause Bandar again", "actor_id": admin["user_id"]
})

# Place order in Sinnuris (FYM-SINNURIS) -> MUST SUCCEED because Sinnuris is active!
order_sinnuris_payload = {
    "customer_id": cust_sinnuris["user_id"],
    "merchant_id": merch_sinnuris["merchant_id"],
    "items": [{"sku_id": sku_sinnuris["sku_id"], "quantity": 1}],
    "delivery_address": "سنورس - ش الجيش",
    "delivery_lat": 29.410, "delivery_lng": 30.866,
    "payment_method": "COD"
}
idem_key_sinnuris = f"IDEM_{uuid.uuid4().hex}"
res_sinnuris = client.post("/api/v1/orders/checkout", json=order_sinnuris_payload, headers={"Idempotency-Key": idem_key_sinnuris})
assert res_sinnuris.status_code == 201, f"Sinnuris order failed with {res_sinnuris.status_code}: {res_sinnuris.text}"
print(f"Tenant Isolation Verified: Order in Sinnuris succeeded ({res_sinnuris.json()['order_number']}) while Bandar was paused!")

# 2. Cross-Tenant IDOR test: Cust_Bandar cannot view Cust_Sinnuris orders
res_cross_cust = client.get(f"/api/v1/customer/{cust_sinnuris['user_id']}/orders", headers={"X-User-Id": cust_bandar["user_id"]})
assert res_cross_cust.status_code == 403
print("Cross-Customer IDOR Protection Verified: HTTP 403 Forbidden")

# 3. Cross-Merchant IDOR test: Merch_Bandar cannot view Merch_Sinnuris orders
res_cross_merch = client.get(f"/api/v1/merchant/{merch_sinnuris['merchant_id']}/orders", headers={"X-Merchant-Id": merch_bandar["merchant_id"]})
assert res_cross_merch.status_code == 403
print("Cross-Merchant IDOR Protection Verified: HTTP 403 Forbidden")

# Restore Bandar to active
client.post("/api/v1/ops/delivery-zones/toggle", json={
    "zone_id": "FYM-CITY", "is_active": True, "reason": "Final Restore", "actor_id": admin["user_id"]
})

report["step_6"] = {
    "status": "PASS",
    "sinnuris_order_succeeded_while_bandar_paused": True,
    "cross_customer_idor_code": res_cross_cust.status_code,
    "cross_merchant_idor_code": res_cross_merch.status_code
}

print("\n" + "="*60)
print("FINAL LIVE ACCEPTANCE SUMMARY:")
print(json.dumps(report, indent=2, ensure_ascii=False))
print("="*60)
