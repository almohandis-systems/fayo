import unittest
import os

class TestPostgresReadiness(unittest.TestCase):
    def test_postgres_schema_ddl_integrity(self):
        sql_path = "/home/spark/fayo_project/fayo_core/fayo_postgres_schema.sql"
        self.assertTrue(os.path.exists(sql_path))
        with open(sql_path, "r") as f:
            sql = f.read()

        # Check all core schemas exist
        for s in ["iam", "commerce", "orders", "fleet", "finance", "audit"]:
            self.assertIn(f"CREATE SCHEMA IF NOT EXISTS {s};", sql)

        # Check strict typing and constraints
        self.assertIn("UUID PRIMARY KEY DEFAULT gen_random_uuid()", sql)
        self.assertIn("TIMESTAMPTZ NOT NULL DEFAULT NOW()", sql)
        self.assertIn("NUMERIC(14, 4) NOT NULL CHECK (amount > 0)", sql)
        self.assertIn("direction VARCHAR(2) NOT NULL CHECK (direction IN ('DR', 'CR'))", sql)
        self.assertIn("REFERENCES finance.journal_entries(entry_id) ON DELETE RESTRICT", sql)
        self.assertIn("REFERENCES finance.accounts(account_id) ON DELETE RESTRICT", sql)

        # Check PostGIS and UUID extension declarations
        self.assertIn('CREATE EXTENSION IF NOT EXISTS "uuid-ossp";', sql)
        self.assertIn('CREATE EXTENSION IF NOT EXISTS "postgis";', sql)

if __name__ == "__main__":
    unittest.main()
