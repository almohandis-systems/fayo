import unittest
import uuid
import sys
sys.path.insert(0, "/home/spark/fayo_project")

from fayo_core.database import init_db, db_transaction
from fayo_core.modules.iam.service import IAMService
from fayo_core.modules.catalog.service import CatalogService
from fayo_core.modules.orders.service import OrderService
from fayo_core.modules.logistics.service import LogisticsService
from fayo_core.shared.domain.errors import ConflictError, ForbiddenError

class TestLogistics(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        init_db()

    def setUp(self):
        with db_transaction() as conn:
            iam = IAMService(conn)
            self.cust = iam.register_user(f"010{uuid.uuid4().hex[:8]}", "Client A", "pass", "FYM-CITY")
            self.courier_user = iam.register_user(f"011{uuid.uuid4().hex[:8]}", "Courier B", "pass", "FYM-CITY", "COURIER")

            cat = CatalogService(conn)
            self.merchant = cat.create_merchant("City Supermarket", "GROCERY", "FYM-CITY", 29.308, 30.842)
            self.sku = cat.add_sku(self.merchant["merchant_id"], "PANTRY", "Rice 5kg", 120.0, 20)

            ord_svc = OrderService(conn)
            self.order = ord_svc.place_order(
                customer_id=self.cust["user_id"],
                merchant_id=self.merchant["merchant_id"],
                items=[{"sku_id": self.sku["sku_id"], "quantity": 1}],
                delivery_address="Fayoum University St.",
                delivery_lat=29.310,
                delivery_lng=30.845,
                payment_method="COD"
            )

    def test_multi_fleet_selection_logic(self):
        with db_transaction() as conn:
            log_svc = LogisticsService(conn)
            # Heavy weight -> Tricycle
            self.assertEqual(log_svc.select_best_vehicle_type(weight_kg=40.0, volume_m3=0.1, distance_km=3.0), "TRICYCLE")
            # Narrow village alley -> Tuk-tuk
            self.assertEqual(log_svc.select_best_vehicle_type(weight_kg=5.0, volume_m3=0.02, distance_km=2.0, is_narrow_village_alley=True), "TUKTUK")
            # Long rural distance -> Car
            self.assertEqual(log_svc.select_best_vehicle_type(weight_kg=10.0, volume_m3=0.05, distance_km=18.0), "CAR")
            # Normal city order -> Motorcycle
            self.assertEqual(log_svc.select_best_vehicle_type(weight_kg=5.0, volume_m3=0.02, distance_km=3.0), "MOTORCYCLE")

    def test_smart_dispatch_and_otp_handshake(self):
        with db_transaction() as conn:
            log_svc = LogisticsService(conn)
            courier = log_svc.register_courier(self.courier_user["user_id"], "MOTORCYCLE", "FYM-1234")
            cid = courier["courier_id"]

            # Place courier near store
            log_svc.update_courier_telemetry(cid, lat=29.3082, lng=30.8422, speed_kmh=15.0)

            # Smart Dispatch
            dispatch = log_svc.assign_smart_dispatch(self.order["order_id"])
            self.assertEqual(dispatch["courier_id"], cid)
            raw_otp = dispatch["raw_otp"]
            did = dispatch["delivery_id"]

            # Courier arrives at merchant within 50m
            log_svc.courier_arrive_merchant(did, cid, courier_lat=29.3081, courier_lng=30.8421)

            # Courier picks up
            log_svc.courier_pickup_order(did, cid)

            # Confirm with wrong OTP must fail
            with self.assertRaises(ForbiddenError):
                log_svc.confirm_delivery_handshake(did, cid, "000000", cash_collected=140.0)

            # Confirm with valid OTP succeeds
            result = log_svc.confirm_delivery_handshake(did, cid, raw_otp, cash_collected=140.0)
            self.assertEqual(result["status"], "DELIVERED")

    def test_gps_spoofing_detection(self):
        with db_transaction() as conn:
            log_svc = LogisticsService(conn)
            courier = log_svc.register_courier(self.courier_user["user_id"], "MOTORCYCLE", "FYM-9999")
            # Spoofing with is_mock = True
            with self.assertRaises(ConflictError):
                log_svc.update_courier_telemetry(courier["courier_id"], 29.300, 30.840, speed_kmh=20.0, is_mock=True)

if __name__ == "__main__":
    unittest.main()
