import unittest
import uuid
import sys
sys.path.insert(0, "/home/spark/fayo_project")

from fastapi.testclient import TestClient
from fayo_core.api.main import app
from fayo_core.database import init_db, db_transaction
from fayo_core.modules.iam.service import IAMService
from fayo_core.modules.catalog.service import CatalogService
from fayo_core.modules.orders.service import OrderService

class TestDeliveryZonesControl(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        test_db = f"/tmp/fayo_zones_{uuid.uuid4().hex}.db"
        import os
        os.environ["FAYO_DB_PATH"] = test_db
        import fayo_core.database
        fayo_core.database.DB_PATH = test_db
        init_db()
        cls.client = TestClient(app)

        with db_transaction() as conn:
            iam = IAMService(conn)
            cat = CatalogService(conn)

            # Register Admin & Normal User
            cls.admin = iam.register_user(f"010{uuid.uuid4().hex[:8]}", "Control Tower Admin", "pass", "FYM-CITY", role_name="SUPER_ADMIN")
            cls.customer = iam.register_user(f"010{uuid.uuid4().hex[:8]}", "Customer Tester", "pass", "FYM-CITY", role_name="CUSTOMER")

            # Setup Merchants and SKUs in different zones
            # Bandar El-Fayoum
            cls.merch_bandar = cat.create_merchant("مطعم بندر الفيوم", "RESTAURANT", "FYM-CITY", 29.308, 30.842)
            cls.sku_bandar = cat.add_sku(cls.merch_bandar["merchant_id"], "MAINS", "كباب بندر", 150.0, 50)

            # Sinnuris
            cls.merch_sinnuris = cat.create_merchant("مطعم سنورس", "RESTAURANT", "FYM-SINNURIS", 29.408, 30.865)
            cls.sku_sinnuris = cat.add_sku(cls.merch_sinnuris["merchant_id"], "MAINS", "فطير سنورس", 80.0, 50)

            # Itsa
            cls.merch_itsa = cat.create_merchant("مطعم إطسا", "RESTAURANT", "FYM-ITSA", 29.230, 30.790)
            cls.sku_itsa = cat.add_sku(cls.merch_itsa["merchant_id"], "MAINS", "طواجن إطسا", 110.0, 50)

    def test_01_bandar_active_order_pass(self):
        # 1. بندر ACTIVE -> إنشاء طلب PASS
        res = self.client.post("/api/v1/orders/checkout", json={
            "customer_id": self.customer["user_id"],
            "merchant_id": self.merch_bandar["merchant_id"],
            "items": [{"sku_id": self.sku_bandar["sku_id"], "quantity": 1}],
            "delivery_address": "بندر الفيوم - المسلة",
            "delivery_lat": 29.310, "delivery_lng": 30.840, "payment_method": "COD"
        }, headers={"Idempotency-Key": str(uuid.uuid4())})
        self.assertEqual(res.status_code, 201)

    def test_02_bandar_inactive_blocks_new_order(self):
        # 2. بندر INACTIVE -> منع الطلب الجديد PASS
        # Admin pauses FYM-CITY
        res_pause = self.client.post("/api/v1/ops/delivery-zones/toggle", json={
            "zone_id": "FYM-CITY",
            "is_active": False,
            "reason": "Heavy rain in Bandar",
            "actor_id": self.admin["user_id"]
        })
        self.assertEqual(res_pause.status_code, 200)

        # Customer attempts checkout in FYM-CITY
        res_order = self.client.post("/api/v1/orders/checkout", json={
            "customer_id": self.customer["user_id"],
            "merchant_id": self.merch_bandar["merchant_id"],
            "items": [{"sku_id": self.sku_bandar["sku_id"], "quantity": 1}],
            "delivery_address": "بندر الفيوم - المسلة",
            "delivery_lat": 29.310, "delivery_lng": 30.840, "payment_method": "COD"
        }, headers={"Idempotency-Key": str(uuid.uuid4())})
        self.assertEqual(res_order.status_code, 422) # PolicyViolationError
        self.assertIn("ZONE_RESTRICTION", res_order.json()["detail"])

        # Re-activate Bandar for subsequent tests
        self.client.post("/api/v1/ops/delivery-zones/toggle", json={
            "zone_id": "FYM-CITY", "is_active": True, "reason": "Clear", "actor_id": self.admin["user_id"]
        })

    def test_03_sinnuris_active_order_pass(self):
        # 3. سنورس ACTIVE -> إنشاء طلب PASS
        res = self.client.post("/api/v1/orders/checkout", json={
            "customer_id": self.customer["user_id"],
            "merchant_id": self.merch_sinnuris["merchant_id"],
            "items": [{"sku_id": self.sku_sinnuris["sku_id"], "quantity": 1}],
            "delivery_address": "سنورس - ش بورسعيد",
            "delivery_lat": 29.410, "delivery_lng": 30.866, "payment_method": "COD"
        }, headers={"Idempotency-Key": str(uuid.uuid4())})
        self.assertEqual(res.status_code, 201)

    def test_04_sinnuris_inactive_blocks_new_order(self):
        # 4. سنورس INACTIVE -> منع الطلب الجديد PASS
        self.client.post("/api/v1/ops/delivery-zones/toggle", json={
            "zone_id": "FYM-SINNURIS", "is_active": False, "reason": "Maintenance", "actor_id": self.admin["user_id"]
        })
        res_order = self.client.post("/api/v1/orders/checkout", json={
            "customer_id": self.customer["user_id"],
            "merchant_id": self.merch_sinnuris["merchant_id"],
            "items": [{"sku_id": self.sku_sinnuris["sku_id"], "quantity": 1}],
            "delivery_address": "سنورس - ش بورسعيد",
            "delivery_lat": 29.410, "delivery_lng": 30.866, "payment_method": "COD"
        }, headers={"Idempotency-Key": str(uuid.uuid4())})
        self.assertEqual(res_order.status_code, 422)

        # Restore Sinnuris
        self.client.post("/api/v1/ops/delivery-zones/toggle", json={
            "zone_id": "FYM-SINNURIS", "is_active": True, "reason": "Back online", "actor_id": self.admin["user_id"]
        })

    def test_05_and_06_itsa_activation_and_deactivation(self):
        # 5. تفعيل إطسا من الإدارة -> يصبح متاحًا PASS
        res_enable = self.client.post("/api/v1/ops/delivery-zones/toggle", json={
            "zone_id": "FYM-ITSA", "is_active": True, "reason": "Pilot expansion to Itsa", "actor_id": self.admin["user_id"]
        })
        self.assertEqual(res_enable.status_code, 200)

        # Create order in Itsa
        res_order = self.client.post("/api/v1/orders/checkout", json={
            "customer_id": self.customer["user_id"],
            "merchant_id": self.merch_itsa["merchant_id"],
            "items": [{"sku_id": self.sku_itsa["sku_id"], "quantity": 1}],
            "delivery_address": "إطسا - ش البحر",
            "delivery_lat": 29.232, "delivery_lng": 30.792, "payment_method": "COD"
        }, headers={"Idempotency-Key": str(uuid.uuid4())})
        self.assertEqual(res_order.status_code, 201)

        # 6. إيقاف إطسا -> يتوقف إنشاء الطلبات الجديدة PASS
        res_disable = self.client.post("/api/v1/ops/delivery-zones/toggle", json={
            "zone_id": "FYM-ITSA", "is_active": False, "reason": "Pausing Itsa", "actor_id": self.admin["user_id"]
        })
        self.assertEqual(res_disable.status_code, 200)

        res_blocked = self.client.post("/api/v1/orders/checkout", json={
            "customer_id": self.customer["user_id"],
            "merchant_id": self.merch_itsa["merchant_id"],
            "items": [{"sku_id": self.sku_itsa["sku_id"], "quantity": 1}],
            "delivery_address": "إطسا - ش البحر",
            "delivery_lat": 29.232, "delivery_lng": 30.792, "payment_method": "COD"
        }, headers={"Idempotency-Key": str(uuid.uuid4())})
        self.assertEqual(res_blocked.status_code, 422)

    def test_07_and_08_halt_all_and_resume_all(self):
        # 7. إيقاف جميع المراكز -> منع الطلبات الجديدة PASS
        res_halt = self.client.post("/api/v1/ops/delivery-zones/toggle", json={
            "zone_id": "ALL", "is_active": False, "reason": "Governorate Emergency Weather Protocol", "actor_id": self.admin["user_id"]
        })
        self.assertEqual(res_halt.status_code, 200)

        # Try in Bandar (should be blocked)
        res_b = self.client.post("/api/v1/orders/checkout", json={
            "customer_id": self.customer["user_id"],
            "merchant_id": self.merch_bandar["merchant_id"],
            "items": [{"sku_id": self.sku_bandar["sku_id"], "quantity": 1}],
            "delivery_address": "بندر الفيوم",
            "delivery_lat": 29.310, "delivery_lng": 30.840, "payment_method": "COD"
        }, headers={"Idempotency-Key": str(uuid.uuid4())})
        self.assertEqual(res_b.status_code, 422)
        self.assertIn("GLOBAL_AUTOMATION", res_b.json()["detail"])

        # Try in Sinnuris (should be blocked)
        res_s = self.client.post("/api/v1/orders/checkout", json={
            "customer_id": self.customer["user_id"],
            "merchant_id": self.merch_sinnuris["merchant_id"],
            "items": [{"sku_id": self.sku_sinnuris["sku_id"], "quantity": 1}],
            "delivery_address": "سنورس",
            "delivery_lat": 29.410, "delivery_lng": 30.866, "payment_method": "COD"
        }, headers={"Idempotency-Key": str(uuid.uuid4())})
        self.assertEqual(res_s.status_code, 422)

        # 8. إعادة تشغيل جميع المراكز -> عودة الخدمة PASS
        res_resume = self.client.post("/api/v1/ops/delivery-zones/toggle", json={
            "zone_id": "ALL", "is_active": True, "reason": "Normal operations resumed", "actor_id": self.admin["user_id"]
        })
        self.assertEqual(res_resume.status_code, 200)

        res_ok = self.client.post("/api/v1/orders/checkout", json={
            "customer_id": self.customer["user_id"],
            "merchant_id": self.merch_bandar["merchant_id"],
            "items": [{"sku_id": self.sku_bandar["sku_id"], "quantity": 1}],
            "delivery_address": "بندر الفيوم",
            "delivery_lat": 29.310, "delivery_lng": 30.840, "payment_method": "COD"
        }, headers={"Idempotency-Key": str(uuid.uuid4())})
        self.assertEqual(res_ok.status_code, 201)

    def test_09_existing_orders_not_affected_by_zone_inactivation(self):
        # 9. الطلبات القديمة لا تتأثر عند إيقاف المركز PASS
        # Create an order in Bandar while active
        res_pre = self.client.post("/api/v1/orders/checkout", json={
            "customer_id": self.customer["user_id"],
            "merchant_id": self.merch_bandar["merchant_id"],
            "items": [{"sku_id": self.sku_bandar["sku_id"], "quantity": 1}],
            "delivery_address": "بندر الفيوم",
            "delivery_lat": 29.310, "delivery_lng": 30.840, "payment_method": "COD"
        }, headers={"Idempotency-Key": str(uuid.uuid4())})
        order_id = res_pre.json()["order_id"]

        # Now deactivate Bandar
        self.client.post("/api/v1/ops/delivery-zones/toggle", json={
            "zone_id": "FYM-CITY", "is_active": False, "reason": "Stop Bandar", "actor_id": self.admin["user_id"]
        })

        # Existing order status can still transition (e.g. ACCEPTED -> PREPARING)
        with db_transaction() as conn:
            ord_svc = OrderService(conn)
            t_res = ord_svc.transition_order_status(order_id, "ACCEPTED", self.merch_bandar["merchant_id"], "MERCHANT", "Accepted")
            self.assertEqual(t_res["status"], "ACCEPTED")

            # Check order details still viewable
            cur = conn.cursor()
            cur.execute("SELECT order_status FROM orders_orders WHERE order_id = ?", (order_id,))
            self.assertEqual(cur.fetchone()["order_status"], "ACCEPTED")

        # Restore Bandar
        self.client.post("/api/v1/ops/delivery-zones/toggle", json={
            "zone_id": "FYM-CITY", "is_active": True, "reason": "Back online", "actor_id": self.admin["user_id"]
        })

    def test_10_and_11_rbac_enforcement_for_zone_control(self):
        # 10. المستخدم العادي لا يستطيع تغيير حالة المركز PASS (403 Forbidden)
        res_user_attempt = self.client.post("/api/v1/ops/delivery-zones/toggle", json={
            "zone_id": "FYM-CITY",
            "is_active": False,
            "reason": "Hacker attempt",
            "actor_id": self.customer["user_id"]
        })
        self.assertEqual(res_user_attempt.status_code, 403)

        # 11. Admin يستطيع تغيير الحالة PASS (200 OK)
        res_admin = self.client.post("/api/v1/ops/delivery-zones/toggle", json={
            "zone_id": "FYM-CITY",
            "is_active": True,
            "reason": "Authorized admin action",
            "actor_id": self.admin["user_id"]
        })
        self.assertEqual(res_admin.status_code, 200)

    def test_12_audit_trail_logging_on_every_change(self):
        # 12. تسجيل كل تغيير في Audit Log PASS
        reason_unique = f"Audit_Check_{uuid.uuid4().hex[:6]}"
        self.client.post("/api/v1/ops/delivery-zones/toggle", json={
            "zone_id": "FYM-TUNIS",
            "is_active": True,
            "reason": reason_unique,
            "actor_id": self.admin["user_id"]
        })

        with db_transaction() as conn:
            cur = conn.cursor()
            cur.execute("""
                SELECT action, entity_type, entity_id, decision_reason
                FROM audit_system_audit_trail
                WHERE decision_reason LIKE ?
            """, (f"%{reason_unique}%",))
            log = cur.fetchone()
            self.assertIsNotNone(log)
            self.assertEqual(log["action"], "DELIVERY_ZONE_TOGGLED")
            self.assertEqual(log["entity_id"], "FYM-TUNIS")

if __name__ == "__main__":
    unittest.main()
