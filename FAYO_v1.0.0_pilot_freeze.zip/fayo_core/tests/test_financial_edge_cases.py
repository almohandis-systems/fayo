import unittest
import uuid
import sys
sys.path.insert(0, "/home/spark/fayo_project")

from fayo_core.database import init_db, db_transaction
from fayo_core.modules.iam.service import IAMService
from fayo_core.modules.catalog.service import CatalogService
from fayo_core.modules.orders.service import OrderService
from fayo_core.modules.logistics.service import LogisticsService
from fayo_core.modules.finance.service import FinancialLedgerService
from fayo_core.shared.domain.errors import ConflictError

class TestFinancialEdgeCases(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        test_db = f"/tmp/fayo_fin_edge_{uuid.uuid4().hex}.db"
        import os
        os.environ["FAYO_DB_PATH"] = test_db
        import fayo_core.database
        fayo_core.database.DB_PATH = test_db
        init_db()

    def setUp(self):
        with db_transaction() as conn:
            iam = IAMService(conn)
            self.cust = iam.register_user(f"010{uuid.uuid4().hex[:8]}", "Client Fin", "pass", "FYM-CITY")
            self.cour_user = iam.register_user(f"011{uuid.uuid4().hex[:8]}", "Courier Fin", "pass", "FYM-CITY", "COURIER")

            cat = CatalogService(conn)
            self.merch = cat.create_merchant("Farm Store", "FARM", "FYM-CITY", 29.308, 30.842, commission_rate=0.15)
            self.sku = cat.add_sku(self.merch["merchant_id"], "FARM", "Olive Oil 1L", 200.0, 20)

            ord_svc = OrderService(conn)
            self.order = ord_svc.place_order(
                customer_id=self.cust["user_id"],
                merchant_id=self.merch["merchant_id"],
                items=[{"sku_id": self.sku["sku_id"], "quantity": 1}],
                delivery_address="Fayoum",
                delivery_lat=29.310,
                delivery_lng=30.844,
                payment_method="COD"
            )
            self.tot = self.order["total_amount"]

            log_svc = LogisticsService(conn)
            self.courier = log_svc.register_courier(self.cour_user["user_id"], "MOTORCYCLE", "FYM-555")
            self.cid = self.courier["courier_id"]

            # Complete delivery and initial settlement
            fin = FinancialLedgerService(conn)
            self.init_entry_id = fin.process_order_delivered_settlement(self.order["order_id"], self.cid, self.tot)

    def test_full_refund_reversal_double_entry_balance(self):
        with db_transaction() as conn:
            fin = FinancialLedgerService(conn)
            refund_entry_id = fin.process_order_refund_reversal(
                order_id=self.order["order_id"],
                refund_type="FULL",
                refund_amount=self.tot,
                reason="Damaged product reported by customer",
                actor_id="admin-user"
            )
            self.assertTrue(refund_entry_id)

            # Invariant: Verify Total Debits == Total Credits on the reversal entry
            cur = conn.cursor()
            cur.execute("""
                SELECT 
                    SUM(CASE WHEN direction = 'DR' THEN amount ELSE 0 END) as dr,
                    SUM(CASE WHEN direction = 'CR' THEN amount ELSE 0 END) as cr
                FROM finance_postings
                WHERE entry_id = ?
            """, (refund_entry_id,))
            totals = cur.fetchone()
            self.assertAlmostEqual(totals["dr"], totals["cr"], places=3)
            self.assertAlmostEqual(totals["dr"], self.tot, places=2)

            # Verify order status became REFUNDED
            cur.execute("SELECT order_status FROM orders_orders WHERE order_id = ?", (self.order["order_id"],))
            self.assertEqual(cur.fetchone()["order_status"], "REFUNDED")

    def test_partial_refund_reversal_double_entry_balance(self):
        with db_transaction() as conn:
            fin = FinancialLedgerService(conn)
            partial_amount = round(self.tot / 2.0, 2)
            refund_entry_id = fin.process_order_refund_reversal(
                order_id=self.order["order_id"],
                refund_type="PARTIAL",
                refund_amount=partial_amount,
                reason="One item missing",
                actor_id="admin-user"
            )
            self.assertTrue(refund_entry_id)

            cur = conn.cursor()
            cur.execute("""
                SELECT 
                    SUM(CASE WHEN direction = 'DR' THEN amount ELSE 0 END) as dr,
                    SUM(CASE WHEN direction = 'CR' THEN amount ELSE 0 END) as cr
                FROM finance_postings
                WHERE entry_id = ?
            """, (refund_entry_id,))
            totals = cur.fetchone()
            self.assertAlmostEqual(totals["dr"], totals["cr"], places=3)
            self.assertAlmostEqual(totals["dr"], partial_amount, places=2)

    def test_excessive_refund_amount_rejected(self):
        with db_transaction() as conn:
            fin = FinancialLedgerService(conn)
            # Refund amount greater than total order must be rejected
            with self.assertRaises(ConflictError):
                fin.process_order_refund_reversal(
                    order_id=self.order["order_id"],
                    refund_type="FULL",
                    refund_amount=self.tot + 500.0,
                    reason="Invalid excess",
                    actor_id="admin-user"
                )

if __name__ == "__main__":
    unittest.main()
