import unittest
import uuid
import sys
sys.path.insert(0, "/home/spark/fayo_project")

from fastapi.testclient import TestClient
from fayo_core.database import init_db, db_transaction
from fayo_core.api.main import app
from fayo_core.modules.iam.service import IAMService
from fayo_core.shared.domain.errors import UnauthorizedError, ForbiddenError

class TestSecurity(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        test_db = f"/tmp/fayo_sec_{uuid.uuid4().hex}.db"
        import os
        os.environ["FAYO_DB_PATH"] = test_db
        import fayo_core.database
        fayo_core.database.DB_PATH = test_db
        init_db()
        cls.client = TestClient(app)

    def test_sql_injection_resilience(self):
        # Malicious payload in phone number and password
        sqli_phone = "01000000000' OR '1'='1"
        sqli_pass = "' OR '1'='1'; DROP TABLE iam_users; --"

        res = self.client.post("/api/v1/auth/login", json={
            "phone_number": sqli_phone,
            "password": sqli_pass
        })
        # Must fail with 401 Unauthorized, never 500 or execute dropped table
        self.assertEqual(res.status_code, 401)

        # Verify table still intact and accessible
        with db_transaction() as conn:
            cur = conn.cursor()
            cur.execute("SELECT COUNT(*) FROM iam_users")
            self.assertGreaterEqual(cur.fetchone()[0], 0)

    def test_privilege_escalation_attempt_fails(self):
        with db_transaction() as conn:
            iam = IAMService(conn)
            hacker = iam.register_user(f"010{uuid.uuid4().hex[:8]}", "Hacker User", "pass", "FYM-CITY", "CUSTOMER")
            target = iam.register_user(f"011{uuid.uuid4().hex[:8]}", "Target User", "pass", "FYM-CITY", "CUSTOMER")

            # Normal user attempts to escalate role
            with self.assertRaises(ForbiddenError):
                iam.assign_role(actor_user_id=hacker["user_id"], target_user_id=target["user_id"], new_role="SUPER_ADMIN")

            # Verify target user still only has CUSTOMER role
            cur = conn.cursor()
            cur.execute("SELECT role_name FROM iam_user_roles WHERE user_id = ?", (target["user_id"],))
            roles = [r[0] for r in cur.fetchall()]
            self.assertEqual(roles, ["CUSTOMER"])

    def test_device_fingerprint_mismatch_triggers_audit_alert(self):
        with db_transaction() as conn:
            iam = IAMService(conn)
            phone = f"012{uuid.uuid4().hex[:8]}"
            user = iam.register_user(phone, "Device User", "pass123", "FYM-CITY", "CUSTOMER", device_fingerprint="ORIGINAL_DEVICE_UUID_1")

            # Login with changed device
            auth = iam.authenticate_user(phone, "pass123", device_fingerprint="UNRECOGNIZED_DEVICE_UUID_2")
            self.assertEqual(auth["user_id"], user["user_id"])

            # Verify audit trail recorded security alert
            cur = conn.cursor()
            cur.execute("SELECT action FROM audit_system_audit_trail WHERE action = 'DEVICE_FINGERPRINT_MISMATCH_LOGIN'")
            self.assertIsNotNone(cur.fetchone())

if __name__ == "__main__":
    unittest.main()
