import unittest
import uuid
import sys
sys.path.insert(0, "/home/spark/fayo_project")

from fayo_core.database import init_db, db_transaction
from fayo_core.modules.iam.service import IAMService
from fayo_core.shared.domain.errors import (
    NotFoundError, ConflictError, UnauthorizedError, ForbiddenError
)

class TestIAM(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        init_db()

    def test_user_registration_and_authentication(self):
        with db_transaction() as conn:
            iam = IAMService(conn)
            phone = f"010{uuid.uuid4().hex[:8]}"
            user = iam.register_user(
                phone_number=phone,
                full_name="Mahmoud El-Fayoumi",
                password="SecurePassword123!",
                zone_id="FYM-CITY",
                role_name="CUSTOMER",
                device_fingerprint="device_android_9921"
            )
            self.assertEqual(user["phone_number"], phone)

            auth = iam.authenticate_user(phone, "SecurePassword123!", "device_android_9921")
            self.assertEqual(auth["user_id"], user["user_id"])
            self.assertIn("CUSTOMER", auth["roles"])

            with self.assertRaises(UnauthorizedError):
                iam.authenticate_user(phone, "WrongPassword!")

            with self.assertRaises(ConflictError):
                iam.register_user(phone, "Duplicate User", "Pass123", "FYM-CITY")

    def test_rbac_and_privilege_escalation_prevention(self):
        with db_transaction() as conn:
            iam = IAMService(conn)
            phone_customer = f"011{uuid.uuid4().hex[:8]}"
            phone_merchant = f"012{uuid.uuid4().hex[:8]}"
            phone_admin = f"015{uuid.uuid4().hex[:8]}"

            customer = iam.register_user(phone_customer, "Ali Customer", "Pass123", "FYM-SINNURIS", "CUSTOMER")
            merchant = iam.register_user(phone_merchant, "Hassan Store", "Pass123", "FYM-SINNURIS", "MERCHANT_OWNER")
            admin = iam.register_user(phone_admin, "Admin Master", "Pass123", "FYM-CITY", "SUPER_ADMIN")

            with self.assertRaises(ForbiddenError):
                iam.authorize(customer["user_id"], ["MERCHANT_OWNER", "MERCHANT_STAFF"])

            self.assertTrue(iam.authorize(merchant["user_id"], ["MERCHANT_OWNER"]))

            with self.assertRaises(ForbiddenError):
                iam.assign_role(actor_user_id=merchant["user_id"], target_user_id=customer["user_id"], new_role="SUPER_ADMIN")

            iam.assign_role(actor_user_id=admin["user_id"], target_user_id=customer["user_id"], new_role="COURIER")
            self.assertTrue(iam.authorize(customer["user_id"], ["COURIER"]))

            with self.assertRaises(ForbiddenError):
                iam.authorize(customer["user_id"], ["COURIER"], required_zone="FYM-ITSA")

if __name__ == "__main__":
    unittest.main()
