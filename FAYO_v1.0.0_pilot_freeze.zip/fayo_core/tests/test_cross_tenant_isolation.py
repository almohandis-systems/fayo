import unittest
import uuid
import sys
sys.path.insert(0, "/home/spark/fayo_project")

from fastapi.testclient import TestClient
from fayo_core.database import init_db, db_transaction
from fayo_core.api.main import app
from fayo_core.modules.iam.service import IAMService
from fayo_core.modules.catalog.service import CatalogService
from fayo_core.modules.orders.service import OrderService
from fayo_core.shared.domain.errors import ForbiddenError

class TestCrossTenantIsolation(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        test_db = f"/tmp/fayo_iso_{uuid.uuid4().hex}.db"
        import os
        os.environ["FAYO_DB_PATH"] = test_db
        import fayo_core.database
        fayo_core.database.DB_PATH = test_db
        init_db()
        cls.client = TestClient(app)

    def setUp(self):
        with db_transaction() as conn:
            iam = IAMService(conn)
            self.cust_a = iam.register_user(f"010{uuid.uuid4().hex[:8]}", "Customer A", "pass", "FYM-CITY")
            self.cust_b = iam.register_user(f"010{uuid.uuid4().hex[:8]}", "Customer B", "pass", "FYM-CITY")

            cat = CatalogService(conn)
            self.merch_a = cat.create_merchant("Store A", "GROCERY", "FYM-CITY", 29.30, 30.84)
            self.merch_b = cat.create_merchant("Store B", "GROCERY", "FYM-CITY", 29.31, 30.85)

            self.sku_a = cat.add_sku(self.merch_a["merchant_id"], "PANTRY", "Flour 1kg", 20.0, 50)
            self.sku_b = cat.add_sku(self.merch_b["merchant_id"], "PANTRY", "Sugar 1kg", 25.0, 50)

            ord_svc = OrderService(conn)
            self.order_a = ord_svc.place_order(
                customer_id=self.cust_a["user_id"],
                merchant_id=self.merch_a["merchant_id"],
                items=[{"sku_id": self.sku_a["sku_id"], "quantity": 1}],
                delivery_address="Address A",
                delivery_lat=29.301,
                delivery_lng=30.841
            )

    def test_merchant_a_cannot_modify_merchant_b_product(self):
        # Merchant A tries to modify SKU belonging to Merchant B
        res = self.client.patch(
            f"/api/v1/catalog/skus/{self.sku_b['sku_id']}/inventory",
            json={"available_qty": 999},
            headers={"X-Merchant-Id": self.merch_a["merchant_id"]}
        )
        self.assertEqual(res.status_code, 403)
        self.assertIn("Cross-tenant access forbidden", res.json()["detail"])

        # Verify SKU B inventory was not modified
        with db_transaction() as conn:
            cur = conn.cursor()
            cur.execute("SELECT available_qty FROM commerce_inventories WHERE sku_id = ?", (self.sku_b["sku_id"],))
            self.assertEqual(cur.fetchone()["available_qty"], 50)

            # Verify audit log caught the IDOR tampering attempt
            cur.execute("SELECT action FROM audit_system_audit_trail WHERE action = 'IDOR_ATTEMPT_UPDATE_PRODUCT'")
            self.assertIsNotNone(cur.fetchone())

    def test_customer_b_cannot_view_or_cancel_customer_a_orders(self):
        # Customer B tries to view Customer A's orders
        res_view = self.client.get(
            f"/api/v1/customer/{self.cust_a['user_id']}/orders",
            headers={"X-User-Id": self.cust_b["user_id"]}
        )
        self.assertEqual(res_view.status_code, 403)

        # Customer B tries to cancel Customer A's order
        res_cancel = self.client.post(
            f"/api/v1/customer/orders/{self.order_a['order_id']}/cancel",
            headers={"X-User-Id": self.cust_b["user_id"]}
        )
        self.assertEqual(res_cancel.status_code, 403)

        # Verify Order A status remains CREATED
        with db_transaction() as conn:
            cur = conn.cursor()
            cur.execute("SELECT order_status FROM orders_orders WHERE order_id = ?", (self.order_a["order_id"],))
            self.assertEqual(cur.fetchone()["order_status"], "CREATED")

    def test_geographic_zone_permission_enforcement(self):
        with db_transaction() as conn:
            iam = IAMService(conn)
            user_sinnuris = iam.register_user(f"011{uuid.uuid4().hex[:8]}", "Sinnuris User", "pass", "FYM-SINNURIS", "COURIER")
            # Should fail when required zone is Itsa
            with self.assertRaises(ForbiddenError):
                iam.authorize(user_sinnuris["user_id"], ["COURIER"], required_zone="FYM-ITSA")

if __name__ == "__main__":
    unittest.main()
