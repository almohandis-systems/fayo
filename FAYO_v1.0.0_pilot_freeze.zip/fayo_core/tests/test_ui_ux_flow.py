import unittest
import uuid
import sys
sys.path.insert(0, "/home/spark/fayo_project")

from fastapi.testclient import TestClient
from fayo_core.database import init_db, db_transaction
from fayo_core.api.main import app
from fayo_core.modules.iam.service import IAMService
from fayo_core.modules.catalog.service import CatalogService

class TestUIUXFlow(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        test_db = f"/tmp/fayo_ui_{uuid.uuid4().hex}.db"
        import os
        os.environ["FAYO_DB_PATH"] = test_db
        import fayo_core.database
        fayo_core.database.DB_PATH = test_db
        init_db()
        cls.client = TestClient(app)

        # Seed initial merchant and SKUs
        with db_transaction() as conn:
            iam = IAMService(conn)
            cls.cust = iam.register_user(f"010{uuid.uuid4().hex[:8]}", "Fayoum Mobile User", "Pass123!", "FYM-CITY")
            cat = CatalogService(conn)
            cls.merch = cat.create_merchant("مطعم وكبابجي وادي الحيتان", "RESTAURANT", "FYM-CITY", 29.308, 30.842)
            cls.sku1 = cat.add_sku(cls.merch["merchant_id"], "GRILL", "كيلو كباب وكفتة بلدي", 320.0, 30)
            cls.sku2 = cat.add_sku(cls.merch["merchant_id"], "SALADS", "طحينة وسلطة خضراء فيومي", 25.0, 100)

    def test_01_open_fayo_homepage_and_mobile_structure(self):
        # 1. Open FAYO
        res = self.client.get("/")
        self.assertEqual(res.status_code, 200)
        html = res.text
        # Verify Mobile-First viewport & FAYO branding
        self.assertIn("FAYO • فايو", html)
        self.assertIn('viewport" content="width=device-width', html)
        self.assertIn("منظومة التجارة واللوجستيات المحلية بمحافظة الفيوم", html)
        # Verify Key Structural Components
        self.assertIn('id="zoneSelect"', html)
        self.assertIn('id="categoriesBar"', html)
        self.assertIn('id="storesList"', html)
        self.assertIn('id="floatingCart"', html)
        self.assertIn('id="trackingModal"', html)
        self.assertIn('bottom-nav', html)

    def test_02_browse_categories_and_stores(self):
        # 2. Browse Categories & Filter Stores
        res_all = self.client.get("/api/v1/catalog/merchants")
        self.assertEqual(res_all.status_code, 200)
        stores = res_all.json()
        self.assertGreaterEqual(len(stores), 1)

        # Filter by zone (FYM-CITY)
        res_zone = self.client.get("/api/v1/catalog/merchants?zone_id=FYM-CITY")
        self.assertEqual(res_zone.status_code, 200)
        self.assertGreaterEqual(len(res_zone.json()), 1)

        # Filter by category (RESTAURANT)
        res_cat = self.client.get("/api/v1/catalog/merchants?merchant_type=RESTAURANT")
        self.assertEqual(res_cat.status_code, 200)
        self.assertEqual(res_cat.json()[0]["merchant_type"], "RESTAURANT")

    def test_03_open_store_and_view_products(self):
        # 3. Open Store
        res = self.client.get(f"/api/v1/catalog/merchants/{self.merch['merchant_id']}")
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertEqual(data["name"], "مطعم وكبابجي وادي الحيتان")
        self.assertIn("skus", data)
        self.assertEqual(len(data["skus"]), 2)
        sku_names = [s["name"] for s in data["skus"]]
        self.assertIn("كيلو كباب وكفتة بلدي", sku_names)

    def test_04_cart_checkout_and_live_tracking_flow(self):
        # 4. Add to Cart & Create Order with Idempotency
        idem_key = f"IDEM_UI_{uuid.uuid4().hex}"
        checkout_payload = {
            "customer_id": self.cust["user_id"],
            "merchant_id": self.merch["merchant_id"],
            "items": [
                {"sku_id": self.sku1["sku_id"], "quantity": 1}, # 320 EGP
                {"sku_id": self.sku2["sku_id"], "quantity": 2}  # 50 EGP
            ],
            "delivery_address": "بندر الفيوم - المسلة - شارع جمال عبد الناصر",
            "delivery_lat": 29.3100,
            "delivery_lng": 30.8400,
            "payment_method": "COD"
        }
        res = self.client.post("/api/v1/orders/checkout", json=checkout_payload, headers={"Idempotency-Key": idem_key})
        self.assertEqual(res.status_code, 201)
        order = res.json()
        order_id = order["order_id"]
        # Subtotal: 320 + 50 = 370 EGP
        self.assertEqual(order["items_subtotal"], 370.00)
        self.assertEqual(order["order_status"], "CREATED")

        # 5. Live Order Tracking
        res_track = self.client.get(f"/api/v1/orders/{order_id}")
        self.assertEqual(res_track.status_code, 200)
        track_data = res_track.json()
        self.assertEqual(track_data["order_status"], "CREATED")
        self.assertEqual(len(track_data["items"]), 2)
        self.assertEqual(track_data["merchant_name"], "مطعم وكبابجي وادي الحيتان")

        # 6. Customer Orders List
        res_my_orders = self.client.get(f"/api/v1/customer/{self.cust['user_id']}/orders", headers={"X-User-Id": self.cust["user_id"]})
        self.assertEqual(res_my_orders.status_code, 200)
        self.assertEqual(len(res_my_orders.json()), 1)
        self.assertEqual(res_my_orders.json()[0]["order_id"], order_id)

    def test_05_floating_cart_and_stepper_contract(self):
        # Verify response structure fits the frontend floating cart and stepper logic
        res = self.client.get(f"/api/v1/catalog/merchants/{self.merch['merchant_id']}")
        skus = res.json()["skus"]
        for s in skus:
            self.assertIn("sku_id", s)
            self.assertIn("price", s)
            self.assertIn("available_qty", s)
            self.assertGreater(s["available_qty"], 0)

if __name__ == "__main__":
    unittest.main()
