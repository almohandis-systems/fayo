import unittest
import uuid
import sys
sys.path.insert(0, "/home/spark/fayo_project")

from fayo_core.database import init_db, db_transaction
from fayo_core.modules.iam.service import IAMService
from fayo_core.modules.catalog.service import CatalogService
from fayo_core.modules.orders.service import OrderService
from fayo_core.modules.logistics.service import LogisticsService
from fayo_core.modules.finance.service import FinancialLedgerService
from fayo_core.shared.domain.errors import ForbiddenError, ConflictError

class TestOfflineAndOTPHardening(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        test_db = f"/tmp/fayo_otp_edge_{uuid.uuid4().hex}.db"
        import os
        os.environ["FAYO_DB_PATH"] = test_db
        import fayo_core.database
        fayo_core.database.DB_PATH = test_db
        init_db()

    def setUp(self):
        with db_transaction() as conn:
            iam = IAMService(conn)
            self.cust = iam.register_user(f"010{uuid.uuid4().hex[:8]}", "Client OTP", "pass", "FYM-CITY")
            self.cour_user = iam.register_user(f"011{uuid.uuid4().hex[:8]}", "Courier OTP", "pass", "FYM-CITY", "COURIER")

            cat = CatalogService(conn)
            self.merch = cat.create_merchant("Store OTP", "GROCERY", "FYM-CITY", 29.308, 30.842)
            self.sku = cat.add_sku(self.merch["merchant_id"], "GROCERY", "Water Box", 50.0, 50)

            ord_svc = OrderService(conn)
            self.order = ord_svc.place_order(
                customer_id=self.cust["user_id"],
                merchant_id=self.merch["merchant_id"],
                items=[{"sku_id": self.sku["sku_id"], "quantity": 1}],
                delivery_address="Fayoum",
                delivery_lat=29.310,
                delivery_lng=30.844,
                payment_method="COD"
            )

            log_svc = LogisticsService(conn)
            self.courier = log_svc.register_courier(self.cour_user["user_id"], "MOTORCYCLE", "FYM-111")
            c_id = self.courier["courier_id"]
            log_svc.update_courier_telemetry(c_id, 29.3081, 30.8421, 10.0)
            disp = log_svc.assign_smart_dispatch(self.order["order_id"])
            self.deliv_id = disp["delivery_id"]
            self.cid = disp["courier_id"]
            self.raw_otp = disp["raw_otp"]

    def test_otp_brute_force_lockout_after_three_attempts(self):
        for attempt in ["000001", "000002", "000003"]:
            with self.assertRaises(ForbiddenError):
                with db_transaction() as conn:
                    log_svc = LogisticsService(conn)
                    log_svc.confirm_delivery_handshake(self.deliv_id, self.cid, attempt, cash_collected=62.0)

        # Attempt 4: Even with CORRECT OTP, delivery is now permanently locked
        with self.assertRaises(ForbiddenError) as ctx:
            with db_transaction() as conn:
                log_svc = LogisticsService(conn)
                log_svc.confirm_delivery_handshake(self.deliv_id, self.cid, self.raw_otp, cash_collected=62.0)
        self.assertIn("locked", str(ctx.exception).lower())

    def test_otp_expiration_check(self):
        with db_transaction() as conn:
            # Simulate expired OTP by backdating otp_expires_at
            cur = conn.cursor()
            cur.execute("""
                UPDATE fleet_deliveries
                SET otp_expires_at = datetime('now', 'utc', '-1 minute')
                WHERE delivery_id = ?
            """, (self.deliv_id,))

            log_svc = LogisticsService(conn)
            with self.assertRaises(ConflictError) as ctx:
                log_svc.confirm_delivery_handshake(self.deliv_id, self.cid, self.raw_otp, cash_collected=62.0)
            self.assertIn("expired", str(ctx.exception).lower())

    def test_offline_courier_sync_idempotency_and_replay_protection(self):
        action_id = str(uuid.uuid4())
        # Setup fresh courier, order, and delivery for offline test
        with db_transaction() as conn:
            iam = IAMService(conn)
            cour_user2 = iam.register_user(f"011{uuid.uuid4().hex[:8]}", "Courier Offline", "pass", "FYM-CITY", "COURIER")
            log_svc = LogisticsService(conn)
            courier2 = log_svc.register_courier(cour_user2["user_id"], "MOTORCYCLE", "FYM-222")
            cid2 = courier2["courier_id"]
            log_svc.update_courier_telemetry(cid2, 29.3081, 30.8421, 10.0)

            ord_svc = OrderService(conn)
            order2 = ord_svc.place_order(
                customer_id=self.cust["user_id"],
                merchant_id=self.merch["merchant_id"],
                items=[{"sku_id": self.sku["sku_id"], "quantity": 1}],
                delivery_address="Fayoum",
                delivery_lat=29.310,
                delivery_lng=30.844
            )
            disp2 = log_svc.assign_smart_dispatch(order2["order_id"])

        # 1. First offline sync upload
        with db_transaction() as conn:
            log_svc = LogisticsService(conn)
            res1 = log_svc.sync_offline_delivery(
                action_id=action_id,
                delivery_id=disp2["delivery_id"],
                courier_id=cid2,
                provided_otp=disp2["raw_otp"],
                cash_collected=order2["total_amount"],
                client_timestamp="2026-10-04T08:00:00Z"
            )
            self.assertEqual(res1["status"], "DELIVERED")

        # 2. Replay of same offline sync upload -> returns cached response without duplicate operations
        with db_transaction() as conn:
            log_svc = LogisticsService(conn)
            res2 = log_svc.sync_offline_delivery(
                action_id=action_id,
                delivery_id=disp2["delivery_id"],
                courier_id=cid2,
                provided_otp=disp2["raw_otp"],
                cash_collected=order2["total_amount"],
                client_timestamp="2026-10-04T08:00:00Z"
            )
            self.assertEqual(res2["status"], "DELIVERED")

if __name__ == "__main__":
    unittest.main()
