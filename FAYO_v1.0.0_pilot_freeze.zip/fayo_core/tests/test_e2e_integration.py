import unittest
import uuid
import sys
sys.path.insert(0, "/home/spark/fayo_project")

from fayo_core.database import init_db, db_transaction
from fayo_core.modules.iam.service import IAMService
from fayo_core.modules.catalog.service import CatalogService
from fayo_core.modules.orders.service import OrderService
from fayo_core.modules.logistics.service import LogisticsService
from fayo_core.modules.finance.service import FinancialLedgerService
from fayo_core.shared.infra.outbox import process_outbox_batch

class TestE2EIntegration(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        test_db = f"/tmp/fayo_e2e_{uuid.uuid4().hex}.db"
        import os
        os.environ["FAYO_DB_PATH"] = test_db
        import fayo_core.database
        fayo_core.database.DB_PATH = test_db
        init_db()

    def test_complete_e2e_order_to_settlement_lifecycle(self):
        # 1. IAM Setup
        with db_transaction() as conn:
            iam = IAMService(conn)
            admin = iam.register_user(f"010{uuid.uuid4().hex[:8]}", "Admin Fayoum", "PassAdmin!", "FYM-CITY", "SUPER_ADMIN")
            customer = iam.register_user(f"011{uuid.uuid4().hex[:8]}", "Tarek Customer", "Pass123!", "FYM-SINNURIS", "CUSTOMER")
            merchant_user = iam.register_user(f"012{uuid.uuid4().hex[:8]}", "Sinnuris Farm Owner", "Pass123!", "FYM-SINNURIS", "MERCHANT_OWNER")
            courier_user = iam.register_user(f"015{uuid.uuid4().hex[:8]}", "Ahmed Courier", "Pass123!", "FYM-SINNURIS", "COURIER")

            # 2. Merchant & Catalog Setup
            cat = CatalogService(conn)
            merchant = cat.create_merchant(
                name="Mazare' Sinnuris Farm",
                merchant_type="FARM",
                zone_id="FYM-SINNURIS",
                lat=29.4105,
                lng=30.8655,
                is_platform_owned=False,
                commission_rate=0.10
            )
            sku1 = cat.add_sku(merchant["merchant_id"], "OILS", "Fayoum Extra Virgin Olive Oil 1L", 180.00, initial_qty=20)
            sku2 = cat.add_sku(merchant["merchant_id"], "DAIRY", "Natural Buffalo Butter 1kg", 220.00, initial_qty=15)

            # 3. Courier Setup
            log_svc = LogisticsService(conn)
            courier = log_svc.register_courier(
                user_id=courier_user["user_id"],
                vehicle_type="MOTORCYCLE",
                license_plate="FYM-6789",
                cod_balance_limit=2500.00
            )
            cid = courier["courier_id"]
            log_svc.update_courier_telemetry(cid, lat=29.4120, lng=30.8660, speed_kmh=20.0)

        # 4. Customer Places Order with Idempotency Key
        idempotency_key = str(uuid.uuid4())
        with db_transaction() as conn:
            ord_svc = OrderService(conn)
            order = ord_svc.place_order(
                customer_id=customer["user_id"],
                merchant_id=merchant["merchant_id"],
                items=[
                    {"sku_id": sku1["sku_id"], "quantity": 1}, # 180 EGP
                    {"sku_id": sku2["sku_id"], "quantity": 1}  # 220 EGP
                ],
                delivery_address="Sinnuris, Port Said Street, House 12",
                delivery_lat=29.4150,
                delivery_lng=30.8700,
                payment_method="COD",
                idempotency_key=idempotency_key
            )
            order_id = order["order_id"]
            self.assertEqual(order["items_subtotal"], 400.00)
            self.assertEqual(order["order_status"], "CREATED")
            total_order_amount = order["total_amount"]

        # 5. Outbox Event Processed
        with db_transaction() as conn:
            processed = process_outbox_batch(conn)
            self.assertGreaterEqual(processed, 1)

        # 6. Merchant Accepts & Prepares Order
        with db_transaction() as conn:
            ord_svc = OrderService(conn)
            ord_svc.transition_order_status(order_id, "ACCEPTED", merchant_user["user_id"], "MERCHANT_OWNER")
            ord_svc.transition_order_status(order_id, "PREPARING", merchant_user["user_id"], "MERCHANT_OWNER")

        # 7. Smart Dispatch Assigns Courier
        with db_transaction() as conn:
            log_svc = LogisticsService(conn)
            dispatch = log_svc.assign_smart_dispatch(order_id)
            self.assertEqual(dispatch["courier_id"], cid)
            delivery_id = dispatch["delivery_id"]
            raw_otp = dispatch["raw_otp"]

        # 8. Courier Arrives at Merchant (Geofence verified within 100m)
        with db_transaction() as conn:
            log_svc = LogisticsService(conn)
            log_svc.courier_arrive_merchant(delivery_id, cid, courier_lat=29.4106, courier_lng=30.8656)

        # 9. Courier Picks Up Order
        with db_transaction() as conn:
            log_svc = LogisticsService(conn)
            log_svc.courier_pickup_order(delivery_id, cid)

            cur = conn.cursor()
            cur.execute("SELECT order_status FROM orders_orders WHERE order_id = ?", (order_id,))
            self.assertEqual(cur.fetchone()["order_status"], "IN_TRANSIT")

        # 10. Courier Handshake & Delivery Confirmation with OTP
        with db_transaction() as conn:
            log_svc = LogisticsService(conn)
            deliv_result = log_svc.confirm_delivery_handshake(delivery_id, cid, raw_otp, cash_collected=total_order_amount)
            self.assertEqual(deliv_result["status"], "DELIVERED")

        # 11. Automated Double-Entry Financial Settlement
        with db_transaction() as conn:
            fin = FinancialLedgerService(conn)
            entry_id = fin.process_order_delivered_settlement(order_id, cid, total_order_amount)
            self.assertTrue(bool(entry_id))

            # Verify balances
            c_cash_acc = fin.get_or_create_account("COURIER", cid, "ASSET", "COURIER_CASH")
            courier_cash_balance = fin.get_account_balance(c_cash_acc["account_id"])
            self.assertEqual(courier_cash_balance, total_order_amount)

            m_payable_acc = fin.get_or_create_account("MERCHANT", merchant["merchant_id"], "LIABILITY", "MERCHANT_PAYABLE")
            merchant_balance = fin.get_account_balance(m_payable_acc["account_id"])
            # Subtotal 400 - 10% commission (40 EGP) = 360.00 EGP
            self.assertEqual(merchant_balance, 360.00)

            plat_comm_acc = fin.get_or_create_account("PLATFORM", "FAYO_HEADQUARTERS", "REVENUE", "PLATFORM_COMMISSION")
            comm_balance = fin.get_account_balance(plat_comm_acc["account_id"])
            self.assertEqual(comm_balance, 40.00)

            plat_deliv_acc = fin.get_or_create_account("PLATFORM", "FAYO_HEADQUARTERS", "REVENUE", "PLATFORM_DELIVERY_MARGIN")
            deliv_margin_balance = fin.get_account_balance(plat_deliv_acc["account_id"])
            self.assertGreater(deliv_margin_balance, 0.0)

        # 12. Verify Audit Trail Completeness
        with db_transaction() as conn:
            cur = conn.cursor()
            cur.execute("SELECT COUNT(*) as count FROM audit_system_audit_trail WHERE entity_id IN (?, ?)", (order_id, cid))
            row = cur.fetchone()
            self.assertGreaterEqual(row["count"], 3)

if __name__ == "__main__":
    unittest.main()
