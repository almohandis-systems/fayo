import os
import sys
import time
import uuid
import resource
import statistics
import concurrent.futures
from typing import List, Dict, Any

sys.path.insert(0, "/home/spark/fayo_project")

test_db = f"/tmp/fayo_load_{uuid.uuid4().hex}.db"
os.environ["FAYO_DB_PATH"] = test_db
import fayo_core.database
fayo_core.database.DB_PATH = test_db
from fayo_core.database import init_db, db_transaction, get_db_connection
from fayo_core.modules.iam.service import IAMService
from fayo_core.modules.catalog.service import CatalogService
from fayo_core.modules.orders.service import OrderService

init_db()

with db_transaction() as conn:
    iam = IAMService(conn)
    customer = iam.register_user(f"010{uuid.uuid4().hex[:8]}", "Load Tester", "pass", "FYM-CITY")
    cat = CatalogService(conn)
    merchant = cat.create_merchant("Load Store", "GROCERY", "FYM-CITY", 29.30, 30.84)
    sku = cat.add_sku(merchant["merchant_id"], "GROCERY", "Sugar 1kg", 30.0, initial_qty=5000)
    sku_id = sku["sku_id"]
    merch_id = merchant["merchant_id"]
    cust_id = customer["user_id"]

def run_concurrent_batch(concurrency_level: int, total_requests: int) -> Dict[str, Any]:
    latencies = []
    successes = 0
    failures = 0
    lock_errors = 0

    def single_worker(worker_idx: int):
        t0 = time.perf_counter()
        try:
            with db_transaction() as conn:
                ord_svc = OrderService(conn)
                ord_svc.place_order(
                    customer_id=cust_id,
                    merchant_id=merch_id,
                    items=[{"sku_id": sku_id, "quantity": 1}],
                    delivery_address="Fayoum Center",
                    delivery_lat=29.31,
                    delivery_lng=30.85,
                    payment_method="COD",
                    idempotency_key=f"LOAD_{concurrency_level}_{worker_idx}"
                )
            dur_ms = (time.perf_counter() - t0) * 1000.0
            return True, dur_ms, None
        except Exception as e:
            dur_ms = (time.perf_counter() - t0) * 1000.0
            is_lock = "locked" in str(e).lower() or "busy" in str(e).lower()
            return False, dur_ms, is_lock

    start_wall = time.perf_counter()
    with concurrent.futures.ThreadPoolExecutor(max_workers=concurrency_level) as executor:
        futures = [executor.submit(single_worker, i) for i in range(total_requests)]
        for f in concurrent.futures.as_completed(futures):
            ok, dur, is_lock = f.result()
            latencies.append(dur)
            if ok:
                successes += 1
            else:
                failures += 1
                if is_lock:
                    lock_errors += 1

    total_time = time.perf_counter() - start_wall
    latencies.sort()
    avg_latency = statistics.mean(latencies)
    p95_latency = latencies[int(len(latencies) * 0.95)]
    min_latency = min(latencies)
    max_latency = max(latencies)
    throughput = total_requests / total_time
    mem_kb = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss

    return {
        "concurrency": concurrency_level,
        "total_requests": total_requests,
        "total_time_seconds": round(total_time, 3),
        "throughput_rps": round(throughput, 1),
        "min_latency_ms": round(min_latency, 2),
        "avg_latency_ms": round(avg_latency, 2),
        "p95_latency_ms": round(p95_latency, 2),
        "max_latency_ms": round(max_latency, 2),
        "success_count": successes,
        "failure_count": failures,
        "lock_errors": lock_errors,
        "memory_rss_mb": round(mem_kb / 1024.0, 2)
    }

if __name__ == "__main__":
    print("=== EXECUTING LOAD TEST SUITE ===")
    for c in [100, 200, 500]:
        res = run_concurrent_batch(c, c)
        print(f"Concurrency: {res['concurrency']} | Throughput: {res['throughput_rps']} req/s | Avg: {res['avg_latency_ms']}ms | P95: {res['p95_latency_ms']}ms | Success: {res['success_count']}/{res['total_requests']} | Locks: {res['lock_errors']}")
