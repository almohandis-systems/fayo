import sqlite3
import os
from contextlib import contextmanager

DB_PATH = os.environ.get("FAYO_DB_PATH", "/tmp/fayo_v1.db")

def get_db_connection():
    conn = sqlite3.connect(DB_PATH, timeout=30.0, check_same_thread=False)
    conn.execute("PRAGMA journal_mode = WAL;")
    conn.execute("PRAGMA foreign_keys = ON;")
    conn.execute("PRAGMA busy_timeout = 5000;")
    conn.row_factory = sqlite3.Row
    return conn

@contextmanager
def db_transaction():
    conn = get_db_connection()
    try:
        conn.execute("BEGIN IMMEDIATE;")
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()

def init_db():
    conn = get_db_connection()
    cur = conn.cursor()

    cur.executescript("""
    CREATE TABLE IF NOT EXISTS audit_system_audit_trail (
        audit_id INTEGER PRIMARY KEY AUTOINCREMENT,
        trace_id TEXT NOT NULL,
        actor_id TEXT NOT NULL,
        actor_type TEXT NOT NULL,
        action TEXT NOT NULL,
        entity_type TEXT NOT NULL,
        entity_id TEXT NOT NULL,
        ip_address TEXT,
        user_agent TEXT,
        input_payload TEXT,
        decision_reason TEXT NOT NULL,
        state_before TEXT,
        state_after TEXT,
        created_at TEXT NOT NULL DEFAULT (datetime('now', 'utc'))
    );
    CREATE INDEX IF NOT EXISTS idx_audit_trace ON audit_system_audit_trail(trace_id);
    CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_system_audit_trail(entity_type, entity_id);

    CREATE TABLE IF NOT EXISTS transactional_outbox (
        id TEXT PRIMARY KEY,
        aggregate_type TEXT NOT NULL,
        aggregate_id TEXT NOT NULL,
        event_type TEXT NOT NULL,
        payload TEXT NOT NULL,
        headers TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'PENDING',
        retry_count INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL DEFAULT (datetime('now', 'utc')),
        published_at TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_outbox_unprocessed ON transactional_outbox(created_at) WHERE status = 'PENDING';

    CREATE TABLE IF NOT EXISTS dead_letter_events (
        id TEXT PRIMARY KEY,
        original_event_id TEXT NOT NULL,
        event_type TEXT NOT NULL,
        payload TEXT NOT NULL,
        error_reason TEXT NOT NULL,
        retry_count INTEGER NOT NULL,
        failed_at TEXT NOT NULL DEFAULT (datetime('now', 'utc'))
    );

    CREATE TABLE IF NOT EXISTS idempotency_keys (
        key TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        request_hash TEXT NOT NULL,
        status TEXT NOT NULL,
        response_code INTEGER,
        response_body TEXT,
        created_at TEXT NOT NULL DEFAULT (datetime('now', 'utc')),
        expires_at TEXT NOT NULL
    );

    
    CREATE TABLE IF NOT EXISTS notification_logs (
        notification_id TEXT PRIMARY KEY,
        recipient_phone TEXT NOT NULL,
        channel TEXT NOT NULL, -- SMS, WHATSAPP, PUSH
        template_type TEXT NOT NULL, -- ORDER_CONFIRMED, DISPATCH_ASSIGNED, ORDER_DELIVERED
        message_body TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'SENT',
        sent_at TEXT NOT NULL DEFAULT (datetime('now', 'utc'))
    );
    CREATE INDEX IF NOT EXISTS idx_notifications_phone ON notification_logs(recipient_phone);
    
    CREATE TABLE IF NOT EXISTS policy_kill_switches (
        switch_key TEXT PRIMARY KEY,
        is_engaged INTEGER NOT NULL DEFAULT 0,
        reason TEXT,
        engaged_by TEXT,
        updated_at TEXT NOT NULL DEFAULT (datetime('now', 'utc'))
    );

    CREATE TABLE IF NOT EXISTS iam_users (
        user_id TEXT PRIMARY KEY,
        tenant_id TEXT NOT NULL DEFAULT 'EGY-FYM',
        phone_number TEXT UNIQUE NOT NULL,
        full_name TEXT NOT NULL,
        password_hash TEXT NOT NULL,
        governorate_code TEXT NOT NULL DEFAULT 'FYM',
        zone_id TEXT NOT NULL,
        device_fingerprint TEXT,
        is_active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL DEFAULT (datetime('now', 'utc'))
    );

    CREATE TABLE IF NOT EXISTS iam_roles (
        role_name TEXT PRIMARY KEY,
        description TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS iam_user_roles (
        user_id TEXT NOT NULL REFERENCES iam_users(user_id) ON DELETE CASCADE,
        role_name TEXT NOT NULL REFERENCES iam_roles(role_name) ON DELETE RESTRICT,
        PRIMARY KEY (user_id, role_name)
    );

    CREATE TABLE IF NOT EXISTS commerce_merchants (
        merchant_id TEXT PRIMARY KEY,
        tenant_id TEXT NOT NULL DEFAULT 'EGY-FYM',
        zone_id TEXT NOT NULL,
        name TEXT NOT NULL,
        merchant_type TEXT NOT NULL,
        is_platform_owned INTEGER NOT NULL DEFAULT 0,
        commission_rate REAL NOT NULL DEFAULT 0.15,
        lat REAL NOT NULL,
        lng REAL NOT NULL,
        is_open INTEGER NOT NULL DEFAULT 1,
        max_prep_time_minutes INTEGER NOT NULL DEFAULT 30,
        created_at TEXT NOT NULL DEFAULT (datetime('now', 'utc'))
    );

    CREATE TABLE IF NOT EXISTS commerce_skus (
        sku_id TEXT PRIMARY KEY,
        merchant_id TEXT NOT NULL REFERENCES commerce_merchants(merchant_id) ON DELETE CASCADE,
        category TEXT NOT NULL,
        name TEXT NOT NULL,
        price REAL NOT NULL CHECK (price >= 0),
        is_available INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL DEFAULT (datetime('now', 'utc'))
    );

    CREATE TABLE IF NOT EXISTS commerce_inventories (
        sku_id TEXT PRIMARY KEY REFERENCES commerce_skus(sku_id) ON DELETE CASCADE,
        available_qty INTEGER NOT NULL CHECK (available_qty >= 0),
        reserved_qty INTEGER NOT NULL DEFAULT 0 CHECK (reserved_qty >= 0),
        version INTEGER NOT NULL DEFAULT 1,
        updated_at TEXT NOT NULL DEFAULT (datetime('now', 'utc'))
    );

    CREATE TABLE IF NOT EXISTS orders_orders (
        order_id TEXT PRIMARY KEY,
        tenant_id TEXT NOT NULL DEFAULT 'EGY-FYM',
        zone_id TEXT NOT NULL,
        customer_id TEXT NOT NULL REFERENCES iam_users(user_id) ON DELETE RESTRICT,
        merchant_id TEXT NOT NULL REFERENCES commerce_merchants(merchant_id) ON DELETE RESTRICT,
        order_number TEXT UNIQUE NOT NULL,
        order_status TEXT NOT NULL,
        payment_method TEXT NOT NULL,
        payment_status TEXT NOT NULL,
        items_subtotal REAL NOT NULL CHECK (items_subtotal >= 0),
        delivery_fee REAL NOT NULL CHECK (delivery_fee >= 0),
        discount_amount REAL NOT NULL DEFAULT 0.0 CHECK (discount_amount >= 0),
        total_amount REAL NOT NULL CHECK (total_amount >= 0),
        delivery_address TEXT NOT NULL,
        delivery_lat REAL NOT NULL,
        delivery_lng REAL NOT NULL,
        version INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL DEFAULT (datetime('now', 'utc')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now', 'utc'))
    );
    CREATE INDEX IF NOT EXISTS idx_orders_customer ON orders_orders(customer_id, created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_orders_merchant ON orders_orders(merchant_id, order_status);

    CREATE TABLE IF NOT EXISTS orders_items (
        item_id TEXT PRIMARY KEY,
        order_id TEXT NOT NULL REFERENCES orders_orders(order_id) ON DELETE CASCADE,
        sku_id TEXT NOT NULL REFERENCES commerce_skus(sku_id) ON DELETE RESTRICT,
        name TEXT NOT NULL,
        unit_price REAL NOT NULL CHECK (unit_price >= 0),
        quantity INTEGER NOT NULL CHECK (quantity > 0),
        total_price REAL NOT NULL CHECK (total_price >= 0)
    );

    CREATE TABLE IF NOT EXISTS fleet_couriers (
        courier_id TEXT PRIMARY KEY,
        user_id TEXT UNIQUE NOT NULL REFERENCES iam_users(user_id) ON DELETE RESTRICT,
        vehicle_type TEXT NOT NULL,
        license_plate TEXT,
        max_payload_weight_kg REAL NOT NULL,
        max_payload_volume_m3 REAL NOT NULL,
        is_active INTEGER NOT NULL DEFAULT 1,
        is_online INTEGER NOT NULL DEFAULT 0,
        current_status TEXT NOT NULL DEFAULT 'IDLE',
        current_lat REAL,
        current_lng REAL,
        last_location_update TEXT,
        cod_balance_limit REAL NOT NULL DEFAULT 2000.00,
        created_at TEXT NOT NULL DEFAULT (datetime('now', 'utc'))
    );

    CREATE TABLE IF NOT EXISTS fleet_deliveries (
        delivery_id TEXT PRIMARY KEY,
        order_id TEXT UNIQUE NOT NULL REFERENCES orders_orders(order_id) ON DELETE RESTRICT,
        courier_id TEXT REFERENCES fleet_couriers(courier_id) ON DELETE RESTRICT,
        pickup_lat REAL NOT NULL,
        pickup_lng REAL NOT NULL,
        dropoff_lat REAL NOT NULL,
        dropoff_lng REAL NOT NULL,
        estimated_distance_km REAL NOT NULL,
        assigned_at TEXT,
        arrived_merchant_at TEXT,
        picked_up_at TEXT,
        delivered_at TEXT,
        wait_time_minutes INTEGER DEFAULT 0,
        delivery_otp_hash TEXT NOT NULL,
        otp_attempts INTEGER NOT NULL DEFAULT 0,
        otp_locked_until TEXT,
        otp_expires_at TEXT NOT NULL DEFAULT (datetime('now', 'utc', '+15 minutes')),
        created_at TEXT NOT NULL DEFAULT (datetime('now', 'utc'))
    );

    CREATE TABLE IF NOT EXISTS fleet_telemetry_logs (
        telemetry_id INTEGER PRIMARY KEY AUTOINCREMENT,
        courier_id TEXT NOT NULL REFERENCES fleet_couriers(courier_id) ON DELETE CASCADE,
        lat REAL NOT NULL,
        lng REAL NOT NULL,
        speed_kmh REAL NOT NULL,
        is_mock INTEGER NOT NULL DEFAULT 0,
        recorded_at TEXT NOT NULL DEFAULT (datetime('now', 'utc'))
    );

    CREATE TABLE IF NOT EXISTS finance_accounts (
        account_id TEXT PRIMARY KEY,
        account_number TEXT UNIQUE NOT NULL,
        account_name TEXT NOT NULL,
        account_type TEXT NOT NULL CHECK (account_type IN ('ASSET', 'LIABILITY', 'EQUITY', 'REVENUE', 'EXPENSE')),
        currency TEXT NOT NULL DEFAULT 'EGP',
        entity_type TEXT NOT NULL,
        entity_id TEXT NOT NULL,
        is_active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL DEFAULT (datetime('now', 'utc'))
    );
    CREATE INDEX IF NOT EXISTS idx_accounts_entity ON finance_accounts(entity_type, entity_id);

    CREATE TABLE IF NOT EXISTS finance_journal_entries (
        entry_id TEXT PRIMARY KEY,
        reference_type TEXT NOT NULL,
        reference_id TEXT NOT NULL,
        description TEXT NOT NULL,
        posted_at TEXT NOT NULL DEFAULT (datetime('now', 'utc')),
        created_by TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_entries_ref ON finance_journal_entries(reference_type, reference_id);

    CREATE TABLE IF NOT EXISTS finance_postings (
        posting_id TEXT PRIMARY KEY,
        entry_id TEXT NOT NULL REFERENCES finance_journal_entries(entry_id) ON DELETE RESTRICT,
        account_id TEXT NOT NULL REFERENCES finance_accounts(account_id) ON DELETE RESTRICT,
        amount REAL NOT NULL CHECK (amount > 0),
        direction TEXT NOT NULL CHECK (direction IN ('DR', 'CR')),
        created_at TEXT NOT NULL DEFAULT (datetime('now', 'utc'))
    );
    CREATE INDEX IF NOT EXISTS idx_postings_acc ON finance_postings(account_id, created_at);
    """)

    roles = [
        ("CUSTOMER", "End customer"),
        ("MERCHANT_STAFF", "Merchant store staff"),
        ("MERCHANT_OWNER", "Merchant store owner"),
        ("COURIER", "Fleet delivery courier"),
        ("OPS_DISPATCHER", "Operations dispatcher"),
        ("FINANCE_MANAGER", "Finance settlement manager"),
        ("SUPER_ADMIN", "Platform super administrator")
    ]
    cur.executemany("INSERT OR IGNORE INTO iam_roles (role_name, description) VALUES (?, ?);", roles)
    
    conn.commit()
    conn.close()

if __name__ == "__main__":
    init_db()
