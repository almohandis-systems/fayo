from fastapi import FastAPI, Request, Header, HTTPException, status
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import List, Optional, Dict, Any

from fayo_core.database import db_transaction, init_db
from fayo_core.shared.domain.errors import DomainError
from fayo_core.modules.iam.service import IAMService
from fayo_core.modules.catalog.service import CatalogService
from fayo_core.modules.orders.service import OrderService
from fayo_core.modules.logistics.service import LogisticsService
from fayo_core.modules.finance.service import FinancialLedgerService
from fayo_core.modules.notifications.service import NotificationService
from fayo_core.modules.ops.service import ControlTowerService

app = FastAPI(
    title="FAYO Core API",
    description="Faiyum Local Commerce & Logistics Platform API (Production Baseline V1)",
    version="1.0.0"
)

# RFC 7807 Global Exception Handler
@app.exception_handler(DomainError)
async def domain_error_handler(request: Request, exc: DomainError):
    return JSONResponse(
        status_code=exc.status_code,
        content=exc.to_dict(instance=request.url.path),
        headers={"Content-Type": "application/problem+json"}
    )

# --- DTOs ---
class RegisterUserDTO(BaseModel):
    phone_number: str
    full_name: str
    password: str
    zone_id: str
    role_name: str = "CUSTOMER"
    device_fingerprint: Optional[str] = None

class LoginDTO(BaseModel):
    phone_number: str
    password: str
    device_fingerprint: Optional[str] = None

class CreateMerchantDTO(BaseModel):
    name: str
    merchant_type: str
    zone_id: str
    lat: float
    lng: float
    is_platform_owned: bool = False
    commission_rate: float = 0.15

class AddSkuDTO(BaseModel):
    merchant_id: str
    category: str
    name: str
    price: float
    initial_qty: int

class OrderItemDTO(BaseModel):
    sku_id: str
    quantity: int

class CheckoutDTO(BaseModel):
    customer_id: str
    merchant_id: str
    items: List[OrderItemDTO]
    delivery_address: str
    delivery_lat: float
    delivery_lng: float
    payment_method: str = "COD"

class OrderStatusTransitionDTO(BaseModel):
    target_status: str
    actor_id: str
    actor_role: str
    decision_reason: Optional[str] = "State transition via API"

class RegisterCourierDTO(BaseModel):
    user_id: str
    vehicle_type: str
    license_plate: str
    cod_balance_limit: float = 2000.0

class TelemetryDTO(BaseModel):
    courier_id: str
    lat: float
    lng: float
    speed_kmh: float
    is_mock: bool = False

class CourierArriveDTO(BaseModel):
    delivery_id: str
    courier_id: str
    courier_lat: float
    courier_lng: float

class CourierPickupDTO(BaseModel):
    delivery_id: str
    courier_id: str

class CourierDeliverDTO(BaseModel):
    delivery_id: str
    courier_id: str
    provided_otp: str
    cash_collected: float

class RemittanceDTO(BaseModel):
    courier_id: str
    amount_remitted: float
    clearing_agent_id: str = "FAYO_MAIN_AGENT"

class KillSwitchDTO(BaseModel):
    switch_key: str
    is_engaged: bool
    reason: str
    actor_id: str

# --- Routers ---

# 1. IAM
@app.post("/api/v1/auth/register", status_code=status.HTTP_201_CREATED)
def register(dto: RegisterUserDTO):
    with db_transaction() as conn:
        iam = IAMService(conn)
        return iam.register_user(
            phone_number=dto.phone_number,
            full_name=dto.full_name,
            password=dto.password,
            zone_id=dto.zone_id,
            role_name=dto.role_name,
            device_fingerprint=dto.device_fingerprint
        )

@app.post("/api/v1/auth/login")
def login(dto: LoginDTO):
    with db_transaction() as conn:
        iam = IAMService(conn)
        return iam.authenticate_user(dto.phone_number, dto.password, dto.device_fingerprint)

# 2. Catalog
@app.post("/api/v1/catalog/merchants", status_code=status.HTTP_201_CREATED)
def create_merchant(dto: CreateMerchantDTO):
    with db_transaction() as conn:
        cat = CatalogService(conn)
        return cat.create_merchant(
            name=dto.name,
            merchant_type=dto.merchant_type,
            zone_id=dto.zone_id,
            lat=dto.lat,
            lng=dto.lng,
            is_platform_owned=dto.is_platform_owned,
            commission_rate=dto.commission_rate
        )

@app.post("/api/v1/catalog/skus", status_code=status.HTTP_201_CREATED)
def add_sku(dto: AddSkuDTO):
    with db_transaction() as conn:
        cat = CatalogService(conn)
        return cat.add_sku(dto.merchant_id, dto.category, dto.name, dto.price, dto.initial_qty)

# 3. Orders
@app.post("/api/v1/orders/checkout", status_code=status.HTTP_201_CREATED)
def checkout(dto: CheckoutDTO, idempotency_key: Optional[str] = Header(None, alias="Idempotency-Key")):
    with db_transaction() as conn:
        ord_svc = OrderService(conn)
        items_payload = [{"sku_id": it.sku_id, "quantity": it.quantity} for it in dto.items]
        res = ord_svc.place_order(
            customer_id=dto.customer_id,
            merchant_id=dto.merchant_id,
            items=items_payload,
            delivery_address=dto.delivery_address,
            delivery_lat=dto.delivery_lat,
            delivery_lng=dto.delivery_lng,
            payment_method=dto.payment_method,
            idempotency_key=idempotency_key
        )
        return res

@app.patch("/api/v1/orders/{order_id}/status")
def update_order_status(order_id: str, dto: OrderStatusTransitionDTO):
    with db_transaction() as conn:
        ord_svc = OrderService(conn)
        return ord_svc.transition_order_status(
            order_id=order_id,
            target_status=dto.target_status,
            actor_id=dto.actor_id,
            actor_role=dto.actor_role,
            decision_reason=dto.decision_reason
        )

# 4. Fleet & Dispatch
@app.post("/api/v1/fleet/couriers", status_code=status.HTTP_201_CREATED)
def register_courier(dto: RegisterCourierDTO):
    with db_transaction() as conn:
        log_svc = LogisticsService(conn)
        return log_svc.register_courier(
            user_id=dto.user_id,
            vehicle_type=dto.vehicle_type,
            license_plate=dto.license_plate,
            cod_balance_limit=dto.cod_balance_limit
        )

@app.post("/api/v1/fleet/telemetry")
def update_telemetry(dto: TelemetryDTO):
    with db_transaction() as conn:
        log_svc = LogisticsService(conn)
        log_svc.update_courier_telemetry(
            courier_id=dto.courier_id,
            lat=dto.lat,
            lng=dto.lng,
            speed_kmh=dto.speed_kmh,
            is_mock=dto.is_mock
        )
        return {"status": "TELEMETRY_RECORDED"}

@app.post("/api/v1/fleet/dispatch/{order_id}")
def dispatch_order(order_id: str):
    with db_transaction() as conn:
        log_svc = LogisticsService(conn)
        return log_svc.assign_smart_dispatch(order_id)

@app.post("/api/v1/fleet/handshake/arrive")
def courier_arrive(dto: CourierArriveDTO):
    with db_transaction() as conn:
        log_svc = LogisticsService(conn)
        log_svc.courier_arrive_merchant(dto.delivery_id, dto.courier_id, dto.courier_lat, dto.courier_lng)
        return {"status": "WAITING_AT_STORE"}

@app.post("/api/v1/fleet/handshake/pickup")
def courier_pickup(dto: CourierPickupDTO):
    with db_transaction() as conn:
        log_svc = LogisticsService(conn)
        log_svc.courier_pickup_order(dto.delivery_id, dto.courier_id)
        return {"status": "IN_DELIVERY"}

@app.post("/api/v1/fleet/handshake/deliver")
def courier_deliver(dto: CourierDeliverDTO):
    with db_transaction() as conn:
        log_svc = LogisticsService(conn)
        res = log_svc.confirm_delivery_handshake(
            delivery_id=dto.delivery_id,
            courier_id=dto.courier_id,
            provided_otp=dto.provided_otp,
            cash_collected=dto.cash_collected
        )
        # Also trigger double-entry financial settlement automatically
        fin = FinancialLedgerService(conn)
        entry_id = fin.process_order_delivered_settlement(
            order_id=res["order_id"],
            courier_id=dto.courier_id,
            cash_collected=dto.cash_collected
        )
        res["journal_entry_id"] = entry_id
        return res

# 5. Finance
@app.post("/api/v1/finance/remittance")
def courier_remittance(dto: RemittanceDTO):
    with db_transaction() as conn:
        fin = FinancialLedgerService(conn)
        entry_id = fin.process_courier_cash_remittance(
            courier_id=dto.courier_id,
            amount_remitted=dto.amount_remitted,
            clearing_agent_id=dto.clearing_agent_id
        )
        return {"status": "REMITTANCE_RECORDED", "journal_entry_id": entry_id}

@app.get("/api/v1/finance/accounts/{account_id}/balance")
def get_balance(account_id: str):
    with db_transaction() as conn:
        fin = FinancialLedgerService(conn)
        return {"account_id": account_id, "balance_egp": fin.get_account_balance(account_id)}

# 6. Control Tower & Operations
@app.get("/api/v1/ops/control-tower")
def get_control_tower_dashboard():
    with db_transaction() as conn:
        ops = ControlTowerService(conn)
        return ops.get_dashboard_snapshot()

@app.post("/api/v1/ops/kill-switch")
def update_kill_switch(dto: KillSwitchDTO):
    with db_transaction() as conn:
        ops = ControlTowerService(conn)
        ops.set_system_kill_switch(dto.switch_key, dto.is_engaged, dto.reason, dto.actor_id)
        return {"status": "KILL_SWITCH_UPDATED", "switch_key": dto.switch_key, "is_engaged": dto.is_engaged}

@app.post("/api/v1/ops/outbox/process")
def process_outbox():
    with db_transaction() as conn:
        ops = ControlTowerService(conn)
        count = ops.trigger_outbox_relay()
        return {"status": "OUTBOX_BATCH_PROCESSED", "events_processed": count}

class ToggleZoneDTO(BaseModel):
    zone_id: Optional[str] = None
    is_active: bool
    reason: str = "Administrative zone delivery update"
    actor_id: str

@app.get("/api/v1/ops/delivery-zones")
def get_delivery_zones():
    with db_transaction() as conn:
        ops = ControlTowerService(conn)
        return ops.get_delivery_zones_status()

@app.post("/api/v1/ops/delivery-zones/toggle")
def toggle_delivery_zone(dto: ToggleZoneDTO, x_admin_id: Optional[str] = Header(None, alias="X-Admin-Id")):
    caller_id = x_admin_id or dto.actor_id
    with db_transaction() as conn:
        cur = conn.cursor()
        cur.execute("SELECT role_name FROM iam_user_roles WHERE user_id = ?", (caller_id,))
        u_role = cur.fetchone()
        role = u_role["role_name"] if u_role else "UNKNOWN"
        
        if role not in ("ADMIN", "SUPER_ADMIN", "OPS"):
            from fayo_core.shared.infra.audit import log_audit_trail
            import uuid
            log_audit_trail(conn, str(uuid.uuid4()), caller_id, role, "UNAUTHORIZED_ZONE_CONTROL_ATTEMPT", "DELIVERY_ZONE", dto.zone_id or "ALL", "Non-admin attempted to change delivery zone status")
            conn.commit()
            raise HTTPException(status_code=403, detail="Forbidden: Admin or Ops privilege required to manage delivery zones.")

        ops = ControlTowerService(conn)
        res = ops.toggle_delivery_zone(dto.zone_id, dto.is_active, dto.reason, caller_id)
        
        from fayo_core.shared.infra.audit import log_audit_trail
        import uuid
        action = "DELIVERY_ZONES_ALL_TOGGLED" if dto.zone_id in ("ALL", None) else "DELIVERY_ZONE_TOGGLED"
        log_audit_trail(conn, str(uuid.uuid4()), caller_id, role, action, "DELIVERY_ZONE", dto.zone_id or "ALL", f"Zone status set to is_active={dto.is_active}: {dto.reason}")
        return res

# --- DTOs for Extensions ---
class UpdateInventoryDTO(BaseModel):
    available_qty: int

class RefundDTO(BaseModel):
    order_id: str
    refund_type: str # FULL or PARTIAL
    refund_amount: float
    reason: str
    actor_id: str

class OfflineSyncDTO(BaseModel):
    action_id: str
    delivery_id: str
    courier_id: str
    provided_otp: str
    cash_collected: float
    client_timestamp: str

# --- Customer APIs ---
@app.get("/api/v1/customer/{customer_id}/orders")
def get_customer_orders(customer_id: str, x_user_id: Optional[str] = Header(None, alias="X-User-Id")):
    with db_transaction() as conn:
        if x_user_id and x_user_id != customer_id:
            from fayo_core.shared.infra.audit import log_audit_trail
            import uuid
            log_audit_trail(conn, str(uuid.uuid4()), x_user_id, "CUSTOMER", "IDOR_ATTEMPT_CUSTOMER_ORDERS", "CUSTOMER", customer_id, "Cross-customer access attempt blocked")
            conn.commit()
            raise HTTPException(status_code=403, detail="Cross-tenant access forbidden: Cannot view another customer's orders.")

        cur = conn.cursor()
        cur.execute("SELECT order_id, order_number, order_status, total_amount, created_at FROM orders_orders WHERE customer_id = ? ORDER BY created_at DESC", (customer_id,))
        return [dict(r) for r in cur.fetchall()]

@app.post("/api/v1/customer/orders/{order_id}/cancel")
def cancel_customer_order(order_id: str, x_user_id: Optional[str] = Header(None, alias="X-User-Id")):
    with db_transaction() as conn:
        cur = conn.cursor()
        cur.execute("SELECT customer_id FROM orders_orders WHERE order_id = ?", (order_id,))
        row = cur.fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Order not found")
        if x_user_id and x_user_id != row["customer_id"]:
            from fayo_core.shared.infra.audit import log_audit_trail
            import uuid
            log_audit_trail(conn, str(uuid.uuid4()), x_user_id, "CUSTOMER", "IDOR_ATTEMPT_ORDER_CANCEL", "ORDER", order_id, "Unauthorized cancellation attempt blocked")
            conn.commit()
            raise HTTPException(status_code=403, detail="Cross-tenant access forbidden: Cannot cancel another customer's order.")

        ord_svc = OrderService(conn)
        return ord_svc.transition_order_status(order_id, "CANCELLED", x_user_id or row["customer_id"], "CUSTOMER", "Customer requested cancellation")

# --- Merchant APIs ---
@app.get("/api/v1/merchant/{merchant_id}/orders")
def get_merchant_orders(
    merchant_id: str,
    x_merchant_id: Optional[str] = Header(None, alias="X-Merchant-Id"),
    x_merchant_owner_id: Optional[str] = Header(None, alias="X-Merchant-Owner-Id")
):
    with db_transaction() as conn:
        caller_tenant = x_merchant_id or x_merchant_owner_id
        if caller_tenant and caller_tenant != merchant_id:
            from fayo_core.shared.infra.audit import log_audit_trail
            import uuid
            log_audit_trail(conn, str(uuid.uuid4()), caller_tenant, "MERCHANT", "IDOR_ATTEMPT_MERCHANT_ORDERS", "MERCHANT", merchant_id, "Cross-merchant order inspection blocked")
            conn.commit()
            raise HTTPException(status_code=403, detail="Cross-tenant access forbidden: Cannot view another merchant's orders.")

        cur = conn.cursor()
        cur.execute("SELECT order_id, order_number, order_status, total_amount, created_at FROM orders_orders WHERE merchant_id = ? ORDER BY created_at DESC", (merchant_id,))
        return [dict(r) for r in cur.fetchall()]

@app.patch("/api/v1/catalog/skus/{sku_id}/inventory")
def update_sku_inventory(sku_id: str, dto: UpdateInventoryDTO, x_merchant_id: Optional[str] = Header(None, alias="X-Merchant-Id")):
    with db_transaction() as conn:
        cur = conn.cursor()
        cur.execute("SELECT merchant_id FROM commerce_skus WHERE sku_id = ?", (sku_id,))
        sku = cur.fetchone()
        if not sku:
            raise HTTPException(status_code=404, detail="SKU not found")
        if x_merchant_id and x_merchant_id != sku["merchant_id"]:
            from fayo_core.shared.infra.audit import log_audit_trail
            import uuid
            log_audit_trail(conn, str(uuid.uuid4()), x_merchant_id, "MERCHANT", "IDOR_ATTEMPT_UPDATE_PRODUCT", "SKU", sku_id, "Cross-merchant inventory tampering attempt blocked")
            conn.commit()
            raise HTTPException(status_code=403, detail="Cross-tenant access forbidden: Merchant cannot modify another merchant's SKU inventory.")

        cur.execute("UPDATE commerce_inventories SET available_qty = ?, version = version + 1, updated_at = datetime('now', 'utc') WHERE sku_id = ?", (dto.available_qty, sku_id))
        return {"sku_id": sku_id, "available_qty": dto.available_qty}

# --- Offline Sync API ---
@app.post("/api/v1/fleet/offline-sync")
def offline_sync(dto: OfflineSyncDTO):
    with db_transaction() as conn:
        log_svc = LogisticsService(conn)
        res = log_svc.sync_offline_delivery(
            action_id=dto.action_id,
            delivery_id=dto.delivery_id,
            courier_id=dto.courier_id,
            provided_otp=dto.provided_otp,
            cash_collected=dto.cash_collected,
            client_timestamp=dto.client_timestamp
        )
        fin = FinancialLedgerService(conn)
        entry_id = fin.process_order_delivered_settlement(
            order_id=res["order_id"],
            courier_id=dto.courier_id,
            cash_collected=dto.cash_collected
        )
        res["journal_entry_id"] = entry_id
        return res

# --- Financial Refund Reversal API ---
@app.post("/api/v1/finance/refund")
def process_refund(dto: RefundDTO):
    with db_transaction() as conn:
        fin = FinancialLedgerService(conn)
        entry_id = fin.process_order_refund_reversal(
            order_id=dto.order_id,
            refund_type=dto.refund_type,
            refund_amount=dto.refund_amount,
            reason=dto.reason,
            actor_id=dto.actor_id
        )
        return {"status": "REFUND_RECORDED", "journal_entry_id": entry_id, "refund_type": dto.refund_type, "refund_amount": dto.refund_amount}


@app.get("/api/v1/catalog/merchants")
def list_merchants(zone_id: Optional[str] = None, merchant_type: Optional[str] = None, search: Optional[str] = None):
    with db_transaction() as conn:
        cur = conn.cursor()
        query = "SELECT merchant_id, name, merchant_type, zone_id, is_platform_owned, lat, lng, is_open, max_prep_time_minutes FROM commerce_merchants WHERE 1=1"
        params = []
        if zone_id:
            query += " AND zone_id = ?"
            params.append(zone_id)
        if merchant_type:
            query += " AND merchant_type = ?"
            params.append(merchant_type)
        if search:
            query += " AND (name LIKE ? OR merchant_type LIKE ?)"
            params.extend([f"%{search}%", f"%{search}%"])
        query += " ORDER BY is_platform_owned DESC, is_open DESC, name ASC"
        cur.execute(query, params)
        rows = [dict(r) for r in cur.fetchall()]
        for m in rows:
            cur.execute("SELECT COUNT(*) as sku_count FROM commerce_skus WHERE merchant_id = ? AND is_available = 1", (m["merchant_id"],))
            m["sku_count"] = cur.fetchone()["sku_count"]
        return rows

@app.get("/api/v1/catalog/merchants/{merchant_id}")
def get_merchant_details(merchant_id: str):
    with db_transaction() as conn:
        cur = conn.cursor()
        cur.execute("SELECT merchant_id, name, merchant_type, zone_id, is_platform_owned, lat, lng, is_open, max_prep_time_minutes FROM commerce_merchants WHERE merchant_id = ?", (merchant_id,))
        merchant = cur.fetchone()
        if not merchant:
            raise HTTPException(status_code=404, detail="Merchant not found")
        
        result = dict(merchant)
        cur.execute("""
            SELECT s.sku_id, s.category, s.name, s.price, s.is_available, i.available_qty
            FROM commerce_skus s
            LEFT JOIN commerce_inventories i ON s.sku_id = i.sku_id
            WHERE s.merchant_id = ? AND s.is_available = 1
            ORDER BY s.category ASC, s.name ASC
        """, (merchant_id,))
        result["skus"] = [dict(r) for r in cur.fetchall()]
        return result

@app.get("/api/v1/orders/{order_id}")
def get_order_details(order_id: str, x_user_id: Optional[str] = Header(None, alias="X-User-Id")):
    with db_transaction() as conn:
        cur = conn.cursor()
        cur.execute("""
            SELECT o.order_id, o.customer_id, o.order_number, o.order_status, o.payment_method, o.payment_status,
                   o.items_subtotal, o.delivery_fee, o.discount_amount, o.total_amount,
                   o.delivery_address, o.zone_id, o.created_at,
                   m.merchant_id, m.name as merchant_name, m.lat as merchant_lat, m.lng as merchant_lng
            FROM orders_orders o
            JOIN commerce_merchants m ON o.merchant_id = m.merchant_id
            WHERE o.order_id = ?
        """, (order_id,))
        order = cur.fetchone()
        if not order:
            raise HTTPException(status_code=404, detail="Order not found")

        # Multi-Tenant & RBAC Isolation:
        if x_user_id:
            cur.execute("SELECT role_name FROM iam_user_roles WHERE user_id = ?", (x_user_id,))
            u_row = cur.fetchone()
            role = u_row["role_name"] if u_row else "UNKNOWN"
            if role in ("ADMIN", "OPS") or x_user_id == order["customer_id"]:
                pass
            else:
                # Check if courier assigned to this delivery
                cur.execute("SELECT courier_id FROM fleet_deliveries WHERE order_id = ? AND courier_id IN (SELECT courier_id FROM fleet_couriers WHERE user_id = ?)", (order_id, x_user_id))
                is_courier = cur.fetchone() is not None
                if not is_courier:
                    from fayo_core.shared.infra.audit import log_audit_trail
                    import uuid
                    log_audit_trail(conn, str(uuid.uuid4()), x_user_id, role, "IDOR_ATTEMPT_GET_ORDER", "ORDER", order_id, "Cross-tenant access attempt to order blocked")
                    conn.commit()
                    raise HTTPException(status_code=403, detail="Cross-tenant access forbidden: Cannot view another user's order.")

        order_data = dict(order)

        # Get Items
        cur.execute("SELECT item_id, sku_id, name, unit_price, quantity, total_price FROM orders_items WHERE order_id = ?", (order_id,))
        order_data["items"] = [dict(r) for r in cur.fetchall()]

        # Get Delivery details if dispatched
        cur.execute("""
            SELECT d.delivery_id, d.courier_id, d.assigned_at, d.arrived_merchant_at, d.picked_up_at, d.delivered_at,
                   c.vehicle_type, u.full_name as courier_name, u.phone_number as courier_phone
            FROM fleet_deliveries d
            LEFT JOIN fleet_couriers c ON d.courier_id = c.courier_id
            LEFT JOIN iam_users u ON c.user_id = u.user_id
            WHERE d.order_id = ?
        """, (order_id,))
        deliv = cur.fetchone()
        order_data["delivery"] = dict(deliv) if deliv else None

        # Return OTP only to the authorized customer
        order_data["customer_otp"] = None
        if x_user_id and x_user_id == order["customer_id"]:
            cur.execute("""
                SELECT message_body FROM notification_logs
                WHERE recipient_phone IN (SELECT phone_number FROM iam_users WHERE user_id = ?)
                  AND template_type = 'DISPATCH_ASSIGNED'
                  AND message_body LIKE ?
                ORDER BY sent_at DESC LIMIT 1
            """, (order["customer_id"], f"%{order['order_number']}%"))
            n_row = cur.fetchone()
            if n_row:
                import re
                m = re.search(r"\[(\d{6})\]", n_row["message_body"])
                if m:
                    order_data["customer_otp"] = m.group(1)

        return order_data

from fastapi.responses import HTMLResponse
from fayo_core.api.ui import UI_HTML

@app.get("/", response_class=HTMLResponse)
@app.get("/app", response_class=HTMLResponse)
def get_fayo_app():
    return HTMLResponse(content=UI_HTML)
