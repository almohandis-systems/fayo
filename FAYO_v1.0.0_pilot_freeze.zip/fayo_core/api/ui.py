UI_HTML = """<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>FAYO — فايو | منظومة التجارة واللوجستيات المحلية بمحافظة الفيوم</title>
    <style>
        :root {
            --fayo-primary: #0b804b;
            --fayo-primary-dark: #076239;
            --fayo-accent: #f59e0b;
            --fayo-bg: #f8fafc;
            --fayo-card-bg: #ffffff;
            --fayo-text: #0f172a;
            --fayo-text-muted: #64748b;
            --fayo-border: #e2e8f0;
            --fayo-danger: #ef4444;
            --fayo-success: #10b981;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif; }
        body { background-color: var(--fayo-bg); color: var(--fayo-text); line-height: 1.5; padding-bottom: 80px; -webkit-tap-highlight-color: transparent; }
        .app-container { max-width: 520px; margin: 0 auto; background: var(--fayo-card-bg); min-height: 100vh; position: relative; box-shadow: 0 4px 20px rgba(0,0,0,0.05); }

        /* Top Header */
        .top-header { position: sticky; top: 0; z-index: 100; background: #ffffff; border-bottom: 1px solid var(--fayo-border); padding: 12px 16px; }
        .header-main { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }
        .brand-badge { display: flex; align-items: center; gap: 8px; font-weight: 800; font-size: 1.25rem; color: var(--fayo-primary); }
        .brand-logo-icon { width: 32px; height: 32px; background: var(--fayo-primary); color: #fff; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 1.1rem; }
        .location-selector { display: flex; align-items: center; gap: 6px; font-size: 0.85rem; color: var(--fayo-text); background: #f1f5f9; padding: 6px 12px; border-radius: 20px; border: 1px solid var(--fayo-border); cursor: pointer; }
        .location-selector select { border: none; background: transparent; font-size: 0.85rem; font-weight: 600; color: var(--fayo-primary-dark); outline: none; cursor: pointer; }

        /* Search Bar */
        .search-container { position: relative; width: 100%; }
        .search-input { width: 100%; padding: 10px 40px 10px 14px; border-radius: 12px; border: 1px solid var(--fayo-border); background: #f8fafc; font-size: 0.9rem; outline: none; transition: border-color 0.2s; }
        .search-input:focus { border-color: var(--fayo-primary); background: #ffffff; }
        .search-icon { position: absolute; right: 12px; top: 50%; transform: translateY(-50%); color: var(--fayo-text-muted); font-size: 1rem; pointer-events: none; }

        /* Promo Hero Cards Carousel */
        .promo-scroll { display: flex; gap: 12px; overflow-x: auto; padding: 14px 16px; scrollbar-width: none; }
        .promo-scroll::-webkit-scrollbar { display: none; }
        .promo-card { flex: 0 0 280px; height: 110px; border-radius: 14px; padding: 14px; color: #ffffff; display: flex; flex-direction: column; justify-content: space-between; position: relative; overflow: hidden; box-shadow: 0 4px 10px rgba(0,0,0,0.08); }
        .promo-card.card-1 { background: linear-gradient(135deg, #0b804b, #10b981); }
        .promo-card.card-2 { background: linear-gradient(135deg, #d97706, #f59e0b); }
        .promo-card.card-3 { background: linear-gradient(135deg, #0284c7, #38bdf8); }
        .promo-card h4 { font-size: 1rem; font-weight: 700; }
        .promo-card p { font-size: 0.75rem; opacity: 0.9; }
        .promo-badge { align-self: flex-start; background: rgba(255,255,255,0.25); padding: 2px 8px; border-radius: 10px; font-size: 0.7rem; font-weight: 600; }

        /* Categories Section */
        .categories-scroll { display: flex; gap: 10px; overflow-x: auto; padding: 4px 16px 14px; scrollbar-width: none; }
        .categories-scroll::-webkit-scrollbar { display: none; }
        .cat-chip { flex: 0 0 auto; padding: 8px 14px; border-radius: 20px; background: #f1f5f9; font-size: 0.85rem; font-weight: 600; color: var(--fayo-text); border: 1px solid transparent; cursor: pointer; transition: all 0.2s; display: flex; align-items: center; gap: 6px; }
        .cat-chip.active { background: var(--fayo-primary); color: #ffffff; border-color: var(--fayo-primary); }

        /* Section Headings */
        .section-header { display: flex; justify-content: space-between; align-items: center; padding: 12px 16px 8px; }
        .section-title { font-size: 1.05rem; font-weight: 800; color: var(--fayo-text); display: flex; align-items: center; gap: 6px; }
        .section-subtitle { font-size: 0.8rem; color: var(--fayo-text-muted); }

        /* Stores Grid */
        .stores-list { padding: 0 16px 16px; display: flex; flex-direction: column; gap: 14px; }
        .store-card { display: flex; gap: 12px; padding: 12px; border-radius: 14px; border: 1px solid var(--fayo-border); background: #ffffff; cursor: pointer; transition: transform 0.15s, box-shadow 0.15s; }
        .store-card:active { transform: scale(0.98); }
        .store-img-box { width: 84px; height: 84px; border-radius: 12px; background: #e2e8f0; display: flex; align-items: center; justify-content: center; font-size: 2rem; flex-shrink: 0; position: relative; overflow: hidden; }
        .store-info { flex: 1; display: flex; flex-direction: column; justify-content: space-between; }
        .store-header { display: flex; justify-content: space-between; align-items: flex-start; }
        .store-name { font-weight: 700; font-size: 0.95rem; color: var(--fayo-text); }
        .store-tag { font-size: 0.7rem; font-weight: 600; padding: 2px 6px; border-radius: 6px; background: #e0f2fe; color: #0284c7; }
        .store-tag.platform { background: #dcfce7; color: #15803d; }
        .store-meta { display: flex; gap: 10px; font-size: 0.78rem; color: var(--fayo-text-muted); margin-top: 4px; }
        .store-badges { display: flex; gap: 8px; align-items: center; margin-top: 6px; }
        .badge-pill { font-size: 0.72rem; padding: 2px 8px; border-radius: 8px; font-weight: 600; background: #f1f5f9; color: var(--fayo-text); }
        .badge-rating { background: #fef3c7; color: #b45309; }

        /* Floating Cart Bar */
        .floating-cart-bar { position: fixed; bottom: 64px; left: 50%; transform: translateX(-50%); width: calc(100% - 32px); max-width: 488px; background: var(--fayo-primary); color: #ffffff; padding: 12px 18px; border-radius: 16px; display: none; justify-content: space-between; align-items: center; z-index: 90; box-shadow: 0 8px 24px rgba(11,128,75,0.4); animation: slideUp 0.25s ease; cursor: pointer; }
        .floating-cart-info { display: flex; align-items: center; gap: 10px; }
        .cart-qty-bubble { background: #ffffff; color: var(--fayo-primary); font-weight: 800; font-size: 0.85rem; width: 26px; height: 26px; border-radius: 50%; display: flex; align-items: center; justify-content: center; }
        .cart-total-text { font-size: 1rem; font-weight: 700; }
        .cart-action-btn { display: flex; align-items: center; gap: 4px; font-weight: 700; font-size: 0.9rem; }

        /* Bottom Nav */
        .bottom-nav { position: fixed; bottom: 0; left: 50%; transform: translateX(-50%); width: 100%; max-width: 520px; height: 60px; background: #ffffff; border-top: 1px solid var(--fayo-border); display: flex; justify-content: space-around; align-items: center; z-index: 100; }
        .nav-item { display: flex; flex-direction: column; align-items: center; font-size: 0.72rem; font-weight: 600; color: var(--fayo-text-muted); text-decoration: none; cursor: pointer; }
        .nav-item.active { color: var(--fayo-primary); }
        .nav-item-icon { font-size: 1.25rem; margin-bottom: 2px; }

        /* Modals & Drawers */
        .modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 200; display: none; align-items: flex-end; justify-content: center; }
        .modal-overlay.open { display: flex; }
        .modal-content { background: #ffffff; width: 100%; max-width: 520px; max-height: 85vh; border-radius: 20px 20px 0 0; overflow-y: auto; padding: 20px 16px; position: relative; animation: slideUp 0.25s ease; }
        .modal-handle { width: 40px; height: 4px; background: #cbd5e1; border-radius: 2px; margin: 0 auto 14px; }
        .modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; border-bottom: 1px solid var(--fayo-border); padding-bottom: 10px; }
        .modal-title { font-size: 1.15rem; font-weight: 800; color: var(--fayo-text); }
        .close-btn { background: #f1f5f9; border: none; width: 30px; height: 30px; border-radius: 50%; font-size: 1.1rem; cursor: pointer; display: flex; align-items: center; justify-content: center; }

        /* Product Cards in Store View */
        .product-card { display: flex; justify-content: space-between; align-items: center; padding: 12px; border: 1px solid var(--fayo-border); border-radius: 12px; margin-bottom: 10px; }
        .prod-info { flex: 1; padding-left: 12px; }
        .prod-name { font-weight: 700; font-size: 0.95rem; }
        .prod-price { font-size: 0.9rem; font-weight: 800; color: var(--fayo-primary); margin-top: 4px; }
        .prod-action { flex-shrink: 0; }
        .add-btn { background: var(--fayo-primary); color: #fff; border: none; padding: 6px 16px; border-radius: 20px; font-weight: 700; font-size: 0.85rem; cursor: pointer; transition: background 0.15s; }
        .add-btn:active { background: var(--fayo-primary-dark); }
        .qty-stepper { display: flex; align-items: center; gap: 8px; background: #f1f5f9; padding: 4px 8px; border-radius: 20px; border: 1px solid var(--fayo-border); }
        .stepper-btn { width: 26px; height: 26px; border-radius: 50%; background: #ffffff; border: 1px solid var(--fayo-border); font-weight: 800; cursor: pointer; display: flex; align-items: center; justify-content: center; }
        .stepper-val { font-weight: 800; font-size: 0.9rem; min-width: 18px; text-align: center; }

        /* Tracking Timeline */
        .timeline { display: flex; flex-direction: column; gap: 16px; margin: 16px 0; }
        .timeline-step { display: flex; gap: 12px; align-items: flex-start; position: relative; }
        .timeline-step::before { content: ''; position: absolute; right: 13px; top: 26px; bottom: -16px; width: 2px; background: var(--fayo-border); }
        .timeline-step:last-child::before { display: none; }
        .step-icon { width: 28px; height: 28px; border-radius: 50%; background: #e2e8f0; color: #64748b; display: flex; align-items: center; justify-content: center; font-size: 0.8rem; font-weight: 700; z-index: 1; }
        .timeline-step.completed .step-icon { background: var(--fayo-primary); color: #ffffff; }
        .timeline-step.active .step-icon { background: var(--fayo-accent); color: #ffffff; box-shadow: 0 0 0 4px #fef3c7; }
        .step-content { flex: 1; }
        .step-title { font-weight: 700; font-size: 0.9rem; }
        .step-desc { font-size: 0.75rem; color: var(--fayo-text-muted); }

        /* Security OTP Card */
        .otp-security-box { background: #fefce8; border: 2px dashed #f59e0b; border-radius: 14px; padding: 14px; text-align: center; margin: 14px 0; }
        .otp-digits { font-size: 1.75rem; font-weight: 900; letter-spacing: 6px; color: #b45309; margin: 6px 0; }
        .otp-hint { font-size: 0.75rem; color: #92400e; font-weight: 600; }

        /* Buttons & Forms */
        .btn-checkout { width: 100%; padding: 14px; background: var(--fayo-primary); color: #ffffff; border: none; border-radius: 14px; font-size: 1rem; font-weight: 800; cursor: pointer; margin-top: 14px; }
        .form-group { margin-bottom: 12px; }
        .form-label { display: block; font-size: 0.8rem; font-weight: 700; margin-bottom: 4px; }
        .form-input { width: 100%; padding: 10px; border-radius: 10px; border: 1px solid var(--fayo-border); font-size: 0.9rem; outline: none; }

        @keyframes slideUp { from { transform: translateY(100%); } to { transform: translateY(0); } }
    </style>
</head>
<body>
    <div class="app-container" id="app">
        <!-- Top Header -->
        <header class="top-header">
            <div class="header-main">
                <div class="brand-badge">
                    <div class="brand-logo-icon">ف</div>
                    <span>FAYO • فايو</span>
                </div>
                <div class="location-selector">
                    <span>📍</span>
                    <select id="zoneSelect" onchange="changeZone(this.value)">
                        <option value="FYM-CITY" selected>بندر الفيوم</option>
                        <option value="FYM-SINNURIS">سنورس</option>
                        <option value="FYM-ITSA">إطسا</option>
                        <option value="FYM-IBSHAWAY">أبشواي</option>
                        <option value="FYM-TUNIS">قرية تونس</option>
                    </select>
                </div>
            </div>
            <div class="search-container">
                <span class="search-icon">🔍</span>
                <input type="text" class="search-input" id="searchInput" placeholder="ابحث عن متجر، وجبة، خضار طازج..." oninput="handleSearch(this.value)">
            </div>
        </header>

        <!-- Promotional Hero Banners -->
        <div class="promo-scroll">
            <div class="promo-card card-1" onclick="filterCategory('FARM')">
                <div class="promo-badge">🌾 مزارع الفيوم</div>
                <h4>خير الفيوم</h4>
                <p>طازج يومياً من المزرعة إلى باب منزلك</p>
            </div>
            <div class="promo-card card-2" onclick="filterCategory('RESTAURANT')">
                <div class="promo-badge">🔥 عروض اليوم</div>
                <h4>مطاعم ومشويات الفيوم</h4>
                <p>توصيل سريع وساخن حتى بابك</p>
            </div>
            <div class="promo-card card-3" onclick="filterCategory('GROCERY')">
                <div class="promo-badge">⚡ توصيل فوري</div>
                <h4>سوبرماركت فايو</h4>
                <p>كافة مستلزمات البقالة والمنزل</p>
            </div>
        </div>

        <!-- Category Pills Navigation -->
        <div class="categories-scroll" id="categoriesBar">
            <button class="cat-chip active" onclick="filterCategory('ALL')">✨ الكل</button>
            <button class="cat-chip" onclick="filterCategory('RESTAURANT')">🍽️ مطاعم</button>
            <button class="cat-chip" onclick="filterCategory('GROCERY')">🛒 بقالة ومارت</button>
            <button class="cat-chip" onclick="filterCategory('FARM')">🌾 خير الفيوم</button>
            <button class="cat-chip" onclick="filterCategory('PHARMACY')">💊 صيدلية</button>
            <button class="cat-chip" onclick="filterCategory('TOURISM')">⛵ سياحة ومخيمات</button>
        </div>

        <!-- Section: Curated Stores -->
        <div class="section-header">
            <div class="section-title">
                <span>⭐</span>
                <span>المتاجر المتاحة في منطقتك</span>
            </div>
            <span class="section-subtitle" id="storesCountSubtitle">جاري التحميل...</span>
        </div>

                <!-- Zone Notice Banner -->
        <div id="zoneNoticeBanner" style="display:none; margin: 0 16px 12px; padding: 12px 14px; background: #fef2f2; border: 1px solid #fecaca; border-radius: 12px; color: #b91c1c; font-weight: 700; font-size: 0.85rem; text-align: center;">
            ⚠️ خدمة التوصيل غير متاحة حالياً في هذه المنطقة.
        </div>

        <!-- Store List Cards -->
        <div class="stores-list" id="storesList">
            <!-- Dynamically populated via API -->
        </div>

        <!-- Floating Cart Bar -->
        <div class="floating-cart-bar" id="floatingCart" onclick="openCartModal()">
            <div class="floating-cart-info">
                <div class="cart-qty-bubble" id="floatingCartQty">0</div>
                <div class="cart-total-text" id="floatingCartTotal">0.00 ج.م</div>
            </div>
            <div class="cart-action-btn">
                <span>عرض السلة وإتمام الطلب</span>
                <span>←</span>
            </div>
        </div>

        <!-- Bottom Navigation -->
        <nav class="bottom-nav">
            <div class="nav-item active" onclick="switchNav('home')">
                <span class="nav-item-icon">🏠</span>
                <span>الرئيسية</span>
            </div>
            <div class="nav-item" onclick="switchNav('orders')">
                <span class="nav-item-icon">📋</span>
                <span>طلباتي</span>
            </div>
            <div class="nav-item" onclick="openAdminZonesModal()">
                <span class="nav-item-icon">🛡️</span>
                <span>نطاقات التوصيل</span>
            </div>
            <div class="nav-item" onclick="switchNav('profile')">
                <span class="nav-item-icon">👤</span>
                <span>حسابي</span>
            </div>
        </nav>

        <!-- Store Menu Modal -->
        <div class="modal-overlay" id="storeModal">
            <div class="modal-content">
                <div class="modal-handle"></div>
                <div class="modal-header">
                    <div>
                        <div class="modal-title" id="modalStoreName">اسم المتجر</div>
                        <div style="font-size: 0.8rem; color: var(--fayo-text-muted);" id="modalStoreMeta">معلومات المتجر</div>
                    </div>
                    <button class="close-btn" onclick="closeStoreModal()">✕</button>
                </div>
                <div id="storeProductsList">
                    <!-- Loaded dynamically -->
                </div>
            </div>
        </div>

        <!-- Cart & Checkout Modal -->
        <div class="modal-overlay" id="cartModal">
            <div class="modal-content">
                <div class="modal-handle"></div>
                <div class="modal-header">
                    <div class="modal-title">سلة الطلبات</div>
                    <button class="close-btn" onclick="closeCartModal()">✕</button>
                </div>
                <div id="cartItemsList" style="margin-bottom: 14px;">
                    <!-- Cart items -->
                </div>
                <div style="background: #f8fafc; padding: 12px; border-radius: 12px; margin-bottom: 12px;">
                    <div style="display:flex; justify-content:space-between; font-size:0.85rem; margin-bottom:4px;">
                        <span>قيمة الأصناف:</span>
                        <span id="cartSubtotalText">0.00 ج.م</span>
                    </div>
                    <div style="display:flex; justify-content:space-between; font-size:0.85rem; margin-bottom:4px;">
                        <span>رسوم التوصيل المقدرة:</span>
                        <span id="cartDeliveryFeeText">15.00 ج.م</span>
                    </div>
                    <div style="display:flex; justify-content:space-between; font-weight:800; font-size:1rem; border-top:1px solid #e2e8f0; padding-top:6px; margin-top:6px;">
                        <span>الإجمالي للدفع:</span>
                        <span id="cartFinalTotalText" style="color:var(--fayo-primary);">0.00 ج.م</span>
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">عنوان التسليم بالتفصيل:</label>
                    <input type="text" class="form-input" id="checkoutAddress" placeholder="اسم الشارع، رقم العمارة أو المنزل، علامة مميزة">
                </div>
                <div class="form-group">
                    <label class="form-label">طريقة الدفع:</label>
                    <div style="padding:10px; background:#f1f5f9; border-radius:10px; font-weight:700; font-size:0.85rem;">
                        💵 الدفع عند الاستلام (كاش / COD)
                    </div>
                </div>
                <button class="btn-checkout" id="submitOrderBtn" onclick="submitCheckout()">تأكيد الطلب الآن (الدفع عند الاستلام)</button>
            </div>
        </div>

        <!-- Admin Zones Modal -->
        <div class="modal-overlay" id="adminZonesModal">
            <div class="modal-content">
                <div class="modal-handle"></div>
                <div class="modal-header">
                    <div>
                        <div class="modal-title">إدارة نطاقات التوصيل</div>
                        <div style="font-size: 0.8rem; color: var(--fayo-text-muted);">تحكم برج المراقبة في مراكز محافظة الفيوم</div>
                    </div>
                    <button class="close-btn" onclick="closeAdminZonesModal()">✕</button>
                </div>
                <div style="display: flex; gap: 8px; margin-bottom: 14px;">
                    <button onclick="toggleAllZones(false)" style="flex: 1; padding: 10px 8px; background: #fee2e2; color: #b91c1c; border: 1px solid #fecaca; border-radius: 10px; font-weight: 700; font-size: 0.8rem; cursor: pointer;">🔴 إيقاف جميع المراكز</button>
                    <button onclick="toggleAllZones(true)" style="flex: 1; padding: 10px 8px; background: #dcfce7; color: #15803d; border: 1px solid #bbf7d0; border-radius: 10px; font-weight: 700; font-size: 0.8rem; cursor: pointer;">🟢 إعادة تشغيل الجميع</button>
                </div>
                <div id="adminZonesList" style="margin-top: 8px;">
                    <!-- Populated dynamically -->
                </div>
            </div>
        </div>

        <!-- Order Live Tracking Modal -->
        <div class="modal-overlay" id="trackingModal">
            <div class="modal-content">
                <div class="modal-handle"></div>
                <div class="modal-header">
                    <div>
                        <div class="modal-title">تتبع الطلب المباشر</div>
                        <div style="font-size: 0.8rem; color: var(--fayo-primary); font-weight:700;" id="trackOrderNumber">طلب رقم FYM-XXXX</div>
                    </div>
                    <button class="close-btn" onclick="closeTrackingModal()">✕</button>
                </div>
                
                <!-- OTP Box -->
                <div class="otp-security-box" id="otpBox">
                    <div class="otp-hint">رمز التحقق السري للتسليم (OTP)</div>
                    <div class="otp-digits" id="trackOtpDisplay">------</div>
                    <div class="otp-hint">⚠️ اعطه للمندوب فقط عند استلام طلبك ومطابقة السلع</div>
                </div>

                <!-- Timeline -->
                <div class="timeline" id="orderTimeline">
                    <div class="timeline-step completed" id="step-created">
                        <div class="step-icon">✓</div>
                        <div class="step-content">
                            <div class="step-title">تم استلام الطلب</div>
                            <div class="step-desc">تم تسجيل طلبك في نظام فايو بنجاح</div>
                        </div>
                    </div>
                    <div class="timeline-step" id="step-preparing">
                        <div class="step-icon">👨‍🍳</div>
                        <div class="step-content">
                            <div class="step-title">قيد التجهيز في المتجر</div>
                            <div class="step-desc">المتجر يجهز الأصناف بعناية</div>
                        </div>
                    </div>
                    <div class="timeline-step" id="step-dispatched">
                        <div class="step-icon">🛵</div>
                        <div class="step-content">
                            <div class="step-title">تم إسناد المندوب</div>
                            <div class="step-desc">المندوب توجه للمتجر للاستلام</div>
                        </div>
                    </div>
                    <div class="timeline-step" id="step-intransit">
                        <div class="step-icon">📦</div>
                        <div class="step-content">
                            <div class="step-title">جاري التوصيل</div>
                            <div class="step-desc">المندوب في طريقه لعنوانك</div>
                        </div>
                    </div>
                    <div class="timeline-step" id="step-delivered">
                        <div class="step-icon">🏠</div>
                        <div class="step-content">
                            <div class="step-title">تم التسليم بنجاح</div>
                            <div class="step-desc">شكراً لتسوقك عبر فايو</div>
                        </div>
                    </div>
                </div>

                <div id="courierInfoCard" style="display:none; background:#f1f5f9; padding:12px; border-radius:12px; margin-top:12px;">
                    <div style="font-weight:700; font-size:0.85rem;" id="courierNameText">المندوب: أحمد الفيومي</div>
                    <div style="font-size:0.75rem; color:var(--fayo-text-muted);" id="courierVehicleText">مركبة: موتوسيكل</div>
                </div>
            </div>
        </div>

    </div>

    <!-- Application Script -->
    <script>
        // State
        const state = {
            currentZone: 'FYM-CITY',
            activeCategory: 'ALL',
            merchants: [],
            cart: {}, // sku_id -> { sku_id, name, price, qty, merchant_id }
            currentMerchant: null,
            activeOrder: null,
            currentUserId: null,
            zoneStatuses: {},
            globalPaused: false
        };

        // Bootstrap on Load
        document.addEventListener('DOMContentLoaded', () => {
            initUserSession();
            loadZoneStatuses();
            loadMerchants();
        });

        // Initialize user session
        async function initUserSession() {
            let uid = localStorage.getItem('fayo_user_id');
            if (!uid) {
                // Register default guest session with real backend
                try {
                    const phone = '010' + Math.floor(10000000 + Math.random() * 90000000);
                    const res = await fetch('/api/v1/auth/register', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            phone_number: phone,
                            full_name: 'عميل فايو',
                            password: 'Pass_' + phone,
                            zone_id: state.currentZone,
                            role_name: 'CUSTOMER'
                        })
                    });
                    if (res.ok) {
                        const data = await res.json();
                        uid = data.user_id;
                        localStorage.setItem('fayo_user_id', uid);
                    }
                } catch(e) {
                    console.error('Session init error', e);
                }
            }
            state.currentUserId = uid;
        }

        // Zone Change
        function changeZone(zone) {
            state.currentZone = zone;
            document.getElementById('checkoutAddress').value = getZoneName(zone) + ' - ';
            updateZoneBanner();
            loadMerchants();
        }

        function getZoneName(z) {
            const map = {
                'FYM-CITY': 'بندر الفيوم',
                'FYM-SINNURIS': 'سنورس',
                'FYM-ITSA': 'إطسا',
                'FYM-IBSHAWAY': 'أبشواي',
                'FYM-TUNIS': 'قرية تونس'
            };
            return map[z] || z;
        }

        // Filter Category
        function filterCategory(cat) {
            state.activeCategory = cat;
            document.querySelectorAll('.cat-chip').forEach(c => c.classList.remove('active'));
            event && event.target && event.target.classList.add('active');
            renderMerchantsList();
        }

        // Search Input
        function handleSearch(val) {
            renderMerchantsList(val.trim());
        }

        // Fetch Merchants from Real Backend
        async function loadMerchants() {
            try {
                const res = await fetch(`/api/v1/catalog/merchants?zone_id=${state.currentZone}`);
                if (res.ok) {
                    state.merchants = await res.json();
                } else {
                    // Fallback to all merchants if zone specific is empty
                    const resAll = await fetch('/api/v1/catalog/merchants');
                    state.merchants = await resAll.json();
                }
                renderMerchantsList();
            } catch (err) {
                console.error('Failed to load merchants', err);
            }
        }

        // Render Merchants
        function renderMerchantsList(searchQuery = '') {
            const listEl = document.getElementById('storesList');
            const subTitleEl = document.getElementById('storesCountSubtitle');
            
            let filtered = state.merchants;
            if (state.activeCategory !== 'ALL') {
                filtered = filtered.filter(m => m.merchant_type === state.activeCategory);
            }
            if (searchQuery) {
                filtered = filtered.filter(m => m.name.toLowerCase().includes(searchQuery.toLowerCase()));
            }

            subTitleEl.textContent = `${filtered.length} متجر`;

            if (filtered.length === 0) {
                listEl.innerHTML = `<div style="text-align:center; padding:30px 10px; color:#64748b;">لا توجد متاجر مطابقة في هذا النطاق حالياً</div>`;
                return;
            }

            listEl.innerHTML = filtered.map(m => {
                const iconMap = { 'FARM': '🌾', 'RESTAURANT': '🍗', 'GROCERY': '🛒', 'PHARMACY': '💊' };
                const icon = iconMap[m.merchant_type] || '🏪';
                const tagClass = m.is_platform_owned ? 'store-tag platform' : 'store-tag';
                const tagLabel = m.is_platform_owned ? 'اختيارات فايو' : (m.is_open ? 'مفتوح الآن' : 'مغلق');

                return `
                <div class="store-card" onclick="openStoreModal('${m.merchant_id}')">
                    <div class="store-img-box">${icon}</div>
                    <div class="store-info">
                        <div class="store-header">
                            <span class="store-name">${m.name}</span>
                            <span class="${tagClass}">${tagLabel}</span>
                        </div>
                        <div class="store-meta">
                            <span>⏱️ ${m.max_prep_time_minutes || 25} دقيقة</span>
                            <span>•</span>
                            <span>🛵 15 ج.م توصيل</span>
                        </div>
                        <div class="store-badges">
                            <span class="badge-pill badge-rating">★ 4.8</span>
                            <span class="badge-pill">${getZoneName(m.zone_id)}</span>
                        </div>
                    </div>
                </div>
                `;
            }).join('');
        }

        // Open Store Details Modal
        async function openStoreModal(merchantId) {
            try {
                const res = await fetch(`/api/v1/catalog/merchants/${merchantId}`);
                if (!res.ok) return;
                const merchant = await res.json();
                state.currentMerchant = merchant;

                document.getElementById('modalStoreName').textContent = merchant.name;
                document.getElementById('modalStoreMeta').textContent = `${getZoneName(merchant.zone_id)} • توصيل خلال ${merchant.max_prep_time_minutes || 30} دقيقة`;

                const prodListEl = document.getElementById('storeProductsList');
                if (!merchant.skus || merchant.skus.length === 0) {
                    prodListEl.innerHTML = `<div style="text-align:center; padding:20px; color:#64748b;">لا توجد منتجات مسجلة لهذا المتجر حالياً</div>`;
                } else {
                    prodListEl.innerHTML = merchant.skus.map(s => {
                        const inCartQty = state.cart[s.sku_id]?.qty || 0;
                        return `
                        <div class="product-card" id="prod-row-${s.sku_id}">
                            <div class="prod-info">
                                <div class="prod-name">${s.name}</div>
                                <div style="font-size:0.75rem; color:#64748b;">${s.category}</div>
                                <div class="prod-price">${Number(s.price).toFixed(2)} ج.م</div>
                            </div>
                            <div class="prod-action" id="action-box-${s.sku_id}">
                                ${inCartQty > 0 ? renderStepper(s.sku_id, inCartQty) : `<button class="add-btn" onclick="addToCart('${s.sku_id}', '${escape(s.name)}', ${s.price}, '${merchant.merchant_id}')">+ أضف</button>`}
                            </div>
                        </div>
                        `;
                    }).join('');
                }

                document.getElementById('storeModal').classList.add('open');
            } catch(e) {
                console.error('Error opening store', e);
            }
        }

        function closeStoreModal() {
            document.getElementById('storeModal').classList.remove('open');
        }

        function renderStepper(skuId, qty) {
            return `
            <div class="qty-stepper">
                <button class="stepper-btn" onclick="modifyCartQty('${skuId}', -1)">-</button>
                <span class="stepper-val">${qty}</span>
                <button class="stepper-btn" onclick="modifyCartQty('${skuId}', 1)">+</button>
            </div>
            `;
        }

        // Cart Management
        function addToCart(skuId, name, price, merchantId) {
            // Check if cart has items from another merchant
            const existingMerch = Object.values(state.cart)[0]?.merchant_id;
            if (existingMerch && existingMerch !== merchantId) {
                if (confirm('السلة تحتوي على منتجات من متجر آخر. هل تريد إفراغ السلة وبدء طلب جديد؟')) {
                    state.cart = {};
                } else {
                    return;
                }
            }

            state.cart[skuId] = {
                sku_id: skuId,
                name: unescape(name),
                price: Number(price),
                qty: 1,
                merchant_id: merchantId
            };
            updateCartUI();
            updateProductRowAction(skuId);
        }

        function modifyCartQty(skuId, delta) {
            if (!state.cart[skuId]) return;
            state.cart[skuId].qty += delta;
            if (state.cart[skuId].qty <= 0) {
                delete state.cart[skuId];
            }
            updateCartUI();
            updateProductRowAction(skuId);
            renderCartModalItems();
        }

        function updateProductRowAction(skuId) {
            const box = document.getElementById(`action-box-${skuId}`);
            if (!box) return;
            const item = state.cart[skuId];
            if (item && item.qty > 0) {
                box.innerHTML = renderStepper(skuId, item.qty);
            } else {
                box.innerHTML = `<button class="add-btn" onclick="addToCart('${skuId}', '${escape(state.cart[skuId]?.name || '')}', ${state.cart[skuId]?.price || 0}, '${state.currentMerchant?.merchant_id}')">+ أضف</button>`;
            }
        }

        function updateCartUI() {
            const items = Object.values(state.cart);
            const totalQty = items.reduce((sum, it) => sum + it.qty, 0);
            const subtotal = items.reduce((sum, it) => sum + (it.price * it.qty), 0);

            const barEl = document.getElementById('floatingCart');
            if (totalQty > 0) {
                document.getElementById('floatingCartQty').textContent = totalQty;
                document.getElementById('floatingCartTotal').textContent = `${subtotal.toFixed(2)} ج.م`;
                barEl.style.display = 'flex';
            } else {
                barEl.style.display = 'none';
                closeCartModal();
            }
        }

        // Cart Modal & Checkout
        function openCartModal() {
            renderCartModalItems();
            document.getElementById('cartModal').classList.add('open');
        }

        function closeCartModal() {
            document.getElementById('cartModal').classList.remove('open');
        }

        function renderCartModalItems() {
            const listEl = document.getElementById('cartItemsList');
            const items = Object.values(state.cart);

            if (items.length === 0) {
                listEl.innerHTML = `<div style="text-align:center; padding:15px; color:#64748b;">السلة فارغة</div>`;
                return;
            }

            listEl.innerHTML = items.map(it => `
            <div style="display:flex; justify-content:space-between; align-items:center; padding:8px 0; border-bottom:1px solid #f1f5f9;">
                <div>
                    <div style="font-weight:700; font-size:0.9rem;">${it.name}</div>
                    <div style="font-size:0.8rem; color:#64748b;">${it.price.toFixed(2)} × ${it.qty} = ${(it.price * it.qty).toFixed(2)} ج.م</div>
                </div>
                ${renderStepper(it.sku_id, it.qty)}
            </div>
            `).join('');

            const subtotal = items.reduce((sum, it) => sum + (it.price * it.qty), 0);
            const deliveryFee = 15.0;
            const total = subtotal + deliveryFee;

            document.getElementById('cartSubtotalText').textContent = `${subtotal.toFixed(2)} ج.م`;
            document.getElementById('cartDeliveryFeeText').textContent = `${deliveryFee.toFixed(2)} ج.م`;
            document.getElementById('cartFinalTotalText').textContent = `${total.toFixed(2)} ج.م`;
        }

        // Submit Checkout via Real API
        async function submitCheckout() {
            const btn = document.getElementById('submitOrderBtn');
            const items = Object.values(state.cart);
            if (items.length === 0) return;

            const merchantId = items[0].merchant_id;
            const isInactive = (state.zoneStatuses[state.currentZone] === false || state.globalPaused);
            if (isInactive) {
                alert('خدمة التوصيل غير متاحة حالياً في هذه المنطقة.');
                return;
            }
            const address = document.getElementById('checkoutAddress').value.trim() || (getZoneName(state.currentZone) + ' - عنوان رئيسي');

            btn.disabled = true;
            btn.textContent = 'جاري تأكيد الطلب وحجز المخزون...';

            const idempotencyKey = 'IDEM_' + Date.now() + '_' + Math.random().toString(36).substring(2, 9);

            try {
                const res = await fetch('/api/v1/orders/checkout', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Idempotency-Key': idempotencyKey
                    },
                    body: JSON.stringify({
                        customer_id: state.currentUserId,
                        merchant_id: merchantId,
                        items: items.map(it => ({ sku_id: it.sku_id, quantity: it.qty })),
                        delivery_address: address,
                        delivery_lat: 29.3100,
                        delivery_lng: 30.8400,
                        payment_method: 'COD'
                    })
                });

                if (res.ok) {
                    const orderData = await res.json();
                    state.activeOrder = orderData;
                    state.cart = {};
                    updateCartUI();
                    closeCartModal();
                    closeStoreModal();
                    openTrackingModal(orderData.order_id);
                } else {
                    const err = await res.json();
                    alert('خطأ في إتمام الطلب: ' + (err.detail || err.title || 'فشل الحجز'));
                }
            } catch (err) {
                console.error('Checkout error', err);
                alert('تعذر الاتصال بالخادم. يرجى المحاولة مرة أخرى.');
            } finally {
                btn.disabled = false;
                btn.textContent = 'تأكيد الطلب الآن (الدفع عند الاستلام)';
            }
        }

        // Live Order Tracking
        async function openTrackingModal(orderId) {
            document.getElementById('trackingModal').classList.add('open');
            fetchOrderTracking(orderId);
        }

        function closeTrackingModal() {
            document.getElementById('trackingModal').classList.remove('open');
        }

        async function fetchOrderTracking(orderId) {
            try {
                const headers = state.currentUserId ? { 'X-User-Id': state.currentUserId } : {};
                const res = await fetch(`/api/v1/orders/${orderId}`, { headers });
                if (!res.ok) return;
                const order = await res.json();

                document.getElementById('trackOrderNumber').textContent = `طلب رقم ${order.order_number}`;

                // Update OTP display
                if (order.customer_otp) {
                    document.getElementById('trackOtpDisplay').textContent = order.customer_otp;
                } else if (order.order_status === 'DELIVERED') {
                    document.getElementById('trackOtpDisplay').textContent = 'تم التسليم';
                } else {
                    document.getElementById('trackOtpDisplay').textContent = 'قيد التجهيز';
                }

                // Update timeline
                updateTimelineSteps(order.order_status);

                if (order.delivery) {
                    document.getElementById('courierInfoCard').style.display = 'block';
                    document.getElementById('courierNameText').textContent = `المندوب: ${order.delivery.courier_name || 'مندوب فايو'}`;
                    document.getElementById('courierVehicleText').textContent = `نوع المركبة: ${order.delivery.vehicle_type || 'موتوسيكل'}`;
                }
            } catch(e) {
                console.error('Tracking fetch error', e);
            }
        }

        function updateTimelineSteps(status) {
            const steps = ['created', 'preparing', 'dispatched', 'intransit', 'delivered'];
            const statusIndex = {
                'CREATED': 0,
                'ACCEPTED': 1,
                'PREPARING': 1,
                'READY_FOR_PICKUP': 2,
                'IN_TRANSIT': 3,
                'DELIVERED': 4
            }[status] || 0;

            steps.forEach((s, idx) => {
                const el = document.getElementById(`step-${s}`);
                if (!el) return;
                el.classList.remove('completed', 'active');
                if (idx < statusIndex) el.classList.add('completed');
                else if (idx === statusIndex) el.classList.add('active');
            });
        }

        function switchNav(tab) {
            document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
            event && event.currentTarget && event.currentTarget.classList.add('active');
            if (tab === 'orders' && state.activeOrder) {
                openTrackingModal(state.activeOrder.order_id);
            }
        }

        // Delivery Zones Management Functions
        async function loadZoneStatuses() {
            try {
                const res = await fetch('/api/v1/ops/delivery-zones');
                if (res.ok) {
                    const data = await res.json();
                    state.globalPaused = (data.global_status === 'PAUSED');
                    data.zones.forEach(z => {
                        state.zoneStatuses[z.zone_id] = z.is_active;
                    });
                    updateZoneBanner();
                }
            } catch(e) {
                console.error('Failed to load zones status', e);
            }
        }

        function updateZoneBanner() {
            const banner = document.getElementById('zoneNoticeBanner');
            const isInactive = (state.zoneStatuses[state.currentZone] === false || state.globalPaused);
            if (banner) {
                banner.style.display = isInactive ? 'block' : 'none';
            }
        }

        async function openAdminZonesModal() {
            document.getElementById('adminZonesModal').classList.add('open');
            renderAdminZonesList();
        }

        function closeAdminZonesModal() {
            document.getElementById('adminZonesModal').classList.remove('open');
        }

        async function renderAdminZonesList() {
            const listEl = document.getElementById('adminZonesList');
            listEl.innerHTML = '<div style="text-align:center; padding:15px; color:#64748b;">جاري تحميل النطاقات...</div>';
            try {
                const res = await fetch('/api/v1/ops/delivery-zones');
                if (!res.ok) return;
                const data = await res.json();
                listEl.innerHTML = data.zones.map(z => `
                    <div style="display:flex; justify-content:space-between; align-items:center; padding:12px 0; border-bottom:1px solid #f1f5f9;">
                        <div>
                            <div style="font-weight:700; font-size:0.95rem;">${z.name_ar}</div>
                            <div style="font-size:0.75rem; color:${z.is_active ? '#15803d' : '#b91c1c'}; font-weight:600; margin-top:2px;">
                                ${z.is_active ? '🟢 التوصيل مفعّل' : '🔴 التوصيل متوقف'} ${z.reason ? '<span style="color:#64748b;">(' + z.reason + ')</span>' : ''}
                            </div>
                        </div>
                        <button onclick="toggleSingleZone('${z.zone_id}', ${!z.is_active})" style="padding:6px 14px; border-radius:8px; font-weight:700; font-size:0.8rem; border:1px solid ${z.is_active ? '#fca5a5' : '#86efac'}; background:${z.is_active ? '#fff1f2' : '#f0fdf4'}; color:${z.is_active ? '#be123c' : '#166534'}; cursor:pointer;">
                            ${z.is_active ? 'إيقاف التوصيل' : 'تفعيل التوصيل'}
                        </button>
                    </div>
                `).join('');
            } catch(e) {
                listEl.innerHTML = '<div style="color:red; text-align:center;">خطأ في تحميل النطاقات</div>';
            }
        }

        async function toggleSingleZone(zoneId, targetActive) {
            try {
                const res = await fetch('/api/v1/ops/delivery-zones/toggle', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        zone_id: zoneId,
                        is_active: targetActive,
                        reason: targetActive ? 'تفعيل تشغيلي للمركز' : 'إيقاف تشغيلي مؤقت',
                        actor_id: state.currentUserId
                    })
                });
                if (res.ok) {
                    await loadZoneStatuses();
                    renderAdminZonesList();
                } else {
                    const err = await res.json();
                    alert('تعذر التعديل: ' + (err.detail || 'غير مصرح'));
                }
            } catch(e) {
                console.error(e);
            }
        }

        async function toggleAllZones(targetActive) {
            if (!confirm(targetActive ? 'هل تريد إعادة تشغيل التوصيل في جميع المراكز؟' : 'هل تريد إيقاف التوصيل في جميع مراكز المحافظة؟')) return;
            try {
                const res = await fetch('/api/v1/ops/delivery-zones/toggle', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        zone_id: 'ALL',
                        is_active: targetActive,
                        reason: targetActive ? 'إعادة تشغيل عام للمحافظة' : 'إيقاف طوارئ عام للمحافظة',
                        actor_id: state.currentUserId
                    })
                });
                if (res.ok) {
                    await loadZoneStatuses();
                    renderAdminZonesList();
                } else {
                    const err = await res.json();
                    alert('تعذر التعديل: ' + (err.detail || 'غير مصرح'));
                }
            } catch(e) {
                console.error(e);
            }
        }
    </script>
</body>
</html>
"""
