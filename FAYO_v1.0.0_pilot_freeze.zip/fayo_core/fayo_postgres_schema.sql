-- ====================================================================
-- FAYO — فايو | PostgreSQL 16 + PostGIS Production Schema DDL
-- ====================================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "postgis";

-- 1. SCHEMAS
CREATE SCHEMA IF NOT EXISTS iam;
CREATE SCHEMA IF NOT EXISTS commerce;
CREATE SCHEMA IF NOT EXISTS orders;
CREATE SCHEMA IF NOT EXISTS fleet;
CREATE SCHEMA IF NOT EXISTS finance;
CREATE SCHEMA IF NOT EXISTS audit;

-- 2. AUDIT & OUTBOX
CREATE TABLE IF NOT EXISTS audit.system_audit_trail (
    audit_id BIGSERIAL PRIMARY KEY,
    trace_id VARCHAR(64) NOT NULL,
    actor_id VARCHAR(64) NOT NULL,
    actor_type VARCHAR(32) NOT NULL,
    action VARCHAR(64) NOT NULL,
    entity_type VARCHAR(64) NOT NULL,
    entity_id VARCHAR(64) NOT NULL,
    ip_address INET,
    user_agent TEXT,
    input_payload JSONB,
    decision_reason TEXT NOT NULL,
    state_before JSONB,
    state_after JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_audit_trace ON audit.system_audit_trail(trace_id);
CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit.system_audit_trail(entity_type, entity_id);

CREATE TABLE IF NOT EXISTS audit.transactional_outbox (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    aggregate_type VARCHAR(64) NOT NULL,
    aggregate_id VARCHAR(64) NOT NULL,
    event_type VARCHAR(64) NOT NULL,
    payload JSONB NOT NULL,
    headers JSONB NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
    retry_count INT NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    published_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_outbox_unprocessed ON audit.transactional_outbox(created_at) WHERE status = 'PENDING';

CREATE TABLE IF NOT EXISTS audit.dead_letter_events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    original_event_id VARCHAR(64) NOT NULL,
    event_type VARCHAR(64) NOT NULL,
    payload JSONB NOT NULL,
    error_reason TEXT NOT NULL,
    retry_count INT NOT NULL,
    failed_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS audit.idempotency_keys (
    key VARCHAR(128) PRIMARY KEY,
    user_id VARCHAR(64) NOT NULL,
    request_hash VARCHAR(64) NOT NULL,
    status VARCHAR(20) NOT NULL,
    response_code INT,
    response_body JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS audit.policy_kill_switches (
    switch_key VARCHAR(128) PRIMARY KEY,
    is_engaged INT NOT NULL DEFAULT 0,
    reason TEXT,
    engaged_by VARCHAR(64),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 3. IAM
CREATE TABLE IF NOT EXISTS iam.users (
    user_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id VARCHAR(32) NOT NULL DEFAULT 'EGY-FYM',
    phone_number VARCHAR(32) UNIQUE NOT NULL,
    full_name VARCHAR(128) NOT NULL,
    password_hash VARCHAR(256) NOT NULL,
    governorate_code VARCHAR(10) NOT NULL DEFAULT 'FYM',
    zone_id VARCHAR(32) NOT NULL,
    device_fingerprint VARCHAR(128),
    is_active INT NOT NULL DEFAULT 1,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS iam.roles (
    role_name VARCHAR(32) PRIMARY KEY,
    description TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS iam.user_roles (
    user_id UUID NOT NULL REFERENCES iam.users(user_id) ON DELETE CASCADE,
    role_name VARCHAR(32) NOT NULL REFERENCES iam.roles(role_name) ON DELETE RESTRICT,
    PRIMARY KEY (user_id, role_name)
);

-- 4. COMMERCE
CREATE TABLE IF NOT EXISTS commerce.merchants (
    merchant_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id VARCHAR(32) NOT NULL DEFAULT 'EGY-FYM',
    zone_id VARCHAR(32) NOT NULL,
    name VARCHAR(128) NOT NULL,
    merchant_type VARCHAR(32) NOT NULL,
    is_platform_owned INT NOT NULL DEFAULT 0,
    commission_rate NUMERIC(5, 4) NOT NULL DEFAULT 0.1500,
    lat NUMERIC(9, 6) NOT NULL,
    lng NUMERIC(9, 6) NOT NULL,
    is_open INT NOT NULL DEFAULT 1,
    max_prep_time_minutes INT NOT NULL DEFAULT 30,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS commerce.skus (
    sku_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    merchant_id UUID NOT NULL REFERENCES commerce.merchants(merchant_id) ON DELETE CASCADE,
    category VARCHAR(64) NOT NULL,
    name VARCHAR(128) NOT NULL,
    price NUMERIC(10, 2) NOT NULL CHECK (price >= 0),
    is_available INT NOT NULL DEFAULT 1,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS commerce.inventories (
    sku_id UUID PRIMARY KEY REFERENCES commerce.skus(sku_id) ON DELETE CASCADE,
    available_qty INT NOT NULL CHECK (available_qty >= 0),
    reserved_qty INT NOT NULL DEFAULT 0 CHECK (reserved_qty >= 0),
    version INT NOT NULL DEFAULT 1,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 5. ORDERS
CREATE TABLE IF NOT EXISTS orders.orders (
    order_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id VARCHAR(32) NOT NULL DEFAULT 'EGY-FYM',
    zone_id VARCHAR(32) NOT NULL,
    customer_id UUID NOT NULL REFERENCES iam.users(user_id) ON DELETE RESTRICT,
    merchant_id UUID NOT NULL REFERENCES commerce.merchants(merchant_id) ON DELETE RESTRICT,
    order_number VARCHAR(32) UNIQUE NOT NULL,
    order_status VARCHAR(32) NOT NULL,
    payment_method VARCHAR(16) NOT NULL,
    payment_status VARCHAR(16) NOT NULL,
    items_subtotal NUMERIC(10, 2) NOT NULL CHECK (items_subtotal >= 0),
    delivery_fee NUMERIC(10, 2) NOT NULL CHECK (delivery_fee >= 0),
    discount_amount NUMERIC(10, 2) NOT NULL DEFAULT 0.00 CHECK (discount_amount >= 0),
    total_amount NUMERIC(10, 2) NOT NULL CHECK (total_amount >= 0),
    delivery_address TEXT NOT NULL,
    delivery_lat NUMERIC(9, 6) NOT NULL,
    delivery_lng NUMERIC(9, 6) NOT NULL,
    version INT NOT NULL DEFAULT 1,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_orders_customer ON orders.orders(customer_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_orders_merchant ON orders.orders(merchant_id, order_status);

CREATE TABLE IF NOT EXISTS orders.order_items (
    item_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id UUID NOT NULL REFERENCES orders.orders(order_id) ON DELETE CASCADE,
    sku_id UUID NOT NULL REFERENCES commerce.skus(sku_id) ON DELETE RESTRICT,
    name VARCHAR(128) NOT NULL,
    unit_price NUMERIC(10, 2) NOT NULL CHECK (unit_price >= 0),
    quantity INT NOT NULL CHECK (quantity > 0),
    total_price NUMERIC(10, 2) NOT NULL CHECK (total_price >= 0)
);

-- 6. FLEET & LOGISTICS
CREATE TABLE IF NOT EXISTS fleet.couriers (
    courier_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID UNIQUE NOT NULL REFERENCES iam.users(user_id) ON DELETE RESTRICT,
    vehicle_type VARCHAR(16) NOT NULL,
    license_plate VARCHAR(32),
    max_payload_weight_kg NUMERIC(6, 2) NOT NULL,
    max_payload_volume_m3 NUMERIC(6, 3) NOT NULL,
    is_active INT NOT NULL DEFAULT 1,
    is_online INT NOT NULL DEFAULT 0,
    current_status VARCHAR(20) NOT NULL DEFAULT 'IDLE',
    current_lat NUMERIC(9, 6),
    current_lng NUMERIC(9, 6),
    last_location_update TIMESTAMPTZ,
    cod_balance_limit NUMERIC(10, 2) NOT NULL DEFAULT 2000.00,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS fleet.deliveries (
    delivery_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id UUID UNIQUE NOT NULL REFERENCES orders.orders(order_id) ON DELETE RESTRICT,
    courier_id UUID REFERENCES fleet.couriers(courier_id) ON DELETE RESTRICT,
    pickup_lat NUMERIC(9, 6) NOT NULL,
    pickup_lng NUMERIC(9, 6) NOT NULL,
    dropoff_lat NUMERIC(9, 6) NOT NULL,
    dropoff_lng NUMERIC(9, 6) NOT NULL,
    estimated_distance_km NUMERIC(6, 2) NOT NULL,
    assigned_at TIMESTAMPTZ,
    arrived_merchant_at TIMESTAMPTZ,
    picked_up_at TIMESTAMPTZ,
    delivered_at TIMESTAMPTZ,
    wait_time_minutes INT DEFAULT 0,
    delivery_otp_hash VARCHAR(128) NOT NULL,
    otp_attempts INT NOT NULL DEFAULT 0,
    otp_locked_until TIMESTAMPTZ,
    otp_expires_at TIMESTAMPTZ NOT NULL DEFAULT (NOW() + INTERVAL '15 minutes'),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 7. FINANCIAL LEDGER
CREATE TABLE IF NOT EXISTS finance.accounts (
    account_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    account_number VARCHAR(32) UNIQUE NOT NULL,
    account_name VARCHAR(128) NOT NULL,
    account_type VARCHAR(16) NOT NULL CHECK (account_type IN ('ASSET', 'LIABILITY', 'EQUITY', 'REVENUE', 'EXPENSE')),
    currency VARCHAR(3) NOT NULL DEFAULT 'EGP',
    entity_type VARCHAR(32) NOT NULL,
    entity_id VARCHAR(64) NOT NULL,
    is_active INT NOT NULL DEFAULT 1,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_accounts_entity ON finance.accounts(entity_type, entity_id);

CREATE TABLE IF NOT EXISTS finance.journal_entries (
    entry_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    reference_type VARCHAR(32) NOT NULL,
    reference_id VARCHAR(64) NOT NULL,
    description TEXT NOT NULL,
    posted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by VARCHAR(64) NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_entries_ref ON finance.journal_entries(reference_type, reference_id);

CREATE TABLE IF NOT EXISTS finance.postings (
    posting_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entry_id UUID NOT NULL REFERENCES finance.journal_entries(entry_id) ON DELETE RESTRICT,
    account_id UUID NOT NULL REFERENCES finance.accounts(account_id) ON DELETE RESTRICT,
    amount NUMERIC(14, 4) NOT NULL CHECK (amount > 0),
    direction VARCHAR(2) NOT NULL CHECK (direction IN ('DR', 'CR')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_postings_acc ON finance.postings(account_id, created_at);
