# FAYO — فايو
## منظومة التجارة واللوجستيات بمحافظة الفيوم
**Release:** `v1.0.0-pilot-freeze`

### التشغيل السريع:
1. تثبيت الاعتماديات:
   ```bash
   pip install -r requirements.txt
   ```
2. بدء الخادم:
   ```bash
   ./run.sh
   # أو:
   python3 -m uvicorn fayo_core.api.main:app --host 0.0.0.0 --port 8000
   ```
3. فتح التطبيق في المتصفح:
   - واجهة المستخدم وتطبيق الجوال: `http://localhost:8000/` أو `http://localhost:8000/app`
   - توثيق الـ API: `http://localhost:8000/docs`
   - إدارة نطاقات التوصيل: `http://localhost:8000/api/v1/ops/delivery-zones`
